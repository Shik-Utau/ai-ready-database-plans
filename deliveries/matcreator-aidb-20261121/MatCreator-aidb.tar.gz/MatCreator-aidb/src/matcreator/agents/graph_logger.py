"""Agent execution graph logger.

Writes a JSON file per session to {workspace_root}/agent_graphs/{session_id}.json
tracking the agent node hierarchy and execution status for frontend visualization.

Schema
------
{
  "session_id": "<str>",
  "nodes": {
    "<node_id>": {
      "id": "<str>",
      "type": "orchestrator|planning|execution|tester|step",
      "label": "<str>",
      "status": "idle|running|success|failed|needs_replanning",
      "parent_id": "<str|null>",
      "dependency_ids": ["<str>", ...],
      "batch_id": "<str|null>",
      "start_time": "<ISO-8601|null>",
      "end_time": "<ISO-8601|null>",
      "summary": "<str|null>",
      "artifacts": ["<str>", ...],
      "input": {"step_number": int, "action": str, ...} | null,
      "tool_calls": [{"name": str, "input": dict, "output": dict, "args_summary": str, "result_summary": str,
                       "start_time": str, "end_time": str}, ...],
      "state_delta": {"<key>": "<value>", ...}
    }
  },
  "edges": [{"from": "<str>", "to": "<str>"}],
  "updated_at": "<ISO-8601>"
}
"""

from __future__ import annotations

import json
import threading
from datetime import datetime, timezone
from typing import List, Literal, Optional

from ..workspace import ADK_DIR

_session_locks: dict[str, threading.Lock] = {}
_session_locks_mutex = threading.Lock()

NodeStatus = Literal["idle", "running", "waiting", "success", "failed", "cancelled", "needs_replanning"]
NodeType = Literal["orchestrator", "planning", "execution", "tester", "step"]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class AgentGraphLogger:
    """File-backed logger that tracks agent node lifecycle for a single session."""

    def __init__(self, session_id: str) -> None:
        self.session_id = session_id
        graph_dir = ADK_DIR / "agent_graphs"
        graph_dir.mkdir(parents=True, exist_ok=True)
        self._path = graph_dir / f"{session_id}.json"
        with _session_locks_mutex:
            if session_id not in _session_locks:
                _session_locks[session_id] = threading.Lock()
            self._lock = _session_locks[session_id]

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def log_node_start(
        self,
        node_id: str,
        node_type: NodeType,
        label: str,
        parent_id: Optional[str] = None,
        batch_id: Optional[str] = None,
        dependency_ids: Optional[List[str]] = None,
    ) -> None:
        """Create or overwrite a node with status=running.

        ``parent_id`` records the phase that launched a node.  When a DAG
        node has explicit predecessors, ``dependency_ids`` supplies its real
        incoming graph edges instead.  This keeps the visualization topology
        faithful without losing the execution-phase association.
        """
        with self._lock:
            graph = self._read()
            existing = graph["nodes"].get(node_id)
            dependencies = list(dict.fromkeys(dependency_ids or []))
            node = {
                "id": node_id,
                "type": node_type,
                "label": label,
                "status": "running",
                "parent_id": parent_id,
                "dependency_ids": dependencies,
                # Execution producers may share this value for work launched
                # by one planning round. It is presentation metadata only: the
                # actual parent edge remains parent_id -> node_id.
                "batch_id": batch_id if batch_id is not None else (existing or {}).get("batch_id"),
                "start_time": existing["start_time"] if existing else _now(),
                "end_time": None,
                "summary": None,
                "artifacts": [],
                "input": None,
                "tool_calls": [],
                "state_delta": {},
                "conversation": [],
                "revision": (existing or {}).get("revision", 0),
            }
            graph["nodes"][node_id] = node
            incoming_ids = dependencies or ([parent_id] if parent_id else [])
            for source_id in incoming_ids:
                if source_id and source_id in graph["nodes"]:
                    edge = {"from": source_id, "to": node_id}
                    if edge not in graph["edges"]:
                        graph["edges"].append(edge)
            node["revision"] = node.get("revision", 0) + 1
            self._write(graph)

    def find_step_node(self, node_id: str) -> Optional[str]:
        """Return the latest logged graph node for an execution-DAG node.

        A resumed execution phase can have a new ``execution_*`` container,
        while its predecessor was completed in an earlier one.  Looking up the
        logged step avoids fabricating an edge to that new container's ID.
        """
        with self._lock:
            matches = [
                node for node in self._read()["nodes"].values()
                if node.get("type") == "step"
                and (node.get("input") or {}).get("node_id") == node_id
            ]
        if not matches:
            return None
        return max(matches, key=lambda node: node.get("start_time") or "").get("id")

    def log_node_complete(
        self,
        node_id: str,
        status: NodeStatus,
        summary: Optional[str] = None,
        artifacts: Optional[List[str]] = None,
    ) -> None:
        """Update an existing node with completion info."""
        with self._lock:
            graph = self._read()
            node = graph["nodes"].get(node_id)
            if node is None:
                return
            # A cancellation is terminal for this run. A late completion from
            # an already-cancelled async task must not turn the graph green.
            if node.get("status") == "cancelled" and status != "cancelled":
                return
            if (
                node.get("end_time") and node.get("status") == status
                and (summary is None or node.get("summary") == summary)
                and (artifacts is None or node.get("artifacts") == artifacts)
            ):
                return
            node["status"] = status
            node["end_time"] = _now()
            if summary is not None:
                node["summary"] = summary
            if artifacts is not None:
                node["artifacts"] = artifacts
            node["revision"] = node.get("revision", 0) + 1
            self._write(graph)

    def count_nodes_of_type(self, node_type: NodeType) -> int:
        """Return how many nodes of the given type already exist (for loop indices)."""
        graph = self._read()
        return sum(1 for n in graph["nodes"].values() if n["type"] == node_type)

    def nodes_of_type(self, node_type: NodeType) -> list[dict]:
        """Return graph nodes of a type for lifecycle-aware node reuse."""
        graph = self._read()
        return [node for node in graph["nodes"].values() if node.get("type") == node_type]

    def log_node_input(self, node_id: str, input_data: dict) -> None:
        """Store the structured input that was passed to the sub-agent."""
        with self._lock:
            graph = self._read()
            node = graph["nodes"].get(node_id)
            if node is None:
                return
            if node.get("input") == input_data:
                return
            node["revision"] = node.get("revision", 0) + 1
            node["input"] = input_data
            self._write(graph)

    def log_tool_call(self, node_id: str, entry: dict) -> None:
        """Append one tool-call record to the node's tool_calls list."""
        with self._lock:
            graph = self._read()
            node = graph["nodes"].get(node_id)
            if node is None:
                return
            node["revision"] = node.get("revision", 0) + 1
            node.setdefault("tool_calls", []).append(entry)
            self._write(graph)

    def log_state_delta(self, node_id: str, delta: dict) -> None:
        """Merge delta into the node's accumulated state_delta."""
        with self._lock:
            graph = self._read()
            node = graph["nodes"].get(node_id)
            if node is None:
                return
            current = node.get("state_delta") or {}
            if all(key in current and current[key] == value for key, value in delta.items()):
                return
            node["revision"] = node.get("revision", 0) + 1
            node.setdefault("state_delta", {}).update(delta)
            self._write(graph)

    def log_conversation_event(self, node_id: str, entry: dict) -> None:
        """Append one conversation turn, coalescing adjacent streamed text.

        LLM providers may send either a token delta or the entire response so
        far.  Keeping every chunk made the graph noisy and meant the frontend
        could not present a single live response for a running node.
        """
        with self._lock:
            graph = self._read()
            node = graph["nodes"].get(node_id)
            if node is None:
                return
            conversation = node.setdefault("conversation", [])
            previous = conversation[-1] if conversation else None
            if (
                previous
                and entry.get("type") in {"text", "thought"}
                and previous.get("type") == entry.get("type")
                and previous.get("author") == entry.get("author")
                and isinstance(previous.get("content"), str)
                and isinstance(entry.get("content"), str)
            ):
                content = _merge_streamed_text(previous["content"], entry["content"])
                if content == previous["content"]:
                    return
                previous["content"] = content
                previous["timestamp"] = entry.get("timestamp", previous.get("timestamp"))
            else:
                conversation.append(entry)
            node["revision"] = node.get("revision", 0) + 1
            self._write(graph)

    def mark_running_nodes_cancelled(
        self,
        node_types: Optional[list[NodeType]] = None,
        summary: str = "Cancelled by user",
    ) -> None:
        """Pre-emptively mark running nodes as cancelled.

        Called eagerly on session cancel so the graph reflects cancellation
        before the step executor polls its flag.
        """
        with self._lock:
            graph = self._read()
            now = _now()
            changed = False
            for node in graph["nodes"].values():
                if node.get("status") != "running":
                    continue
                if node_types is not None and node.get("type") not in node_types:
                    continue
                node["status"] = "cancelled"
                node["end_time"] = now
                node["summary"] = summary
                node["revision"] = node.get("revision", 0) + 1
                changed = True
            if changed:
                self._write(graph)

    def cancel_step_node_by_number(self, step_number: int, summary: str = "Cancelled by user") -> bool:
        """Find the running step node with input.step_number==step_number and mark it cancelled.

        Returns True if a node was found and updated.
        """
        with self._lock:
            graph = self._read()
            now = _now()
            for node in graph["nodes"].values():
                if (
                    node.get("type") == "step"
                    and node.get("status") == "running"
                    and (node.get("input") or {}).get("step_number") == step_number
                ):
                    node["status"] = "cancelled"
                    node["end_time"] = now
                    node["summary"] = summary
                    node["revision"] = node.get("revision", 0) + 1
                    self._write(graph)
                    return True
        return False

    def cancel_step_node_by_id(self, node_id: str, summary: str = "Cancelled by user") -> bool:
        """Find the running step node with input.node_id==node_id and mark it cancelled.

        Used for DAG-mode cancellation where nodes are identified by string node_id.
        Returns True if a matching node was found and updated.
        """
        with self._lock:
            graph = self._read()
            now = _now()
            for node in graph["nodes"].values():
                if (
                    node.get("type") == "step"
                    and node.get("status") == "running"
                    and (node.get("input") or {}).get("node_id") == node_id
                ):
                    node["status"] = "cancelled"
                    node["end_time"] = now
                    node["summary"] = summary
                    node["revision"] = node.get("revision", 0) + 1
                    self._write(graph)
                    return True
        return False

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _read(self) -> dict:
        if self._path.exists():
            try:
                return json.loads(self._path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass
        return {"session_id": self.session_id, "nodes": {}, "edges": [], "updated_at": _now()}

    def _write(self, graph: dict) -> None:
        graph["updated_at"] = _now()
        self._path.write_text(json.dumps(graph, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")


def _merge_streamed_text(current: str, incoming: str) -> str:
    """Merge a streamed delta or cumulative snapshot without duplicated text."""
    if not incoming or current.endswith(incoming):
        return current
    if incoming.startswith(current):
        return incoming
    for overlap in range(min(len(current), len(incoming)), 0, -1):
        if current.endswith(incoming[:overlap]):
            return current + incoming[overlap:]
    return current + incoming
