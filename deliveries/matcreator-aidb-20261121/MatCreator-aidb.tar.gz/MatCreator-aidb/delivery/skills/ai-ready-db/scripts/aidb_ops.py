#!/usr/bin/env python3
"""Local aidb operations for MatCreator; stdout is a small JSON receipt."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys
import uuid
import hashlib
from contextlib import contextmanager
from typing import Any


def ensure_runtime() -> None:
    """Reuse the installed bridge's environment discovery, without its server."""
    if os.environ.get('_AIDB_OPS_RUNTIME') == '1':
        return
    from aidb_client import discover_aidb_python, discover_aidb_root
    root = discover_aidb_root()
    python = discover_aidb_python(root)
    env = dict(os.environ, _AIDB_OPS_RUNTIME='1', PYTHONDONTWRITEBYTECODE='1')
    env['PYTHONPATH'] = str(root) + os.pathsep + env.get('PYTHONPATH', '')
    os.execve(str(python), [str(python), '-B', str(Path(__file__).resolve()), *sys.argv[1:]], env)


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')


def workspace_config(path: str | None, *, reading: bool) -> tuple[dict, Path]:
    from ai_ready_db.config import load_config
    if not path:
        raise ValueError('Specify --config or AI_READY_DB_CONFIG; no database path is guessed')
    config_path = Path(path).expanduser().resolve(strict=True)
    config = load_config(config_path)
    # Require explicit storage locations, rather than load_config's data/ defaults.
    import yaml
    supplied = yaml.safe_load(config_path.read_text(encoding='utf-8'))
    storage = supplied.get('ase_sqlite', {}) if isinstance(supplied, dict) else {}
    for key in ('path', 'json_sidecar_path'):
        if not storage.get(key):
            raise ValueError(f'Config must explicitly set ase_sqlite.{key}')
        location = Path(storage[key]).expanduser()
        if not location.is_absolute():
            location = config_path.parent / location
        location = location.resolve()
        config['ase_sqlite'][key] = str(location)
        if reading and not location.is_file():
            raise FileNotFoundError(f'Configured {key} does not exist: {location}')
    if not reading:
        exists = [Path(config['ase_sqlite'][key]).exists() for key in ('path', 'json_sidecar_path')]
        if any(exists) and not all(exists):
            raise ValueError('Database and sidecar must both exist, or both be new')
    return config, config_path


def available_fields(record: Any) -> dict:
    names = ('structure', 'energy', 'forces', 'stress', 'magmom', 'charge')
    return {'present': [name for name in names if getattr(record, name) is not None],
            'missing': [name for name in names if getattr(record, name) is None]}


def known_hubbard_u(record: Any) -> bool | None:
    if record.hubbard_u:
        return True
    for key in ('LDAU', 'ldau'):
        value = record.calculation_parameters.get(key)
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            if value.strip().lower() in ('true', '.true.', 't', '1', 'yes', 'y', 'on'):
                return True
            if value.strip().lower() in ('false', '.false.', 'f', '0', 'no', 'n', 'off'):
                return False
        if isinstance(value, (int, float)) and value in (0, 1):
            return bool(value)
    return None


def stored_details(record: Any) -> dict:
    details = record.to_dict()
    # aidb's ASE round trip drops unit fields; recover only recorded evidence.
    if record.stress is not None:
        details['stress_unit'] = record.provenance.get('normalized_stress_unit', record.stress_unit)
        details['stress_convention'] = record.provenance.get('normalized_stress_convention', record.stress_convention)
        if record.virial is not None and details['stress_unit'] == 'eV/Angstrom^3':
            details['virial_unit'] = 'eV'
    else:
        details['stress_unit'] = None
        details['stress_convention'] = None
    return details


@contextmanager
def database_lock(config: dict):
    """Serialize this adapter's readers/writers around aidb's SQLite + sidecar pair."""
    import fcntl
    path = Path(config['ase_sqlite']['json_sidecar_path'] + '.aidb_ops.lock')
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)


def summary(record: Any) -> dict:
    return {'record_id': record.record_id, 'formula': record.formula_reduced,
            'calculation_type': record.calculation_type,
            'method': {'functional': record.functional, 'has_hubbard_u': known_hubbard_u(record)},
            'data': available_fields(record),
            'source': {'dataset': record.source_dataset, 'id': record.source_id}}


STRING_FILTERS = {'record_id', 'formula', 'functional', 'calculation_type', 'source_dataset', 'source_id'}
BOOL_FILTERS = {'has_hubbard_u', 'has_forces', 'has_stress'}


def read_conditions(path: str) -> dict:
    from pymatgen.core import Composition, Element
    conditions = json.loads(Path(path).read_text(encoding='utf-8'))
    if not isinstance(conditions, dict):
        raise ValueError('Conditions must be a JSON object')
    unsupported = set(conditions) - STRING_FILTERS - BOOL_FILTERS - {'elements'}
    if unsupported:
        raise ValueError(f'Unsupported query conditions: {sorted(unsupported)}')
    effective = {key: value for key, value in conditions.items() if value is not None}
    if not effective:
        raise ValueError('At least one confirmed, non-null query condition is required')
    for key, value in effective.items():
        if key in STRING_FILTERS and (not isinstance(value, str) or not value.strip()):
            raise ValueError(f'{key} must be a nonempty string or null')
        if key in BOOL_FILTERS and not isinstance(value, bool):
            raise ValueError(f'{key} must be a boolean or null')
        if key == 'elements':
            if not isinstance(value, list) or not value or any(not isinstance(el, str) for el in value):
                raise ValueError('elements must be a nonempty array of element symbols or null')
            for element in value:
                Element(element)
        if key == 'formula':
            composition = Composition(value)
            if not composition.valid or any(amount <= 0 for amount in composition.values()):
                raise ValueError('formula must have valid elements and positive amounts')
    return conditions


def matches(record: Any, conditions: dict) -> bool:
    from pymatgen.core import Composition
    for key, value in conditions.items():
        if value is None:
            continue
        if key == 'formula':
            actual = Composition(record.composition).reduced_composition
            if actual != Composition(value).reduced_composition:
                return False
        elif key == 'elements':
            if not set(value).issubset(record.elements):
                return False
        elif key in ('has_forces', 'has_stress'):
            if (getattr(record, key[4:]) is not None) != value:
                return False
        elif key == 'has_hubbard_u':
            if known_hubbard_u(record) is not value:
                return False
        elif getattr(record, key) != value:
            return False
    return True


def query_records(args: argparse.Namespace, run: Path) -> dict:
    from ai_ready_db.ai_ready_db_Renaissance.local.local_workspace import LocalASEWorkspace
    conditions = read_conditions(args.conditions_json)
    config, config_path = workspace_config(args.config, reading=True)
    with database_lock(config):
        workspace = LocalASEWorkspace(config)
        if conditions.get('record_id'):
            record = workspace.get_record(conditions['record_id'])
            candidates = [record] if record is not None else []
        else:
            candidates = workspace.select_records({})
    matched = []
    for record in candidates:
        if matches(record, conditions):
            matched.append(record)
    details = run / 'records.jsonl'
    with details.open('w', encoding='utf-8') as handle:
        for record in matched:
            handle.write(json.dumps(stored_details(record), ensure_ascii=False, allow_nan=False) + '\n')
    report = {'status': 'query_complete', 'conditions': conditions,
              'scope': {'backend': 'local', 'database': config['ase_sqlite']['path'], 'namespaces': 'all'},
              'config_path': str(config_path), 'match_count': len(matched),
              'complete': True, 'details_path': str(details),
              'preview': [summary(record) for record in matched[:3]],
              'preview_truncated': len(matched) > 3}
    return report


def vasp_method(parameters: dict) -> str | None:
    if parameters.get('LHFCALC'):
        return 'hybrid'  # Preserve HFSCREEN/AEXX; do not guess HSE/PBE0 from incomplete settings.
    meta = parameters.get('METAGGA')
    if meta and str(meta).upper() not in ('--', 'NONE'):
        return str(meta)
    gga = parameters.get('GGA')
    return {'PE': 'PBE', 'PS': 'PBEsol', '91': 'PW91'}.get(str(gga),
        str(gga) if gga and gga != '--' else None)


def parse_final_record(folder: Path, source_id: str, dataset: str) -> tuple[Any, dict]:
    import numpy as np
    from monty.json import jsanitize
    from pymatgen.io.vasp.outputs import Vasprun
    from ai_ready_db.core.normalization import normalize_json_record
    from ai_ready_db.core.hashing import generate_record_id
    outputs = [path for name in ('vasprun.xml', 'vasprun.xml.gz') if (path := folder / name).is_file()]
    if len(outputs) != 1:
        raise ValueError('Calculation directory must contain exactly one vasprun.xml or vasprun.xml.gz')
    path = outputs[0]
    before_hash = hashlib.sha256(path.read_bytes()).hexdigest()
    parsed = Vasprun(path, parse_dos=False, parse_eigen=False, parse_potcar_file=False)
    if hashlib.sha256(path.read_bytes()).hexdigest() != before_hash:
        raise ValueError('VASP output changed while parsing; wait for the calculation to finish')
    convergence: dict[str, bool | None] = {'electronic': None, 'ionic': None}
    if parsed.ionic_steps:
        try:
            convergence = {'electronic': bool(parsed.converged_electronic), 'ionic': bool(parsed.converged_ionic)}
        except (KeyError, AttributeError, IndexError, TypeError):
            pass
    evidence = {'vasprun_path': str(path), 'sha256': before_hash, 'convergence': convergence}
    if not all(value is True for value in convergence.values()):
        return None, evidence
    last = parsed.ionic_steps[-1]
    parameters = jsanitize(dict(parsed.parameters), strict=True)
    parameters['LDAU'] = bool(parsed.is_hubbard)
    nsw, ibrion = parameters.get('NSW'), parameters.get('IBRION')
    calculation_type = ('static' if nsw == 0 or ibrion == -1 else
        'relaxation' if ibrion in (1, 2, 3) else 'molecular_dynamics' if ibrion == 0 else None)
    stress = last.get('stress')
    if stress is not None:
        # ASE's read_vasp_xml uses the same -0.1 GPa conversion from VASP kbar.
        stress = (-np.asarray(stress, dtype=float)).tolist()
    raw = {'source_id': source_id, 'structure': parsed.final_structure.as_dict(),
        'energy': float(parsed.final_energy) if 'e_0_energy' in last else None,
        'forces': jsanitize(last.get('forces'), strict=True), 'stress': stress,
        'stress_unit': 'kbar', 'stress_convention': 'tensile_positive',
        'functional': vasp_method(parameters), 'calculation_type': calculation_type,
        'calculation_parameters': parameters,
        'provenance': {'source_dataset': dataset, 'source_id': source_id,
            'input_stress_unit': 'kbar', 'input_stress_convention': 'vasp_compressive_positive',
            'stress_sign_conversion': -1},
        'source_metadata': {**evidence, 'software': 'VASP', 'version': parsed.vasp_version,
            'kpoints': jsanitize(parsed.kpoints.as_dict(), strict=True),
            'potcar_symbols': parsed.potcar_symbols}}
    record = normalize_json_record(raw, dataset)
    # aidb metadata detection can mistake inactive LDAUU arrays for active +U.
    record.hubbard_u = dict(parsed.hubbards) if parsed.is_hubbard else None
    record.record_id = generate_record_id(source_dataset=dataset, source_id=source_id,
        structure_hash=record.structure_hash, energy=record.energy, functional=record.functional,
        has_hubbard_u=record.has_hubbard_u, calculation_type=record.calculation_type)
    # Validate before any write, including optional non-finite or malformed results.
    json.dumps(record.to_dict(), allow_nan=False)
    if record.nsites < 1:
        raise ValueError('Final structure is empty')
    for key, shape in [('forces', (record.nsites, 3)), ('stress', (3, 3))]:
        value = getattr(record, key)
        if value is not None and np.asarray(value).shape != shape:
            raise ValueError(f'Invalid final {key} dimensions')
    return record, evidence


def insert_record(args: argparse.Namespace, run: Path) -> dict:
    from ai_ready_db.ai_ready_db_Renaissance.local.local_workspace import LocalASEWorkspace
    if not args.source_id.strip() or not args.source_dataset.strip():
        raise ValueError('source-id and source-dataset must be nonempty')
    config, config_path = workspace_config(args.config, reading=False)
    record, evidence = parse_final_record(Path(args.calculation_dir).expanduser().resolve(strict=True),
        args.source_id, args.source_dataset)
    if record is None:
        return {'status': 'not_stored', 'reason': 'Convergence was not confirmed', **evidence}
    namespace = ('bulk_dft_u_archive' if record.has_hubbard_u else
        'bulk_base_pbe' if record.functional == 'PBE' else 'fine_tune_working')
    intended_path = run / 'intended-record.json'
    write_json(intended_path, stored_details(record))
    # Keep a receipt before writing, so a failed write/readback can be investigated without retrying.
    write_json(run / 'write-attempt.json', {'record_id': record.record_id,
        'database': config['ase_sqlite']['path'], 'namespace': namespace,
        'intended_record_path': str(intended_path), 'storage_state': 'unknown_until_verified'})
    with database_lock(config):
        workspace = LocalASEWorkspace(config)
        record_id = workspace.write_record(record, namespace, 'local_calculation', 'local_only')
        stored = workspace.get_record(record_id)
        if stored is None:
            raise RuntimeError('Write returned but record ID could not be read back; do not retry automatically')
        expected = json.loads(json.dumps(stored_details(record), allow_nan=False))
        actual = stored_details(stored)
        for key in ('record_id', 'structure', 'energy', 'forces', 'stress', 'stress_unit', 'stress_convention',
                    'functional', 'hubbard_u', 'calculation_type', 'calculation_parameters',
                    'source_id', 'source_dataset', 'energy_per_atom', 'virial', 'magmom', 'charge', 'provenance'):
            if expected[key] != actual[key]:
                raise RuntimeError(f'Readback mismatch: {key}; stored state needs inspection, do not retry automatically')
        for key, value in expected['source_metadata'].items():
            if actual['source_metadata'].get(key) != value:
                raise RuntimeError(f'Readback metadata mismatch: {key}; do not retry automatically')
    details = run / 'record.json'
    write_json(details, actual)
    return {'status': 'insert_complete', 'record_id': record_id, 'readback_verified': True,
        'database': config['ase_sqlite']['path'], 'sidecar': config['ase_sqlite']['json_sidecar_path'],
        'config_path': str(config_path), 'namespace': namespace, 'details_path': str(details),
        'summary': summary(stored), **evidence}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', default=os.environ.get('AI_READY_DB_CONFIG'))
    parser.add_argument('--workspace', required=True)
    commands = parser.add_subparsers(dest='operation', required=True)
    query = commands.add_parser('query')
    query.add_argument('--conditions-json', required=True)
    insert = commands.add_parser('insert')
    insert.add_argument('--calculation-dir', required=True)
    insert.add_argument('--source-id', required=True)
    insert.add_argument('--source-dataset', default='local_dft')
    args = parser.parse_args()
    run = Path(args.workspace).expanduser().resolve() / '.aidb/runs' / uuid.uuid4().hex
    try:
        ensure_runtime()
        run.mkdir(parents=True, exist_ok=False)
        report = query_records(args, run) if args.operation == 'query' else insert_record(args, run)
        report_path = run / 'report.json'
        write_json(report_path, report)
        receipt = {key: report[key] for key in ('status', 'match_count', 'complete', 'details_path',
            'record_id', 'readback_verified', 'reason') if key in report}
        receipt['report_path'] = str(report_path)
        print(json.dumps(receipt, ensure_ascii=False))
        return 0
    except Exception as exc:
        error = {'status': 'error', 'operation': args.operation, 'error': type(exc).__name__, 'message': str(exc)}
        if run.is_dir():
            if (run / 'write-attempt.json').is_file():
                error['write_attempt_path'] = str(run / 'write-attempt.json')
            write_json(run / 'error.json', error)
            error['report_path'] = str(run / 'error.json')
        print(json.dumps(error, ensure_ascii=False))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
