#!/usr/bin/env python3
"""Refresh reviewed delivery hashes; original snapshot provenance is preserved."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    manifest_path = ROOT / "delivery/manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    paths = [
        ROOT / "delivery", ROOT / "src/matcreator/skills", ROOT / "tests/aidb/fixtures",
        ROOT / "script/install_aidb_handoff.py", ROOT / "script/check_aidb_handoff.py",
        ROOT / "script/start_aidb_handoff.sh", ROOT / "script/update_aidb_handoff_manifest.py",
        ROOT / "web/vite-frontend/package-lock.json", ROOT / "pyproject.toml",
    ]
    files = set()
    for path in paths:
        files.update(path.rglob("*") if path.is_dir() else [path])
    manifest["files"] = {
        path.relative_to(ROOT).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(files)
        if path.is_file() and path != manifest_path
        and not any(part in ("__pycache__", "build") or part.endswith(".egg-info") for part in path.parts)
        and path.suffix not in (".pyc", ".pyo")
    }
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Recorded {len(manifest['files'])} delivery files")


if __name__ == "__main__":
    main()
