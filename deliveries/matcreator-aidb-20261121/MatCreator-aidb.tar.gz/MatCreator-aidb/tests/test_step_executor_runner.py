import asyncio
import logging
from pathlib import Path

from matcreator.llm_cards import LLMCard
from matcreator.agents.execution_agent.step_executor import (
    StepExecutorInput,
    StepExecutorResult,
    build_step_executor_agent,
)
from matcreator.agents.execution_agent.step_executor_runner import (
    _artifact_allowed_roots,
    _build_step_content,
    _refresh_skill_registry_after_creation,
    _schedule_step_runner_cleanup,
    _verify_step_result_artifacts,
)
from matcreator.agents.execution_agent import step_executor_runner
from matcreator.agents.execution_graph_state import get_execution_graph, set_execution_graph
from matcreator.agents.session_log import SESSION_ARTIFACTS_KEY


def test_step_executor_registers_tracked_remote_job_tools() -> None:
    agent = build_step_executor_agent(LLMCard(name="test", model="test-model"))
    tool_names = {tool.name for tool in agent.tools if hasattr(tool, "name")}

    assert {
        "submit_bohr_sandbox",
        "submit_bohr_batchjob",
        "attach_bohr_batchjob",
        "get_remote_job_status",
        "run_remote_job_command",
        "start_remote_job_command",
        "poll_remote_job_command",
        "upload_remote_job_input",
        "download_remote_job_output",
        "collect_remote_job_outputs",
        "pause_remote_job",
        "terminate_remote_job",
    } <= tool_names
    assert "submit_e2b_sandbox" not in tool_names


class _FakeState:
    def __init__(self, data):
        self._data = data

    def to_dict(self):
        return self._data


def test_cancelled_runner_cleanup_is_scheduled_without_waiting():
    class FakeRunner:
        def __init__(self) -> None:
            self.closed = False
            self.closed_event = asyncio.Event()

        async def close(self) -> None:
            self.closed = True
            self.closed_event.set()

    async def exercise() -> None:
        release = asyncio.Event()

        async def slow_task() -> None:
            await release.wait()

        runner = FakeRunner()
        task = asyncio.create_task(slow_task())
        _schedule_step_runner_cleanup(runner, (task,))

        await asyncio.sleep(0)
        assert not runner.closed

        release.set()
        await asyncio.wait_for(runner.closed_event.wait(), timeout=1)
        assert runner.closed

    asyncio.run(exercise())


def test_success_with_missing_artifact_requires_replanning(tmp_path, caplog):
    existing_artifact = tmp_path / "result.txt"
    existing_artifact.write_text("ok", encoding="utf-8")
    missing_artifact = tmp_path / "missing.txt"

    result = StepExecutorResult(
        status="success",
        key_results="Generated result files.",
        concise_summary="Generated result files.",
        artifacts=[str(existing_artifact), str(missing_artifact)],
    )

    caplog.set_level(logging.WARNING)
    verified, missing_artifacts = _verify_step_result_artifacts(
        result,
        allowed_roots=[tmp_path],
    )

    assert verified.status == "needs_replanning"
    assert verified.artifacts == [str(existing_artifact)]
    assert missing_artifacts == [str(missing_artifact)]
    assert str(missing_artifact) in (verified.replan_reason or "")
    assert verified.concise_summary == verified.replan_reason
    assert verified.key_results == verified.replan_reason
    assert str(missing_artifact) in caplog.text
    assert "claimed artifact path(s)" in caplog.text


def test_success_with_missing_tool_plot_requires_replanning(tmp_path):
    result = StepExecutorResult(
        status="success",
        key_results="Generated a plot.",
        concise_summary="Generated a plot.",
    )
    missing_plot = tmp_path / "missing-plot.png"

    verified, missing_artifacts = _verify_step_result_artifacts(
        result,
        allowed_roots=[tmp_path],
        additional_artifacts=[str(missing_plot)],
    )

    assert verified.status == "needs_replanning"
    assert missing_artifacts == [str(missing_plot)]
    assert str(missing_plot) in (verified.replan_reason or "")


def test_success_accepts_existing_file_and_directory_artifacts(tmp_path):
    file_artifact = tmp_path / "result.txt"
    file_artifact.write_text("ok", encoding="utf-8")
    directory_artifact = tmp_path / "outputs"
    directory_artifact.mkdir()

    result = StepExecutorResult(
        status="success",
        key_results="Generated artifacts.",
        concise_summary="Generated artifacts.",
        artifacts=[str(file_artifact), str(directory_artifact)],
    )

    verified, missing_artifacts = _verify_step_result_artifacts(
        result,
        allowed_roots=[tmp_path],
    )

    assert verified.status == "success"
    assert verified.artifacts == [str(file_artifact), str(directory_artifact)]
    assert missing_artifacts == []


def test_nscf_step_success_depends_on_band_files_and_compute_not_archive(tmp_path):
    paths = [tmp_path / name for name in ("bands.json", "bands.svg")]
    for path in paths:
        path.write_text("verified output")
    completion = {
        "compute_status": "succeeded", "archive_status": "failed",
        "archive_reason": "database unavailable", "artifact_paths": list(map(str, paths)),
    }

    def step_result():
        return StepExecutorResult(status="success", concise_summary="Bands ready",
                                  key_results="Two band files", artifacts=list(map(str, paths)))

    result = step_result()
    step_executor_runner._apply_nscf_completion(result, completion, [tmp_path])
    assert result.status == "success"
    assert "database unavailable" in result.concise_summary

    failed = step_result()
    step_executor_runner._apply_nscf_completion(failed, {**completion, "compute_status": "unverified"}, [tmp_path])
    assert failed.status == "needs_replanning"

    paths[1].unlink()
    missing = step_result()
    step_executor_runner._apply_nscf_completion(missing, completion, [tmp_path])
    assert missing.status == "needs_replanning"


def test_skill_creation_success_refreshes_the_skill_registry(monkeypatch):
    expected = {"count": 42, "skills": ["new-skill"]}
    monkeypatch.setattr(
        "matcreator.skill.refresh_skills",
        lambda: expected,
    )

    assert _refresh_skill_registry_after_creation(["skill-creation"]) == {
        "status": "ok",
        **expected,
    }


def test_other_steps_do_not_refresh_the_skill_registry(monkeypatch):
    monkeypatch.setattr(
        "matcreator.skill.refresh_skills",
        lambda: pytest.fail("refresh should only run after skill creation"),
    )

    assert _refresh_skill_registry_after_creation(["structure-generation"]) is None


def test_relative_artifact_path_is_not_treated_as_verified(tmp_path, monkeypatch):
    relative_artifact = Path("result.txt")
    (tmp_path / relative_artifact).write_text("ok", encoding="utf-8")
    monkeypatch.chdir(tmp_path)

    result = StepExecutorResult(
        status="success",
        key_results="Generated artifact.",
        concise_summary="Generated artifact.",
        artifacts=[str(relative_artifact)],
    )

    verified, missing_artifacts = _verify_step_result_artifacts(
        result,
        allowed_roots=[tmp_path],
    )

    assert verified.status == "needs_replanning"
    assert verified.artifacts == []
    assert missing_artifacts == [str(relative_artifact)]


def test_existing_artifact_outside_allowed_roots_requires_replanning(tmp_path):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    outside_artifact = tmp_path / "outside.txt"
    outside_artifact.write_text("not from this step", encoding="utf-8")

    result = StepExecutorResult(
        status="success",
        key_results="Generated artifact.",
        concise_summary="Generated artifact.",
        artifacts=[str(outside_artifact)],
    )

    verified, missing_artifacts = _verify_step_result_artifacts(
        result,
        allowed_roots=[workspace],
    )

    assert verified.status == "needs_replanning"
    assert verified.artifacts == []
    assert missing_artifacts == [str(outside_artifact)]


def test_output_dir_constrains_artifacts_without_restricting_workspace_access(tmp_path):
    workspace = tmp_path / "workspace"
    output_dir = workspace / "case_001"
    output_dir.mkdir(parents=True)
    shared_artifact = workspace / "shared.txt"
    shared_artifact.write_text("readable shared file, but not a valid output", encoding="utf-8")
    output_artifact = output_dir / "result.txt"
    output_artifact.write_text("valid output", encoding="utf-8")

    result = StepExecutorResult(
        status="success",
        key_results="Generated artifacts.",
        concise_summary="Generated artifacts.",
        artifacts=[str(shared_artifact), str(output_artifact)],
    )

    verified, missing_artifacts = _verify_step_result_artifacts(
        result,
        allowed_roots=_artifact_allowed_roots(workspace, [], output_dir),
    )

    assert verified.status == "needs_replanning"
    assert verified.artifacts == [str(output_artifact)]
    assert missing_artifacts == [str(shared_artifact)]


def test_multimodal_card_attaches_referenced_image_to_step_content(tmp_path):
    image_path = tmp_path / "plot.png"
    image_path.write_bytes(b"\x89PNG\r\n\x1a\n")
    step_input = StepExecutorInput(
        step_number=1,
        action=f"Analyze the image at {image_path}",
        suggested_skills=["plot"],
        workspace_dir=str(tmp_path),
    )

    content, input_images = _build_step_content(
        step_input,
        llm_card=LLMCard(
            name="vision",
            model="openai/vision-model",
            modalities=("text", "image"),
        ),
        workspace_dir=tmp_path,
        state={},
    )

    assert input_images == [str(image_path)]
    assert len(content.parts) == 2
    assert content.parts[1].inline_data.mime_type == "image/png"


def test_text_only_card_does_not_attach_referenced_image(tmp_path):
    image_path = tmp_path / "plot.png"
    image_path.write_bytes(b"\x89PNG\r\n\x1a\n")
    step_input = StepExecutorInput(
        step_number=1,
        action=f"Analyze the image at {image_path}",
        suggested_skills=["plot"],
        workspace_dir=str(tmp_path),
    )

    content, input_images = _build_step_content(
        step_input,
        llm_card=LLMCard(name="text", model="openai/text-model"),
        workspace_dir=tmp_path,
        state={},
    )

    assert input_images == []
    assert len(content.parts) == 1


def test_multimodal_card_can_attach_session_image_artifact_when_image_requested(tmp_path):
    image_path = tmp_path / "previous_plot.png"
    image_path.write_bytes(b"\x89PNG\r\n\x1a\n")
    step_input = StepExecutorInput(
        step_number=1,
        action="Analyze the previous plot.",
        suggested_skills=["plot"],
        workspace_dir=str(tmp_path),
    )

    content, input_images = _build_step_content(
        step_input,
        llm_card=LLMCard(
            name="vision",
            model="openai/vision-model",
            tags=("vision",),
        ),
        workspace_dir=tmp_path,
        state={SESSION_ARTIFACTS_KEY: [str(image_path)]},
    )

    assert input_images == [str(image_path)]
    assert len(content.parts) == 2


def test_multimodal_card_accepts_adk_state_object_for_session_image_artifacts(tmp_path):
    image_path = tmp_path / "previous_plot.png"
    image_path.write_bytes(b"\x89PNG\r\n\x1a\n")
    step_input = StepExecutorInput(
        step_number=1,
        action="Describe the previous image.",
        suggested_skills=["plot"],
        workspace_dir=str(tmp_path),
    )

    content, input_images = _build_step_content(
        step_input,
        llm_card=LLMCard(
            name="vision",
            model="openai/vision-model",
            modalities=("text", "image"),
        ),
        workspace_dir=tmp_path,
        state=_FakeState({SESSION_ARTIFACTS_KEY: [str(image_path)]}),
    )

    assert input_images == [str(image_path)]
    assert len(content.parts) == 2


def test_step_executor_retries_only_malformed_streamed_tool_arguments():
    agent = build_step_executor_agent(LLMCard(name="test", model="openai/test"))

    assert agent.retry_config is not None
    assert agent.retry_config.max_attempts == 2
    assert agent.retry_config.exceptions == ["JSONDecodeError"]


# ---------------------------------------------------------------------------
# Remote-job handoff on timeout
# ---------------------------------------------------------------------------


class _MutableState(dict):
    """Minimal stand-in for ADK session state used by the graph state helpers."""


class _FakeToolContext:
    def __init__(self, state):
        self.state = state


def _run_await_step_completion(monkeypatch, *, remote_job, grace, hold=0.2):
    monkeypatch.setattr(step_executor_runner, "_SUB_STEP_TIMEOUT", 0.01)
    monkeypatch.setattr(step_executor_runner, "_REMOTE_JOB_GRACE_TIMEOUT", grace)
    monkeypatch.setattr(
        step_executor_runner,
        "active_remote_job_for_attempt",
        lambda attempt: remote_job,
    )

    async def exercise():
        async def slow_task():
            await asyncio.sleep(hold)
            return ({}, [], [], {})

        task = asyncio.create_task(slow_task())
        try:
            return await step_executor_runner._await_step_completion(
                task, {}, step_number=1, session_id="session-1"
            )
        finally:
            task.cancel()

    return asyncio.run(exercise())


def test_timeout_without_remote_job_is_a_plain_timeout(monkeypatch):
    timed_out, remote_job = _run_await_step_completion(
        monkeypatch, remote_job=None, grace=5
    )

    assert timed_out is True
    assert remote_job is None


def test_timeout_with_active_remote_job_reports_it_after_one_grace_window(monkeypatch):
    job = {"job_id": "job-1", "provider": "e2b", "external_id": "sbx-1", "status": "running"}

    timed_out, remote_job = _run_await_step_completion(
        monkeypatch, remote_job=job, grace=0.01
    )

    assert timed_out is True
    assert remote_job == job


def test_grace_window_lets_a_nearly_finished_step_complete(monkeypatch):
    job = {"job_id": "job-1", "provider": "e2b", "external_id": "sbx-1", "status": "running"}

    timed_out, remote_job = _run_await_step_completion(
        monkeypatch, remote_job=job, grace=5, hold=0.05
    )

    assert timed_out is False
    assert remote_job is None


def test_waiting_handoff_records_remote_job_on_the_graph_node():
    state = _MutableState()
    set_execution_graph(state, {"nodes": {"step_train": {"status": "running"}}, "edges": []})
    tool_context = _FakeToolContext(state)
    job = {"job_id": "job-1", "provider": "e2b", "external_id": "sbx-1", "status": "running"}

    step_executor_runner._mark_node_waiting_on_remote_job(
        tool_context,
        node_id="step_train",
        remote_job=job,
        summary="Executor released; job still running.",
    )

    node = get_execution_graph(state)["nodes"]["step_train"]
    assert node["status"] == "waiting"
    assert node["remote_job"] == job
    assert node["recovery"]["status"] == "waiting_remote"


def test_resumed_node_receives_explicit_reattachment_instructions():
    state = _MutableState()
    set_execution_graph(state, {
        "nodes": {
            "step_train": {
                "status": "pending",
                "remote_job": {
                    "job_id": "job-1",
                    "provider": "e2b",
                    "external_id": "sbx-1",
                    "status": "running",
                },
            }
        },
        "edges": [],
    })

    context = step_executor_runner._remote_job_prior_context(
        _FakeToolContext(state), "step_train"
    )

    assert context is not None
    assert "job-1" in context
    assert "sbx-1" in context
    assert "get_remote_job_status" in context
    assert "Do NOT call submit_bohr_sandbox" in context


def test_node_without_remote_job_gets_no_reattachment_instructions():
    state = _MutableState()
    set_execution_graph(state, {"nodes": {"step_train": {"status": "pending"}}, "edges": []})

    assert step_executor_runner._remote_job_prior_context(
        _FakeToolContext(state), "step_train"
    ) is None
