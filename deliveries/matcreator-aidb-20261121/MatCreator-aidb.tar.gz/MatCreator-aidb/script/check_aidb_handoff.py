#!/usr/bin/env python3
"""Check installed paths and archive/query/export a real fixture in a temporary DB."""
from __future__ import annotations

import json
import hashlib
import os
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "script"))
from install_aidb_handoff import verify_bundle


def main():
    verify_bundle()
    required = ("MATCREATOR_HOME", "MATCLAW_WORKSPACE", "AI_READY_DB_ROOT", "AI_READY_DB_PYTHON")
    if any(not os.environ.get(key) for key in required):
        raise RuntimeError("请先 source 安装程序打印的 env.sh")
    from ase.db import connect
    from ase.io import read
    from io import StringIO
    import numpy as np
    from matcreator.config import apply_config_env_overrides
    apply_config_env_overrides()
    from matcreator.skill import get_skill_source, _skill_dir_map, is_skill_disabled
    from matcreator.aidb.service import SessionAIDB, InstalledSkillQuery
    from matcreator.aidb.archive import archive_vasp_result
    from matcreator.aidb.exports import export_record
    import matcreator
    import ai_ready_db
    expected = Path(os.environ["MATCREATOR_HOME"]) / "skills/ai-ready-db"
    actual = _skill_dir_map().get("ai-ready-db")
    if actual != expected or actual.is_symlink():
        raise RuntimeError(f"skill 加载位置不符合交付配置：{actual}，预期 {expected}")
    bundled = ROOT / "delivery/skills/ai-ready-db"
    for original in bundled.rglob("*"):
        if original.is_file() and "__pycache__" not in original.parts:
            installed = actual / original.relative_to(bundled)
            if not installed.is_file() or hashlib.sha256(installed.read_bytes()).digest() != hashlib.sha256(original.read_bytes()).digest():
                raise RuntimeError(f"已安装 skill 与本交付不同：{installed}")
    if is_skill_disabled("ai-ready-db"):
        raise RuntimeError("ai-ready-db 在当前知识图谱中已停用，请在设置中启用")
    if not Path(matcreator.__file__).resolve().is_relative_to(ROOT / "src"):
        raise RuntimeError("正在加载另一个 MatCreator 版本")
    if not Path(ai_ready_db.__file__).resolve().is_relative_to(ROOT / "delivery/vendor/ai-ready-db"):
        raise RuntimeError("正在加载交付之外的 AIDB 包")
    print(f"MatCreator: {matcreator.__file__}")
    print(f"AIDB: {ai_ready_db.__file__}")
    print(f"skill: {actual} ({get_skill_source('ai-ready-db').name})")
    # Every run uses a new directory; the recipient's material database is untouched.
    with tempfile.TemporaryDirectory(prefix="matcreator-handoff-check-") as temporary:
        root = Path(temporary)
        db = root / "archive.db"
        sidecar = root / "archive.sidecar.json"
        with connect(str(db)) as database:
            database.count()
        sidecar.write_text('{"records": {}}', encoding="utf-8")
        config = root / "config.json"
        config.write_text(json.dumps({"database": {"backend": "ase_sqlite"}, "ase_sqlite": {
            "path": str(db), "json_sidecar_path": str(sidecar), "max_query_keys_per_row": 64,
        }}), encoding="utf-8")
        import shutil
        workspace = root / "workspace"
        shutil.copytree(ROOT / "tests/aidb/fixtures/vasp/si-pbe-relax", workspace / "si")
        session = SessionAIDB(workspace, "handoff-check", query_database=InstalledSkillQuery())
        session.bind(config)
        assert session.query({"formula": "Si"})["matched_count"] == 0
        saved = archive_vasp_result(session, "si")
        assert saved["status"] == "saved" and saved["readback_verified"], saved
        again = archive_vasp_result(session, "si")
        assert again["status"] == "existing" and again["record_id"] == saved["record_id"], again
        result = session.query({"formula": "Si", "functional": "PBE", "has_forces": True})
        assert result["matched_count"] == 1, result
        record = session.detail(saved["record_id"])["record"]
        files, errors = export_record(record, ("extxyz", "poscar", "html"))
        assert not errors, errors
        # Read the real exported bytes through ASE independently.
        xyz = files["extxyz"]["content"]
        frame = read(StringIO(xyz), format="extxyz")
        assert len(frame) == 8 and frame.get_forces().shape == (8, 3)
        assert np.isclose(frame.get_potential_energy(), -43.38227814, rtol=0, atol=1e-8)
        print(f"PASS: 空库、归档、重复归档、查询、按 ID 读回、EXTXYZ/POSCAR/HTML 导出；record={saved['record_id']}")
    print("此自检不调用模型、不提交 VASP；正常 Web 对话请按 docs/aidb-handoff.md 验收。")


if __name__ == "__main__":
    main()
