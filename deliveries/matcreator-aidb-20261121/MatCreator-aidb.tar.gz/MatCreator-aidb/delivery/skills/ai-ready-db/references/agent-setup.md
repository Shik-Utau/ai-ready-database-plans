# 独立安装目录的环境与更新

本版独立维护于 `${MATCREATOR_HOME:-$HOME/.matcreator}/skills/ai-ready-db/`。
Ai-ready_Database 提供代码库及运行环境；不要从该项目的 skills/ai-ready-db 整包覆盖或合并本目录。

## 环境

本版脚本沿用 aidb_client 的环境发现：默认查找常规位置 `$HOME/projects/Ai-ready_Database` 及其 .venv。
项目位于其他位置时，在启动 MatCreator 的环境中配置：

```bash
export AI_READY_DB_ROOT=/absolute/path/to/Ai-ready_Database
export AI_READY_DB_PYTHON=/absolute/path/to/Ai-ready_Database/.venv/bin/python
export AI_READY_DB_CONFIG=/absolute/path/to/local.yaml
```

也可使用现有 `templates/bridge_config.example.json` 配置代码库位置；不提交机器专用配置或凭据。
aidb Python 环境需能导入 ai_ready_db、ASE、pymatgen、numpy、PyYAML、monty；沿用项目已有依赖管理，不在普通查库任务里重装环境。
MatCreator 工具先以 `python` 启动脚本，脚本再进入 aidb 解释器；若宿主没有可用 python 命令，报告宿主执行配置问题。

配置必须显式包含 SQLite 与 sidecar 的路径。建议使用绝对路径，避免配置文件目录与原 CLI 工作目录的相对路径解释不同。
详细输入和例子在 [接口约定](interface-contract.md)；正常操作使用 aidb_ops.py 的 query/insert。

## 更新与生效

1. 备份当前安装文件，备份放在 skills 扫描目录之外，避免同名 skill 被重复发现。
2. 只应用经审查的本版改动，保留机器专用配置；禁止以数据库项目内 skill 代替本版。
3. 运行 [验收清单](acceptance-plan.md) 中的隔离测试，核对实际加载路径。
4. 运行中的 MatCreator 可用 refresh_skills 工具刷新；独立 Python 进程中的刷新不会更新已有服务进程。不要为了更新 skill 清空知识图谱。

本交付的发布源位于 MatCreator 仓库 `delivery/skills/ai-ready-db/`，原始与交付哈希见 `delivery/manifest.json`。安装和自检见仓库 `docs/aidb-handoff.md`。运行目录中的 skill 改动须同步回发布源后提交；用 `python3 script/update_aidb_handoff_manifest.py` 更新经确认的发布文件哈希。
旧桥接脚本及模板保留作兼容诊断，其 preflight / archive-and-requery 不属于本版默认工作流。
