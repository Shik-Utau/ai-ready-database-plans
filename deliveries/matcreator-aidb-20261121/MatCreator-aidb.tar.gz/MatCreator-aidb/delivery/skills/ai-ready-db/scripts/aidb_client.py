#!/usr/bin/env python3
"""Portable stdlib-only client for the local ai-ready-db bridge.

The client runs in MatCreator's Python environment. It discovers the aidb
checkout, starts ``aidb_server.py`` with aidb's Python, then forwards one CLI
request over a user-scoped Unix socket. No developer path is baked in.
"""

from __future__ import annotations

import fcntl
import errno
import hashlib
import importlib.util
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Mapping


SKILL_ROOT = Path(__file__).resolve().parents[1]
SERVER_SCRIPT = Path(__file__).with_name("aidb_server.py")
DEFAULT_TIMEOUT = 300.0
DEFAULT_STARTUP_TIMEOUT = 60.0
MAX_RESPONSE_BYTES = 64 * 1024 * 1024


class BridgeConfigurationError(RuntimeError):
    """The bridge cannot locate a usable aidb installation."""


def _is_aidb_root(path: Path) -> bool:
    return (path / "ai_ready_db" / "cli.py").is_file() and (
        (path / "pyproject.toml").is_file() or (path / "configs").is_dir()
    )


def _candidate_roots(
    env: Mapping[str, str], cwd: Path, skill_root: Path
) -> list[Path]:
    candidates: list[Path] = []
    config_path = Path(
        env.get("AI_READY_DB_BRIDGE_CONFIG", skill_root / "bridge_config.json")
    ).expanduser()
    if config_path.is_file():
        try:
            payload = json.loads(config_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise BridgeConfigurationError(
                f"invalid bridge config {config_path}: {exc}"
            ) from exc
        configured_root = payload.get("aidb_root")
        if configured_root:
            candidates.append(Path(str(configured_root)).expanduser())

    for anchor in (cwd, skill_root):
        candidates.extend((anchor, *anchor.parents))

    matcreator_home = Path(
        env.get("MATCREATOR_HOME", str(Path.home() / ".matcreator"))
    ).expanduser()
    candidates.extend(
        [
            matcreator_home.parent / "projects" / "Ai-ready_Database",
            Path.home() / "projects" / "Ai-ready_Database",
            Path.home() / "Ai-ready_Database",
        ]
    )
    try:
        spec = importlib.util.find_spec("ai_ready_db")
    except (ImportError, ModuleNotFoundError, ValueError):
        spec = None
    if spec and spec.origin:
        candidates.append(Path(spec.origin).resolve().parent.parent)
    return candidates


def discover_aidb_root(
    env: Mapping[str, str] | None = None,
    cwd: Path | None = None,
    skill_root: Path | None = None,
) -> Path:
    """Resolve the aidb checkout without a developer-specific absolute path."""

    env = env or os.environ
    cwd = (cwd or Path.cwd()).resolve()
    skill_root = (skill_root or SKILL_ROOT).resolve()
    explicit = env.get("AI_READY_DB_ROOT", "").strip()
    if explicit:
        root = Path(explicit).expanduser().resolve()
        if not _is_aidb_root(root):
            raise BridgeConfigurationError(
                f"AI_READY_DB_ROOT is not an ai-ready-db checkout: {root}"
            )
        return root

    seen: set[Path] = set()
    for candidate in _candidate_roots(env, cwd, skill_root):
        try:
            resolved = candidate.expanduser().resolve()
        except OSError:
            continue
        if resolved in seen:
            continue
        seen.add(resolved)
        if _is_aidb_root(resolved):
            return resolved
    raise BridgeConfigurationError(
        "ai-ready-db checkout not found; set AI_READY_DB_ROOT or create "
        f"{skill_root / 'bridge_config.json'} from bridge_config.example.json"
    )


def _python_can_import(python: Path, root: Path) -> bool:
    try:
        result = subprocess.run(
            [str(python), "-c", "import ai_ready_db, ase, yaml"],
            cwd=root,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=15,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    return result.returncode == 0


def discover_aidb_python(
    root: Path, env: Mapping[str, str] | None = None
) -> Path:
    """Find a Python interpreter that can import aidb and its core runtime."""

    env = env or os.environ
    explicit = env.get("AI_READY_DB_PYTHON", "").strip()
    if explicit:
        # Do not resolve a virtualenv interpreter symlink: executing the
        # resolved base interpreter loses the virtualenv's site-packages.
        python = Path(os.path.abspath(Path(explicit).expanduser()))
        if not python.is_file():
            raise BridgeConfigurationError(
                f"AI_READY_DB_PYTHON does not exist: {python}"
            )
        if not _python_can_import(python, root):
            raise BridgeConfigurationError(
                f"AI_READY_DB_PYTHON cannot import ai_ready_db runtime: {python}"
            )
        return python

    candidates = [
        root / ".venv" / "bin" / "python",
        root / ".venv" / "Scripts" / "python.exe",
        Path(sys.executable),
    ]
    for executable in ("python3", "python"):
        found = shutil.which(executable)
        if found:
            candidates.append(Path(found))

    seen: set[Path] = set()
    for candidate in candidates:
        try:
            resolved = Path(os.path.abspath(candidate.expanduser()))
        except OSError:
            continue
        if resolved in seen or not resolved.is_file():
            continue
        seen.add(resolved)
        if _python_can_import(resolved, root):
            return resolved
    raise BridgeConfigurationError(
        f"no Python can import ai_ready_db under {root}; set AI_READY_DB_PYTHON"
    )


def bridge_paths(
    root: Path, env: Mapping[str, str] | None = None
) -> tuple[Path, Path, Path]:
    """Return socket, lock and log paths scoped to this aidb checkout."""

    env = env or os.environ
    explicit = env.get("AI_READY_DB_BRIDGE_SOCK", "").strip()
    if explicit:
        sock = Path(explicit).expanduser()
    else:
        scope = env.get("MATCREATOR_USER_ID") or env.get("USER") or "local"
        digest = hashlib.sha256(f"{root}:{scope}".encode()).hexdigest()[:12]
        sock = Path(tempfile.gettempdir()) / f"aidb_{os.getuid()}_{digest}.sock"
    lock = Path(env.get("AI_READY_DB_BRIDGE_LOCK", f"{sock}.lock")).expanduser()
    log = Path(env.get("AI_READY_DB_BRIDGE_LOG", f"{sock}.log")).expanduser()
    return sock, lock, log


def _sock_alive(sock_path: Path) -> bool:
    probe = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    probe.settimeout(0.5)
    try:
        probe.connect(str(sock_path))
        return True
    except OSError:
        return False
    finally:
        probe.close()


def _connect_with_retry(sock_path: Path, timeout: float) -> socket.socket:
    deadline = time.monotonic() + timeout
    transient = {errno.EAGAIN, errno.ECONNREFUSED, errno.ENOENT}
    while True:
        conn = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            conn.close()
            raise socket.timeout(f"timed out connecting to {sock_path}")
        conn.settimeout(min(1.0, remaining))
        try:
            conn.connect(str(sock_path))
            conn.settimeout(max(0.1, deadline - time.monotonic()))
            return conn
        except socket.timeout:
            conn.close()
        except OSError as exc:
            conn.close()
            if exc.errno not in transient:
                raise
        time.sleep(min(0.05, max(0.0, deadline - time.monotonic())))


def request(sock_path: Path, argv: list[str], timeout: float) -> dict:
    conn = _connect_with_retry(sock_path, timeout)
    try:
        conn.sendall((json.dumps({"argv": argv}) + "\n").encode())
        chunks: list[bytes] = []
        size = 0
        while True:
            chunk = conn.recv(65536)
            if not chunk:
                break
            chunks.append(chunk)
            size += len(chunk)
            if size > MAX_RESPONSE_BYTES:
                raise RuntimeError(
                    f"bridge response exceeds {MAX_RESPONSE_BYTES} bytes"
                )
            if chunk.endswith(b"\n"):
                break
    finally:
        conn.close()
    raw = b"".join(chunks)
    if not raw:
        raise RuntimeError("bridge closed connection without a response")
    try:
        reply = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"bridge returned invalid JSON: {exc}") from exc
    if not isinstance(reply, dict):
        raise RuntimeError("bridge response must be a JSON object")
    return reply


def _log_tail(log_path: Path, limit: int = 4000) -> str:
    try:
        text = log_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    return text[-limit:]


def _spawn_server(
    root: Path,
    python: Path,
    sock_path: Path,
    log_path: Path,
    env: Mapping[str, str],
) -> None:
    sock_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    sock_path.unlink(missing_ok=True)
    server_env = {
        **env,
        "AI_READY_DB_ROOT": str(root),
        "AI_READY_DB_BRIDGE_SOCK": str(sock_path),
    }
    with log_path.open("ab") as log_handle:
        proc = subprocess.Popen(
            [str(python), str(SERVER_SCRIPT)],
            cwd=root,
            start_new_session=True,
            stdout=log_handle,
            stderr=log_handle,
            env=server_env,
        )
    startup_timeout = float(
        env.get("AI_READY_DB_BRIDGE_STARTUP_TIMEOUT", DEFAULT_STARTUP_TIMEOUT)
    )
    deadline = time.monotonic() + startup_timeout
    while time.monotonic() < deadline:
        if _sock_alive(sock_path):
            return
        if proc.poll() is not None:
            raise RuntimeError(
                f"bridge server exited with code {proc.returncode}: "
                f"{_log_tail(log_path)}"
            )
        time.sleep(0.1)
    raise TimeoutError(
        f"bridge server failed to start within {startup_timeout}s: "
        f"{_log_tail(log_path)}"
    )


def ensure_server(
    root: Path,
    python: Path | None,
    sock_path: Path,
    lock_path: Path,
    log_path: Path,
    env: Mapping[str, str] | None = None,
) -> None:
    env = env or os.environ
    if _sock_alive(sock_path):
        return
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("w", encoding="utf-8") as lock_handle:
        fcntl.flock(lock_handle, fcntl.LOCK_EX)
        if not _sock_alive(sock_path):
            # Discover the runtime only for the single lock holder that will
            # actually start the server. Under a 100-client cold burst this
            # avoids 100 simultaneous Python import probes.
            python = python or discover_aidb_python(root, env=env)
            _spawn_server(root, python, sock_path, log_path, env)


def bridge_info(env: Mapping[str, str] | None = None) -> dict:
    env = env or os.environ
    root = discover_aidb_root(env=env)
    python = discover_aidb_python(root, env=env)
    sock, lock, log = bridge_paths(root, env=env)
    return {
        "ok": True,
        "aidb_root": str(root),
        "aidb_python": str(python),
        "socket_path": str(sock),
        "lock_path": str(lock),
        "log_path": str(log),
        "server_alive": _sock_alive(sock),
    }


def _print_error(kind: str, exc: BaseException, **extra: object) -> None:
    print(
        json.dumps(
            {"ok": False, "error": kind, "detail": str(exc), **extra},
            sort_keys=True,
        ),
        file=sys.stderr,
    )


def main() -> int:
    argv = sys.argv[1:]
    try:
        if argv == ["bridge-info"]:
            print(json.dumps(bridge_info(), indent=2, sort_keys=True))
            return 0
        if not argv:
            raise ValueError("an aidb CLI subcommand is required")
        root = discover_aidb_root()
        sock, lock, log = bridge_paths(root)
        ensure_server(root, None, sock, lock, log)
        timeout = float(os.environ.get("AI_READY_DB_BRIDGE_TIMEOUT", DEFAULT_TIMEOUT))
        reply = request(sock, argv, timeout)
    except BridgeConfigurationError as exc:
        _print_error("configuration_error", exc)
        return 2
    except socket.timeout as exc:
        _print_error(
            "timeout",
            exc,
            timeout_s=float(
                os.environ.get("AI_READY_DB_BRIDGE_TIMEOUT", DEFAULT_TIMEOUT)
            ),
            note="the serial bridge may still be executing this request",
        )
        return 1
    except (ConnectionRefusedError, FileNotFoundError, TimeoutError, OSError) as exc:
        _print_error("bridge_unavailable", exc)
        return 1
    except (RuntimeError, ValueError, json.JSONDecodeError) as exc:
        _print_error("protocol_error", exc)
        return 1

    stdout = reply.get("stdout", "")
    stderr = reply.get("stderr", "")
    if not isinstance(stdout, str) or not isinstance(stderr, str):
        _print_error("protocol_error", RuntimeError("stdout/stderr must be strings"))
        return 1
    sys.stdout.write(stdout)
    if stderr:
        sys.stderr.write(stderr)
    try:
        return int(reply.get("returncode", 1))
    except (TypeError, ValueError):
        _print_error("protocol_error", RuntimeError("invalid returncode"))
        return 1


if __name__ == "__main__":
    sys.exit(main())
