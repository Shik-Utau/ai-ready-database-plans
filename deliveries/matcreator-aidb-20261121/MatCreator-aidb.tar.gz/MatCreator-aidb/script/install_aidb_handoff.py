#!/usr/bin/env python3
"""Install the pinned AIDB delivery into an independent Linux/WSL runtime."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
DELIVERY = ROOT / "delivery"


def verify_bundle():
    manifest = json.loads((DELIVERY / "manifest.json").read_text(encoding="utf-8"))
    for name, expected in manifest["files"].items():
        path = ROOT / name
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise RuntimeError(f"交付文件缺失或已改变：{name}")
    if not manifest["files"]:
        raise RuntimeError("交付文件清单为空")
    return manifest


def run(*args, **kwargs):
    subprocess.run([str(value) for value in args], check=True, **kwargs)


def initialize(runtime: Path, *, python: Path):
    """Prepare paths and copy a real skill directory (rglob ignores symlink bundles)."""
    from ase.db import connect
    import yaml

    runtime.mkdir(parents=True, exist_ok=True)
    home = runtime / "home"
    workspace = runtime / "workspace"
    home.mkdir(exist_ok=True)
    workspace.mkdir(exist_ok=True)
    target = home / "skills/ai-ready-db"
    source = DELIVERY / "skills/ai-ready-db"
    if target.exists() or target.is_symlink():
        same = not target.is_symlink() and {
            p.relative_to(target).as_posix(): p.read_bytes()
            for p in target.rglob("*") if p.is_file() and "__pycache__" not in p.parts
        } == {p.relative_to(source).as_posix(): p.read_bytes() for p in source.rglob("*") if p.is_file()}
        if not same:
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
            backup = runtime / "backups" / stamp / "ai-ready-db"
            backup.parent.mkdir(parents=True)
            target.rename(backup)
            print(f"旧 skill 已备份到扫描目录之外：{backup}")
    if not target.exists():
        shutil.copytree(source, target)

    database = runtime / "data/archive.db"
    database.parent.mkdir(exist_ok=True)
    sidecar = database.with_suffix(".sidecar.json")
    config = runtime / "aidb-config.json"
    # Rerunning installation must not reset an existing database or sidecar.
    if database.exists() != sidecar.exists():
        raise RuntimeError("数据库与 sidecar 只存在一个，请先核对 data/，安装不会重建缺失文件")
    if not database.exists():
        with connect(str(database)) as db:
            db.count()
        sidecar.write_text('{"records": {}}\n', encoding="utf-8")
    if not config.exists():
        config.write_text(json.dumps({
            "database": {"backend": "ase_sqlite"},
            "ase_sqlite": {"path": str(database), "json_sidecar_path": str(sidecar),
                           "max_query_keys_per_row": 64},
        }, indent=2) + "\n", encoding="utf-8")
    user_config = home / "config.yaml"
    if not user_config.exists():
        user_config.write_text(yaml.safe_dump({
            "llm": {"model": "openai/REPLACE_WITH_YOUR_MODEL", "api_key": "", "base_url": ""},
            "workspace": {"default_workdir": str(workspace)},
            "ports": {"adk": 8100, "web": 8101, "frontend": 5174},
            "env": {"AI_READY_DB_CONFIG": str(config)},
        }, allow_unicode=True, sort_keys=False), encoding="utf-8")
        user_config.chmod(0o600)

    fixture = ROOT / "tests/aidb/fixtures/vasp/si-pbe-relax"
    sample = workspace / "aidb-demo/si-pbe-relax"
    if not sample.exists():
        sample.mkdir(parents=True)
        for name in ("vasprun.xml", "OUTCAR", "INCAR", "KPOINTS"):
            shutil.copy2(fixture / name, sample / name)

    variables = {
        "MATCREATOR_HOME": home,
        "MATCREATOR_CONFIG_PATH": user_config,
        "MATCLAW_WORKSPACE": workspace,
        "MATCREATOR_MODULE_SKILLS_ROOT": ROOT / "src/matcreator/skills",
        "AI_READY_DB_ROOT": DELIVERY / "vendor/ai-ready-db",
        "AI_READY_DB_PYTHON": python,
        "AI_READY_DB_CONFIG": config,
        "MATCREATOR_MODE": "local",
        "MATCREATOR_ADK_HOST": "127.0.0.1",
        "MATCREATOR_WEB_HOST": "127.0.0.1",
        "MATCREATOR_FRONTEND_HOST": "127.0.0.1",
        "LITELLM_LOCAL_MODEL_COST_MAP": "True",
    }
    lines = ["# Generated for this checkout and runtime; source this file in Bash.",
             f"source {shlex.quote(str(python.parent / 'activate'))}"]
    lines += [f"export {key}={shlex.quote(str(value))}" for key, value in variables.items()]
    lines.append(f"export PYTHONPATH={shlex.quote(str(ROOT / 'src'))}")
    (runtime / "env.sh").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return variables


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime", type=Path, default=ROOT / ".handoff")
    args = parser.parse_args()
    if sys.platform != "linux":
        parser.error("请在 Linux 或 WSL 中运行；AIDB skill 使用 fcntl / Unix socket")
    verify_bundle()
    runtime = args.runtime.expanduser().absolute()
    if runtime == ROOT or runtime == Path.home() or runtime == Path("/"):
        parser.error("--runtime 必须是独立的运行目录")
    for executable in ("uv", "node", "npm", "git"):
        if shutil.which(executable) is None:
            parser.error(f"缺少 {executable}，请按 docs/aidb-handoff.md 安装前置工具")
    version = subprocess.check_output(["node", "--version"], text=True).strip().lstrip("v")
    if tuple(map(int, version.split(".")[:3])) < (24, 14, 1):
        parser.error("Node.js 需要 >= 24.14.1")
    python = runtime / ".venv/bin/python"
    if not python.exists():
        run("uv", "venv", runtime / ".venv", "--python", "3.12")
    run("uv", "pip", "install", "--python", python, "-r", DELIVERY / "requirements-linux-py312.lock")
    run("uv", "pip", "install", "--python", python, "--no-deps", "-e", ROOT,
        "-e", DELIVERY / "vendor/ai-ready-db")
    run("npm", "ci", cwd=ROOT / "web/vite-frontend")
    run("npm", "run", "build", cwd=ROOT / "web/vite-frontend")
    # Re-enter the new interpreter so initialization never borrows developer dependencies.
    code = ("import runpy; from pathlib import Path; "
            f"m=runpy.run_path({str(Path(__file__).resolve())!r}); "
            f"m['initialize'](Path({str(runtime)!r}), python=Path({str(python)!r}))")
    run(python, "-c", code)
    print(f"安装完成。执行：source {shlex.quote(str(runtime / 'env.sh'))}")
    print("然后执行：python script/check_aidb_handoff.py")


if __name__ == "__main__":
    main()
