#!/usr/bin/env python3
"""Run overlapping read-only requests through the aidb bridge."""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import time


CLIENT = Path(__file__).resolve().parent / "aidb_client.py"


def percentile(values: list[float], fraction: float) -> float:
    ordered = sorted(values)
    if not ordered:
        return 0.0
    index = min(len(ordered) - 1, max(0, round((len(ordered) - 1) * fraction)))
    return ordered[index]


def one_request(config: Path | None, timeout: float) -> dict[str, object]:
    command = [sys.executable, str(CLIENT), "local-status"]
    if config:
        command += ["--config", str(config)]
    started = time.monotonic()
    try:
        result = subprocess.run(
            command, text=True, capture_output=True, timeout=timeout, check=False
        )
        elapsed = time.monotonic() - started
        try:
            valid_json = isinstance(json.loads(result.stdout), dict)
        except json.JSONDecodeError:
            valid_json = False
        return {
            "returncode": result.returncode,
            "duration_seconds": elapsed,
            "valid_json": valid_json,
            "stderr": result.stderr[-1000:],
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "returncode": None,
            "duration_seconds": time.monotonic() - started,
            "valid_json": False,
            "stderr": f"timeout after {exc.timeout}s",
        }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path)
    parser.add_argument("--concurrency", type=int, default=100)
    parser.add_argument("--requests", type=int, default=100)
    parser.add_argument("--timeout", type=float, default=30.0)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    if args.concurrency < 1 or args.requests < 1:
        parser.error("--concurrency and --requests must be positive")

    started = time.monotonic()
    results: list[dict[str, object]] = []
    with ThreadPoolExecutor(max_workers=args.concurrency) as pool:
        futures = [pool.submit(one_request, args.config, args.timeout) for _ in range(args.requests)]
        for future in as_completed(futures):
            results.append(future.result())
    wall = time.monotonic() - started

    durations = [float(item["duration_seconds"]) for item in results]
    succeeded = sum(
        1 for item in results if item["returncode"] == 0 and item["valid_json"] is True
    )
    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "command": "local-status",
        "concurrency": args.concurrency,
        "requests": args.requests,
        "succeeded": succeeded,
        "failed": args.requests - succeeded,
        "success_rate": succeeded / args.requests,
        "wall_seconds": wall,
        "requests_per_second": args.requests / wall if wall else None,
        "latency_seconds": {
            "min": min(durations),
            "p50": percentile(durations, 0.50),
            "p95": percentile(durations, 0.95),
            "p99": percentile(durations, 0.99),
            "max": max(durations),
        },
        "failures": [item for item in results if item["returncode"] != 0 or not item["valid_json"]],
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({
        "status": "passed" if succeeded == args.requests else "failed",
        "success_rate": report["success_rate"],
        "p95_seconds": report["latency_seconds"]["p95"],
        "report": str(args.report.resolve()),
    }, ensure_ascii=False))
    return 0 if succeeded == args.requests else 1


if __name__ == "__main__":
    raise SystemExit(main())
