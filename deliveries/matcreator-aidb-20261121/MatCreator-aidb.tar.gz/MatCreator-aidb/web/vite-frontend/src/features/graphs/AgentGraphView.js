import { fetchAgentNodeDetail, graphNodeRevision, graphNodeSummary } from "./graphSummary.js";
import { Network, DataSet } from "vis-network/standalone";
import { createDisclosureController } from "../ui/disclosureState.js";
import { installNetworkWheelZoom } from "./networkWheelZoom.js";
import { httpClient } from "../../shared/api/http.js";
import { applyGraphUpdate } from "./graphUpdates.js";
import {
  AGENT_NODE_SHAPE,
  agentNodeShapeForRecipe,
  dropletGeometry,
  dropletMotionForNode,
  nodeShapeDimensions,
  nodeShapeVerticalExtent,
  runningMotionEnvelope,
  traceDropletPath,
} from "./agentNodeGeometry.js";
import {
  agentDropletBodyAlphas,
  agentDropletOpticAlphas,
  resolveAgentDropletFillAlpha,
} from "./agentNodeLiquidStyle.js";

// Node identity and execution state intentionally live in separate visual
// vocabularies. Type owns the face and its letter; state only owns a compact
// badge or the running motion below.
const NODE_TYPE_VISUALS = {
  orchestrator: {
    fill: "224, 231, 255", border: "129, 140, 248", text: "#1e1b4b",
    dark: { fill: "99, 102, 241", border: "165, 180, 252", text: "#eef2ff" },
  },
  planning: {
    fill: "219, 234, 254", border: "96, 165, 250", text: "#172554",
    dark: { fill: "14, 165, 233", border: "125, 211, 252", text: "#ecfeff" },
  },
  execution: {
    fill: "209, 250, 229", border: "52, 211, 153", text: "#064e3b",
    dark: { fill: "16, 185, 129", border: "110, 231, 183", text: "#ecfdf5" },
  },
  tester: {
    fill: "254, 243, 199", border: "245, 158, 11", text: "#713f12",
    dark: { fill: "217, 119, 6", border: "252, 211, 77", text: "#fffbeb" },
  },
  step: {
    fill: "226, 232, 240", border: "148, 163, 184", text: "#1e293b",
    dark: { fill: "71, 85, 105", border: "148, 163, 184", text: "#f8fafc" },
  },
};

// These names mirror the graph logger / execution-plan lifecycle values.
// Symbols provide a non-colour status cue even at a glance or in grayscale.
const STATUS_VISUALS = {
  running:          { color: "251, 191, 36", edge: "254, 240, 138", symbol: null, label: "Running" },
  success:          { color: "34, 197, 94", symbol: "✓", label: "Completed" },
  failed:           { color: "239, 68, 68", symbol: "!", label: "Failed" },
  needs_replanning: { color: "245, 158, 11", symbol: "?", label: "Needs replanning" },
  blocked:          { color: "245, 158, 11", symbol: "?", label: "Blocked" },
  waiting:          { color: "100, 116, 139", symbol: "…", label: "Waiting" },
  pending:          { color: "100, 116, 139", symbol: "…", label: "Pending" },
  idle:             { color: "100, 116, 139", symbol: "…", label: "Idle" },
  cancelled:        { color: "100, 116, 139", symbol: "×", label: "Cancelled" },
};

const STATUS_TRANSITION_MS = 360;

const rgba = (rgb, alpha) => `rgba(${rgb}, ${alpha})`;

// These distances describe time, rather than graph depth.  In particular an
// execution batch gets its own row even though every execution node still has
// the same planning node as its real parent.
const VINE_BATCH_GAP = 104;
const VINE_BATCH_STAGGER = 68;
const VINE_ROOT_GAP = 132;
// Keep task chains legible vertically while batches themselves still use the
// tighter stagger below.
const VINE_DESCENDANT_GAP = 82;
const VINE_NODE_GAP = 64;
const VINE_PLANNER_GAP = 460;
const VINE_STEM_CLEARANCE = 42;
const DIRECT_LANE_CLEARANCE = 28;

const STATUS_ALIASES = {
  completed: "success",
  succeeded: "success",
  cancelled: "cancelled",
  canceled: "cancelled",
  terminated: "cancelled",
};

export class AgentGraphView {
  constructor(containerId, dependencies) {
    this._stepExecutionFeed = dependencies.stepExecutionFeed;
    this._graphViewport = dependencies.graphViewport;
    this._requestStepCancellation = dependencies.requestStepCancellation;
    this._createArtifactListItem = dependencies.createArtifactListItem;
    this._renderStepConversationEvent = dependencies.renderStepConversationEvent;
    this._renderStepToolCall = dependencies.renderStepToolCall;
    this._syncPanelResizerVisibility = dependencies.syncPanelResizerVisibility;
    this._container = document.getElementById(containerId);
    this._surfaceEl = document.getElementById("graph-surface");
    this._nodes = new DataSet([]);
    this._edges = new DataSet([]);
    this._network = null;
    this._pollInterval = null;
    this._eventStream = null;
    this._didInitialFit = false;
    this._pendingFit = true;
    this._animationFrame = null;
    this._lastAnimationPaint = 0;
    this._viewportVisible = true;
    this._animationTimer = null;
    this._motionTime = 0;
    this._activeEdges = [];
    this._vineEdges = [];
    this._hasRunningNodes = false;
    this._nodeTransitions = new Map();
    this._lastNodeStatuses = new Map();
    this._runningNodeIds = new Set();
    this._touchState = null;
    this._interactionFrame = null;
    this._motionPreference = window.matchMedia?.("(prefers-reduced-motion: reduce)") ?? null;
    this._reduceMotion = this._motionPreference?.matches ?? false;
    this._motionPreference?.addEventListener?.("change", (event) => {
      this._reduceMotion = Boolean(event.matches);
      this._syncAnimation();
      this._network?.redraw();
    });
    this._graphSurfaceIsLight = this._readGraphSurfaceTone();
    this._graphDropletFillAlpha = this._readGraphDropletFillAlpha();
    this._detailEl = document.getElementById("graph-detail");
    this._detailClose = document.getElementById("graph-detail-close");
    this._detailLabel = document.getElementById("detail-label");
    this._detailStatus = document.getElementById("detail-status");
    this._detailSummary = document.getElementById("detail-summary");
    this._detailArtifacts = document.getElementById("detail-artifacts");
    this._detailTiming = document.getElementById("detail-timing");
    this._detailInput = document.getElementById("detail-input");
    this._detailToolcalls = document.getElementById("detail-toolcalls");
    this._detailToolcallsCount = document.getElementById("detail-toolcalls-count");
    this._detailConversation = document.getElementById("detail-conversation");
    this._detailConversationCount = document.getElementById("detail-conversation-count");
    this._nodeData = {};
    this._layoutKey = null;
    this._cachedDisplayEdges = [];
    this._cachedPositions = {};
    this._cachedVineEdgeIds = new Set();
    this._vineStemX = new Map();
    this._displayEdgesByNode = new Map();
    this._edgePhases = new Map();
    this._nodeVisualKeys = new Map();
    this._detailRenderKey = null;
    this._graphSnapshot = null;
    this._activeDetailNodeId = null;
    this._detailDisclosures = createDisclosureController({
      captureScrollPosition: () => ({ scrollTop: this._detailEl.scrollTop }),
      restoreScrollPosition: (position) => {
        requestAnimationFrame(() => requestAnimationFrame(() => {
          if (position) this._detailEl.scrollTop = position.scrollTop;
        }));
      },
    });
    this._init();
    document.addEventListener("visibilitychange", () => this._syncAnimation());
    if (typeof IntersectionObserver !== "undefined") {
      this._visibilityObserver = new IntersectionObserver(([entry]) => {
        this._viewportVisible = entry.isIntersecting;
        this._syncAnimation();
      });
      this._visibilityObserver.observe(this._graphViewport || this._container);
    }
  }

  _init() {
    const edgeColors = this._edgeColors();
    const options = {
      // Agent activity uses a chronology-aware layout below.  A DAG layout
      // would put every child of a planner at the same depth and erase the
      // distinction between successive planning rounds.
      layout: { hierarchical: false },
      physics: { enabled: false },
      edges: {
        arrows: { to: { enabled: true, scaleFactor: 0.72 } },
        color: edgeColors,
        width: 2.4,
        smooth: { type: "cubicBezier", forceDirection: "vertical" },
      },
      nodes: {
        shape: "custom",
        borderWidth: 2,
        borderWidthSelected: 3,
      },
      interaction: {
        hover: true,
        hoverConnectedEdges: true,
        tooltipDelay: 200,
        dragNodes: true,
        dragView: true,
        // vis-network zooms a fixed amount for each event, which is unstable
        // for high-resolution wheels and touchpads.
        zoomView: false,
      },
    };

    this._network = new Network(
      this._container,
      { nodes: this._nodes, edges: this._edges },
      options
    );
    installNetworkWheelZoom(this._container, this._network);

    this._network.on("selectNode", (params) => {
      if (params.nodes.length) this._showDetail(params.nodes[0]);
    });
    this._network.on("deselectNode", () => this._hideDetail());
    this._network.on("beforeDrawing", (ctx) => this._drawVines(ctx));
    this._network.on("afterDrawing", (ctx) => this._drawActiveFlow(ctx));
    this._network.on("blurNode", () => this._clearLiquidTouch());
    const handleLiquidPointerMove = (event) => this._updateLiquidTouchFromPointerEvent(event);
    this._container?.addEventListener("pointermove", handleLiquidPointerMove, { passive: true });
    this._container?.addEventListener("mousemove", handleLiquidPointerMove, { passive: true });
    this._container?.addEventListener("pointerleave", () => this._clearLiquidTouch());
    window.addEventListener("matcreator-theme-change", () => this._applyTheme());
    this._detailClose?.addEventListener("click", () => {
      this._network.unselectAll();
      this._hideDetail();
    });
  }

  _edgeColors() {
    // Keep these colors opaque. vis-network draws the arrowhead over the last
    // segment of its edge; translucent colors compound at that seam and create
    // a visibly darker/lighter patch.
    return this._graphSurfaceIsLight
      ? { color: "#b8c2d0", highlight: "#64748b", hover: "#8290a3", inherit: false }
      : { color: "#526176", highlight: "#cbd5e1", hover: "#94a3b8", inherit: false };
  }

  _readGraphSurfaceTone() {
    const token = window.getComputedStyle?.(document.body)
      ?.getPropertyValue("--skin-graph-surface-tone")
      ?.trim()
      ?.toLowerCase();
    if (token === "light") return true;
    if (token === "dark") return false;
    return document.body.dataset.theme === "light";
  }

  _readGraphDropletFillAlpha() {
    const token = window.getComputedStyle?.(document.body)
      ?.getPropertyValue("--skin-graph-droplet-fill-alpha")
      ?.trim();
    return resolveAgentDropletFillAlpha(token);
  }

  _applyTheme() {
    this._graphSurfaceIsLight = this._readGraphSurfaceTone();
    this._graphDropletFillAlpha = this._readGraphDropletFillAlpha();
    const color = this._edgeColors();
    const updates = this._edges.getIds().map((id) => ({ id, color }));
    if (updates.length) this._edges.update(updates);

    // A recipe can change custom-node geometry as well as colour. Updating the
    // DataSet invalidates vis-network's cached CustomShape hit dimensions.
    const nodeUpdates = Object.values(this._nodeData).map((raw) => {
      const current = this._nodes.get(raw.id) || {};
      const fallback = this._cachedPositions[raw.id] || { x: 0, y: 0 };
      return {
        ...this._visNode(raw),
        x: Number.isFinite(current.x) ? current.x : fallback.x,
        y: Number.isFinite(current.y) ? current.y : fallback.y,
        fixed: current.fixed || { x: true, y: true },
      };
    });
    if (nodeUpdates.length) this._nodes.update(nodeUpdates);

    this._syncAnimation();
    this._network?.redraw();
    requestAnimationFrame(() => this._network?.redraw());
  }

  _nodeTooltip(raw) {
    const status = raw.status || "idle";
    const statusVisual = STATUS_VISUALS[status];
    const lines = [
      raw.label || raw.id,
      `Status: ${statusVisual?.label || status}`,
      `Type: ${raw.type || "step"}`,
    ];
    if (this._isDirectOrchestratorStep(raw)) lines.push("Dispatch: direct from orchestrator");
    if (raw.summary) lines.push(`Summary: ${raw.summary}`);
    if (raw.start_time) {
      if (raw.end_time) {
        const secs = ((new Date(raw.end_time) - new Date(raw.start_time)) / 1000).toFixed(1);
        lines.push(`Duration: ${secs}s`);
      } else {
        lines.push("Duration: running");
      }
    }
    return lines.join("\n");
  }

  _nodeBadge(raw) {
    const stepNumber = raw.input && raw.input.step_number;
    if (raw.type === "step" && stepNumber !== undefined && stepNumber !== null) {
      return String(stepNumber).slice(0, 2);
    }
    const typeInitials = {
      orchestrator: "O",
      planning: "P",
      execution: "E",
      tester: "T",
    };
    if (typeInitials[raw.type]) return typeInitials[raw.type];
    return String(raw.label || raw.id || "?").trim().charAt(0).toUpperCase() || "?";
  }

  _nodeRadius(raw) {
    const baseRadius = raw.type === "orchestrator" ? 17 : raw.type === "planning" ? 15 : 13;
    return this._nodeShape() === AGENT_NODE_SHAPE.DROPLET ? baseRadius + 2 : baseRadius;
  }

  _nodeShape() {
    return agentNodeShapeForRecipe(
      document.body.dataset.styleRecipe,
      document.body.dataset.styleRecipeVersion,
    );
  }

  _traceNodePath(ctx, x, y, radius, shape = this._nodeShape(), motion = null) {
    if (shape === AGENT_NODE_SHAPE.DROPLET) {
      return traceDropletPath(ctx, x, y, radius, motion);
    }
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    return null;
  }

  _nodeVerticalExtent(raw, direction) {
    return nodeShapeVerticalExtent(this._nodeRadius(raw), this._nodeShape(), direction);
  }

  _isDirectOrchestratorStep(raw) {
    return raw?.type === "step" && raw?.parent_id === "orchestrator";
  }

  _vineRouteForEdge(edge, nodeMap) {
    const fromNode = nodeMap[edge.from];
    const toNode = nodeMap[edge.to];
    if (fromNode?.type === "planning" && toNode?.type === "execution") {
      return {
        key: `batches:${edge.from}`,
        stemX: this._vineStemX.get(edge.from),
        entryMode: "bottom",
      };
    }
    if (fromNode?.type !== "orchestrator") return null;
    if (toNode?.type === "planning") {
      return {
        key: `root:${edge.from}:${edge.to}`,
        stemX: this._vineStemX.get(edge.to),
        entryMode: "bottom",
      };
    }
    if (
      this._isDirectOrchestratorStep(toNode)
      && (!Array.isArray(toNode.dependency_ids) || toNode.dependency_ids.length === 0)
    ) {
      return {
        key: `direct:${edge.from}`,
        stemX: this._vineStemX.get(edge.from),
        entryMode: "bottom",
      };
    }
    return null;
  }

  _isRoutedVineEdge(edge, nodeMap) {
    return this._vineRouteForEdge(edge, nodeMap) !== null;
  }

  _nodeTransition(nodeId) {
    const transition = this._nodeTransitions.get(nodeId);
    if (!transition) return null;
    const elapsed = performance.now() - transition.startedAt;
    if (elapsed >= STATUS_TRANSITION_MS) return null;
    return { ...transition, progress: Math.max(0, elapsed / STATUS_TRANSITION_MS) };
  }

  _liquidMotionForNode(raw, { hover = false } = {}) {
    if (!raw || this._reduceMotion) return dropletMotionForNode(raw?.id, this._motionTime);
    const status = raw.status || "idle";
    const transition = this._nodeTransition(raw.id);
    const runningStrength = runningMotionEnvelope(status, transition);
    const hoverStrength = hover ? 0.34 : 0;
    const touch = this._touchState?.nodeId === raw.id ? this._touchState : null;
    return dropletMotionForNode(raw.id, this._motionTime, {
      active: status === "running" || transition?.from === "running",
      hover,
      strength: Math.max(runningStrength, hoverStrength),
      touch,
    });
  }

  _scheduleInteractionPaint() {
    if (this._interactionFrame !== null) return;
    this._interactionFrame = requestAnimationFrame(() => {
      this._interactionFrame = null;
      this._network?.redraw();
    });
  }

  _updateLiquidTouchFromPointerEvent(event) {
    if (!this._container || !this._network || !event) {
      this._clearLiquidTouch();
      return;
    }
    const canvas = this._container.querySelector("canvas");
    const rect = (canvas || this._container).getBoundingClientRect();
    const DOM = {
      x: event.clientX - rect.left,
      y: event.clientY - rect.top,
    };
    this._updateLiquidTouch({
      pointer: {
        DOM,
        canvas: this._network.DOMtoCanvas(DOM),
      },
    });
  }

  _updateLiquidTouch(params) {
    if (
      this._nodeShape() !== AGENT_NODE_SHAPE.DROPLET
      || !params?.pointer?.DOM
      || !params?.pointer?.canvas
    ) {
      this._clearLiquidTouch();
      return;
    }
    const nodeId = this._network?.getNodeAt(params.pointer.DOM);
    const hasNode = nodeId !== undefined && nodeId !== null;
    const raw = hasNode ? this._nodeData[nodeId] : null;
    const position = hasNode ? this._network?.getPositions([nodeId])?.[nodeId] : null;
    if (!raw || !position || this._reduceMotion) {
      this._clearLiquidTouch();
      return;
    }

    const radius = this._nodeRadius(raw);
    const localX = (params.pointer.canvas.x - position.x) / radius;
    const localY = (params.pointer.canvas.y - position.y) / radius;
    const distance = Math.hypot(localX, localY);
    const penetration = Math.max(0, Math.min(1, 1 - distance / 1.08));
    this._touchState = {
      nodeId,
      x: localX,
      y: localY,
      strength: 0.46 + Math.sqrt(penetration) * 0.54,
    };
    this._scheduleInteractionPaint();
  }

  _clearLiquidTouch() {
    if (!this._touchState) return;
    this._touchState = null;
    this._scheduleInteractionPaint();
  }

  _hasLiveTransitions() {
    const now = performance.now();
    let hasLiveTransition = false;
    this._nodeTransitions.forEach((transition, nodeId) => {
      if (now - transition.startedAt < STATUS_TRANSITION_MS) {
        hasLiveTransition = true;
      } else {
        this._nodeTransitions.delete(nodeId);
      }
    });
    return hasLiveTransition;
  }

  _drawRunningAura(ctx, x, y, radius, isLight) {
    const pulse = this._reduceMotion
      ? 0.35
      : (Math.sin(this._motionTime / 330 + x * 0.015) + 1) / 2;
    const glowStrength = this._reduceMotion ? 0.78 : 0.55 + pulse * 0.45;
    const haloGap = 4.2;
    const gapBoundary = radius + haloGap;
    // Radius breathing is intentionally subtle; the pulse is primarily an
    // intensity change so the halo feels alive without wobbling like a loader.
    const radiusBreath = this._reduceMotion ? 0 : (pulse - 0.5) * 1.1;
    const coreRadius = radius + haloGap + 3.1 + radiusBreath;
    const outerRadius = coreRadius + 8.5;
    const haloCore = "245, 158, 11";
    const haloHighlight = "251, 191, 36";
    const alpha = glowStrength * (isLight ? 0.8 : 1);
    const drawLayer = (outer, stops) => {
      const gradient = ctx.createRadialGradient(x, y, gapBoundary, x, y, outer);
      stops.forEach(([offset, color, opacity]) => {
        gradient.addColorStop(offset, rgba(color, alpha * opacity));
      });
      ctx.beginPath();
      ctx.arc(x, y, outer, 0, Math.PI * 2);
      ctx.fillStyle = gradient;
      ctx.fill();
    };

    // The wide outer field carries most of the breathing light, while its
    // first stop keeps the node-facing gap visibly dark.
    drawLayer(outerRadius, [
      [0, haloCore, 0],
      [0.16, haloCore, 0.12],
      [0.4, haloCore, 0.46],
      [0.64, haloHighlight, 0.28],
      [1, haloCore, 0],
    ]);
    // A narrower inward falloff gives the ring a soft inner lip without
    // painting into the dark clearance around the node.
    drawLayer(coreRadius + 1.4, [
      [0, haloCore, 0],
      [0.34, haloCore, 0.35],
      [0.78, haloHighlight, 0.82],
      [1, haloHighlight, 0.32],
    ]);
    // The running state is intentionally glow-only: the layered falloff
    // provides the shape while preserving the dark clearance around the node.
  }

  _drawStatusGlyph(ctx, symbol, x, y, radius, color) {
    const unit = radius / 5.4;
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(unit, unit);
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineWidth = 1.45;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    if (symbol === "✓") {
      ctx.beginPath();
      ctx.moveTo(-3.1, -0.1);
      ctx.lineTo(-0.8, 2.35);
      ctx.lineTo(3.5, -2.65);
      ctx.stroke();
    } else if (symbol === "!") {
      ctx.beginPath();
      ctx.moveTo(0, -3.25);
      ctx.lineTo(0, 0.75);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(0, 3.05, 0.78, 0, Math.PI * 2);
      ctx.fill();
    } else if (symbol === "?") {
        ctx.beginPath();

        // compact upper hook
        ctx.moveTo(-1.65, -1.65);
        ctx.bezierCurveTo(
            -1.35, -2.75,
            0.05, -3.15,
            1.25, -2.55
        );
        ctx.bezierCurveTo(
            2.15, -2.05,
            2.05, -0.85,
            1.05, -0.20
        );
        ctx.bezierCurveTo(
            0.30, 0.30,
            0.00, 0.65,
            0.00, 1.25
        );
        ctx.stroke();

        // clearly separated dot
        ctx.beginPath();
        ctx.arc(0, 3.65, 0.85, 0, Math.PI * 2);
        ctx.fill();
    } else if (symbol === "…") {
      [-2.4, 0, 2.4].forEach((offset) => {
        ctx.beginPath();
        ctx.arc(offset, 0.4, 0.75, 0, Math.PI * 2);
        ctx.fill();
      });
    } else if (symbol === "×") {
      ctx.beginPath();
      ctx.moveTo(-2.55, -2.55);
      ctx.lineTo(2.55, 2.55);
      ctx.moveTo(2.55, -2.55);
      ctx.lineTo(-2.55, 2.55);
      ctx.stroke();
    } else if (symbol === "▶") {
      ctx.beginPath();
      ctx.moveTo(-1.7, -2.85);
      ctx.lineTo(2.65, 0);
      ctx.lineTo(-1.7, 2.85);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
  }

  _drawStatusBadge(ctx, x, y, radius, status, transition, shape, motion = null) {
    const visual = STATUS_VISUALS[status] || STATUS_VISUALS.idle;
    const staticRunningCue = status === "running"
      && shape === AGENT_NODE_SHAPE.DROPLET
      && this._reduceMotion;
    const symbol = visual.symbol || (staticRunningCue ? "▶" : null);
    if (!symbol) return;

    const arrival = transition?.to === status ? Math.min(1, transition.progress / 0.62) : 1;
    const easedArrival = 1 - (1 - arrival) ** 3;
    const failurePulse = status === "failed" && transition?.to === status
      ? 1 + Math.sin(Math.min(1, transition.progress) * Math.PI) * 0.16
      : 1;
    const baseBadgeRadius = staticRunningCue
      ? Math.max(4.2, radius * 0.26)
      : Math.max(5, radius * 0.34);
    const badgeRadius = baseBadgeRadius * (0.72 + easedArrival * 0.28) * failurePulse;
    const dropletAnchor = shape === AGENT_NODE_SHAPE.DROPLET
      ? dropletGeometry(radius, motion).statusAnchor
      : null;
    const badgeX = x + (dropletAnchor?.x ?? radius * 0.73);
    const badgeY = y + (dropletAnchor?.y ?? -radius * 0.73);

    ctx.save();
    ctx.globalAlpha *= 0.78 + easedArrival * 0.22;
    ctx.beginPath();
    ctx.arc(badgeX, badgeY, badgeRadius, 0, Math.PI * 2);
    ctx.fillStyle = rgba(visual.color, 1);
    ctx.fill();
    ctx.lineWidth = 1;
    ctx.strokeStyle = this._graphSurfaceIsLight
      ? "rgba(15, 23, 42, 0.16)"
      : "rgba(255, 255, 255, 0.42)";
    ctx.stroke();
    const glyphColor = status === "waiting" || status === "pending" || status === "idle" || status === "cancelled"
      ? "#f8fafc"
      : "#172033";
    this._drawStatusGlyph(ctx, symbol, badgeX, badgeY, badgeRadius, glyphColor);
    ctx.restore();
  }

  _drawLiquidDroplet(ctx, {
    x,
    y,
    radius,
    palette,
    isLight,
    selected,
    hover,
    isCancelled,
    motion,
    fillAlpha,
  }) {
    const stateAlpha = isCancelled ? 0.48 : 1;
    const bodyAlphas = agentDropletBodyAlphas(fillAlpha, stateAlpha);
    const opticAlphas = agentDropletOpticAlphas(
      stateAlpha,
      selected ? 1 : hover ? 0.58 : 0,
    );

    ctx.save();
    this._traceNodePath(ctx, x, y, radius, AGENT_NODE_SHAPE.DROPLET, motion);
    const body = ctx.createRadialGradient(
      x - radius * 0.4,
      y - radius * 0.48,
      Math.max(0.8, radius * 0.06),
      x + radius * 0.12,
      y + radius * 0.16,
      radius * 1.22,
    );
    body.addColorStop(0, `rgba(255, 255, 255, ${bodyAlphas.highlight})`);
    body.addColorStop(0.18, `rgba(255, 255, 255, ${bodyAlphas.sheen})`);
    body.addColorStop(0.62, rgba(palette.fill, bodyAlphas.fill));
    body.addColorStop(1, rgba(palette.border, bodyAlphas.rim));
    ctx.fillStyle = body;
    ctx.shadowColor = `rgba(0, 0, 0, ${(isLight ? 0.14 : 0.22) * stateAlpha})`;
    ctx.shadowBlur = selected ? 4 : hover ? 3.4 : 2.8;
    ctx.shadowOffsetY = 1.2;
    ctx.fill();
    ctx.shadowColor = "transparent";
    ctx.shadowBlur = 0;
    ctx.shadowOffsetY = 0;

    // A very thin spectral film gives the dark glass a diffraction sheen
    // without recolouring the node type or lifecycle state.  Conic gradients
    // read like an oil-film reflection; the linear fallback keeps older Canvas
    // implementations functional.
    ctx.save();
    this._traceNodePath(ctx, x, y, radius - 0.9, AGENT_NODE_SHAPE.DROPLET, motion);
    ctx.clip();
    ctx.globalCompositeOperation = "screen";
    const spectrum = typeof ctx.createConicGradient === "function"
      ? ctx.createConicGradient(-Math.PI * 0.72, x - radius * 0.08, y - radius * 0.06)
      : ctx.createLinearGradient(
        x - radius,
        y - radius,
        x + radius,
        y + radius,
      );
    spectrum.addColorStop(0, "rgba(34, 211, 238, 0)");
    spectrum.addColorStop(0.13, `rgba(56, 189, 248, ${opticAlphas.spectrum})`);
    spectrum.addColorStop(0.29, `rgba(129, 140, 248, ${opticAlphas.spectrum * 0.68})`);
    spectrum.addColorStop(0.44, `rgba(244, 114, 182, ${opticAlphas.spectrum * 0.5})`);
    spectrum.addColorStop(0.58, `rgba(250, 204, 21, ${opticAlphas.spectrum * 0.48})`);
    spectrum.addColorStop(0.73, `rgba(52, 211, 153, ${opticAlphas.spectrum * 0.58})`);
    spectrum.addColorStop(0.88, `rgba(125, 211, 252, ${opticAlphas.spectrum * 0.9})`);
    spectrum.addColorStop(1, "rgba(34, 211, 238, 0)");
    ctx.fillStyle = spectrum;
    ctx.fillRect(x - radius * 1.2, y - radius * 1.2, radius * 2.4, radius * 2.4);

    // Fine interference contours stay sparse at the small graph-node scale.
    // Their shared gradient makes them appear to catch the same moving light
    // rather than becoming decorative stripes.
    const caustic = ctx.createLinearGradient(
      x - radius * 0.9,
      y - radius * 0.75,
      x + radius * 0.85,
      y + radius * 0.72,
    );
    caustic.addColorStop(0, `rgba(103, 232, 249, ${opticAlphas.caustic * 0.15})`);
    caustic.addColorStop(0.28, `rgba(186, 230, 253, ${opticAlphas.caustic})`);
    caustic.addColorStop(0.55, `rgba(196, 181, 253, ${opticAlphas.caustic * 0.72})`);
    caustic.addColorStop(0.78, `rgba(110, 231, 183, ${opticAlphas.caustic * 0.78})`);
    caustic.addColorStop(1, "rgba(255, 255, 255, 0)");
    ctx.strokeStyle = caustic;
    ctx.lineWidth = Math.max(0.45, radius * 0.038);
    ctx.lineCap = "round";
    [-0.34, -0.14, 0.08].forEach((offset, index) => {
      ctx.beginPath();
      ctx.moveTo(x - radius * 0.82, y + radius * (offset - 0.08));
      ctx.bezierCurveTo(
        x - radius * 0.18,
        y + radius * (offset - 0.42 - index * 0.025),
        x + radius * 0.44,
        y + radius * (offset + 0.28),
        x + radius * 0.78,
        y + radius * (offset + 0.12),
      );
      ctx.stroke();
    });
    ctx.restore();

    // Two contour-following rims create the refractive edge visible in the
    // reference while preserving the existing organic silhouette.
    ctx.save();
    ctx.globalCompositeOperation = "screen";
    const rim = typeof ctx.createConicGradient === "function"
      ? ctx.createConicGradient(Math.PI * 0.34, x, y)
      : ctx.createLinearGradient(x - radius, y, x + radius, y);
    rim.addColorStop(0, `rgba(103, 232, 249, ${opticAlphas.innerRim})`);
    rim.addColorStop(0.2, `rgba(191, 219, 254, ${opticAlphas.innerRim * 0.72})`);
    rim.addColorStop(0.39, `rgba(167, 139, 250, ${opticAlphas.innerRim * 0.5})`);
    rim.addColorStop(0.57, `rgba(250, 204, 21, ${opticAlphas.innerRim * 0.42})`);
    rim.addColorStop(0.74, `rgba(52, 211, 153, ${opticAlphas.innerRim * 0.5})`);
    rim.addColorStop(1, `rgba(125, 211, 252, ${opticAlphas.innerRim})`);
    this._traceNodePath(ctx, x, y, radius - 0.35, AGENT_NODE_SHAPE.DROPLET, motion);
    ctx.lineWidth = Math.max(0.85, radius * 0.07);
    ctx.strokeStyle = rim;
    ctx.shadowColor = `rgba(56, 189, 248, ${opticAlphas.outerGlow})`;
    ctx.shadowBlur = hover || selected ? 4.2 : 2.7;
    ctx.stroke();
    ctx.shadowColor = "transparent";
    this._traceNodePath(ctx, x, y, radius - 1.75, AGENT_NODE_SHAPE.DROPLET, motion);
    ctx.lineWidth = Math.max(0.42, radius * 0.032);
    ctx.globalAlpha *= 0.72;
    ctx.stroke();
    ctx.restore();

    ctx.save();
    this._traceNodePath(ctx, x, y, radius - 1.2, AGENT_NODE_SHAPE.DROPLET, motion);
    ctx.clip();
    const highlightDx = (motion?.highlightX || 0) * radius;
    const highlightDy = (motion?.highlightY || 0) * radius;

    ctx.beginPath();
    ctx.ellipse(
      x - radius * 0.34 + highlightDx,
      y - radius * 0.36 + highlightDy,
      Math.max(1.15, radius * 0.105),
      Math.max(2.6, radius * 0.3),
      -0.55,
      0,
      Math.PI * 2,
    );
    ctx.fillStyle = `rgba(255, 255, 255, ${Math.min(1, opticAlphas.specular * (hover || selected ? 1.14 : 1))})`;
    ctx.fill();

    ctx.beginPath();
    ctx.arc(
      x - radius * 0.5 + highlightDx * 0.72,
      y - radius * 0.58 + highlightDy * 0.72,
      Math.max(0.72, radius * 0.055),
      0,
      Math.PI * 2,
    );
    ctx.fillStyle = `rgba(255, 255, 255, ${0.9 * stateAlpha})`;
    ctx.fill();
    ctx.restore();

    if (motion?.touchDepth > 0) {
      const contactAngle = motion.touchAngle || 0;
      const contactDistance = Math.min(0.78, Math.hypot(motion.touchX, motion.touchY)) * radius;
      const contactX = x + Math.cos(contactAngle) * contactDistance;
      const contactY = y + Math.sin(contactAngle) * contactDistance;
      const dimpleRadius = radius * (0.14 + motion.touchDepth * 0.19);
      ctx.save();
      this._traceNodePath(ctx, x, y, radius - 0.9, AGENT_NODE_SHAPE.DROPLET, motion);
      ctx.clip();
      const dimple = ctx.createRadialGradient(
        contactX,
        contactY,
        0,
        contactX,
        contactY,
        dimpleRadius,
      );
      dimple.addColorStop(0, `rgba(10, 18, 28, ${0.38 * motion.touchDepth})`);
      dimple.addColorStop(0.58, rgba(palette.border, 0.08 * motion.touchDepth));
      dimple.addColorStop(1, "rgba(255, 255, 255, 0)");
      ctx.beginPath();
      ctx.arc(contactX, contactY, dimpleRadius, 0, Math.PI * 2);
      ctx.fillStyle = dimple;
      ctx.fill();
      ctx.restore();
    }
    ctx.restore();
  }

  _drawDirectDispatchMark(ctx, x, y, radius) {
    // Keep this separate from the lifecycle badge: the bolt describes who
    // dispatched the work, rather than whether that work succeeded or failed.
    const markX = x - radius * 0.66;
    const markY = y + radius * 0.62;
    const scale = Math.max(0.72, radius / 15);
    ctx.save();
    ctx.translate(markX, markY);
    ctx.scale(scale, scale);
    ctx.beginPath();
    ctx.moveTo(0.7, -5.2);
    ctx.lineTo(-3.1, 0.25);
    ctx.lineTo(-0.4, 0.25);
    ctx.lineTo(-1.15, 5.0);
    ctx.lineTo(3.25, -1.2);
    ctx.lineTo(0.55, -1.2);
    ctx.closePath();
    ctx.fillStyle = this._graphSurfaceIsLight ? "#d97706" : "#fbbf24";
    ctx.fill();
    ctx.restore();
  }

  _nodeRenderer(raw, typeVisual, badge, radius) {
    return ({ ctx, x, y, state }) => {
      const selected = Boolean(state?.selected);
      const hover = Boolean(state?.hover);
      const status = raw.status || "idle";
      const isRunning = status === "running";
      const isCancelled = status === "cancelled";
      const shape = this._nodeShape();
      const isDroplet = shape === AGENT_NODE_SHAPE.DROPLET;
      const drawRadius = radius + (selected ? 2 : hover ? 1 : 0);
      const borderWidth = selected ? 2.4 : hover ? 2.1 : 1.55;

      return {
        drawNode: () => {
          // vis-network calls custom renderers once with NaN coordinates while
          // measuring a new hierarchical node. Canvas drawing APIs reject
          // those values, so leave that sizing pass blank; nodeDimensions below are
          // still returned and the following positioned redraw paints it.
          if (!Number.isFinite(x) || !Number.isFinite(y)) return;
          ctx.save();
          const isLight = this._graphSurfaceIsLight;
          const palette = isDroplet
            ? typeVisual.dark || typeVisual
            : isLight ? typeVisual : typeVisual.dark || typeVisual;
          const transition = this._reduceMotion ? null : this._nodeTransition(raw.id);
          const liquidMotion = isDroplet
            ? this._liquidMotionForNode(raw, { hover })
            : null;

          // Preserve the established active-node treatment: a warm, breathing
          // aura for standard skins. Rack Lab communicates activity through
          // the liquid body's own low-amplitude deformation.
          if (isRunning && !isDroplet) this._drawRunningAura(ctx, x, y, drawRadius, isLight);

          // Selection is neutral and deliberately tight so it cannot be
          // mistaken for a lifecycle state.
          if (selected) {
            this._traceNodePath(ctx, x, y, drawRadius + 3.4, shape, liquidMotion);
            ctx.lineWidth = 1.45;
            ctx.strokeStyle = isLight ? "rgba(15, 23, 42, 0.72)" : "rgba(248, 250, 252, 0.78)";
            ctx.stroke();
          }

          if (isDroplet) {
            this._drawLiquidDroplet(ctx, {
              x,
              y,
              radius: drawRadius,
              palette,
              isLight,
              selected,
              hover,
              isCancelled,
              motion: liquidMotion,
              fillAlpha: this._graphDropletFillAlpha,
            });
          } else {
            // Standard recipes retain their opaque backing plate and flat face.
            this._traceNodePath(ctx, x, y, drawRadius, shape);
            ctx.fillStyle = isLight ? "#f8fafc" : "#172033";
            ctx.fill();
            this._traceNodePath(ctx, x, y, drawRadius - 0.7, shape);
            const faceAlpha = isCancelled ? 0.55 : 1;
            ctx.fillStyle = rgba(
              palette.fill,
              faceAlpha * (isLight ? (hover || selected ? 0.9 : 0.78) : 1),
            );
            ctx.fill();
            ctx.lineWidth = borderWidth;
            ctx.strokeStyle = rgba(
              palette.border,
              faceAlpha * (isLight ? (selected ? 1 : hover ? 0.96 : 0.82) : 1),
            );
            ctx.stroke();
          }

          ctx.save();
          ctx.fillStyle = isDroplet
            ? isLight ? "#10243d" : "rgba(248, 250, 252, 0.96)"
            : palette.text;
          if (isCancelled) ctx.globalAlpha *= 0.72;
          ctx.font = `800 ${badge.length > 1 ? 11 : 12.5}px Manrope, system-ui, sans-serif`;
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          const metrics = ctx.measureText(badge);
          const opticalOffset = metrics.actualBoundingBoxLeft !== undefined
            ? (metrics.actualBoundingBoxLeft - metrics.actualBoundingBoxRight) / 2
            : 0;
          const contentY = isDroplet
            ? y + dropletGeometry(drawRadius, liquidMotion).opticalCenterY
            : y;
          ctx.fillText(badge, x + opticalOffset, contentY);
          if (this._isDirectOrchestratorStep(raw)) {
            this._drawDirectDispatchMark(ctx, x, y, drawRadius);
          }
          this._drawStatusBadge(
            ctx,
            x,
            y,
            drawRadius,
            status,
            transition,
            shape,
            liquidMotion,
          );
          ctx.restore();
          ctx.restore();
        },
        nodeDimensions: nodeShapeDimensions(radius, shape),
      };
    };
  }

  _visNode(raw) {
    const typeVisual = NODE_TYPE_VISUALS[raw.type] || NODE_TYPE_VISUALS.step;
    const palette = this._nodeShape() === AGENT_NODE_SHAPE.DROPLET
      ? typeVisual.dark || typeVisual
      : this._graphSurfaceIsLight ? typeVisual : typeVisual.dark || typeVisual;
    const badge = this._nodeBadge(raw);
    const radius = this._nodeRadius(raw);
    return {
      id: raw.id,
      label: "",
      shape: "custom",
      color: {
        background: rgba(palette.fill, 1),
        border: rgba(palette.border, 1),
        highlight: { background: rgba(palette.fill, 1), border: rgba(palette.border, 1) },
      },
      // vis-network may retain a custom renderer between DataSet updates.
      // Resolve the current node data while painting so a completed node can
      // never keep the renderer closure from its earlier running state.
      ctxRenderer: (params) => {
        const current = this._nodeData[raw.id] || raw;
        const currentTypeVisual = NODE_TYPE_VISUALS[current.type] || NODE_TYPE_VISUALS.step;
        return this._nodeRenderer(
          current,
          currentTypeVisual,
          this._nodeBadge(current),
          this._nodeRadius(current),
        )(params);
      },
      title: this._nodeTooltip(raw),
    };
  }

  _normalizeNodeStatus(status) {
    const normalized = String(status || "idle").toLowerCase();
    return STATUS_ALIASES[normalized] || (STATUS_VISUALS[normalized] ? normalized : "idle");
  }

  _bezierPoint(p0, p1, p2, p3, progress) {
    const inverse = 1 - progress;
    return {
      x: inverse ** 3 * p0.x
        + 3 * inverse ** 2 * progress * p1.x
        + 3 * inverse * progress ** 2 * p2.x
        + progress ** 3 * p3.x,
      y: inverse ** 3 * p0.y
        + 3 * inverse ** 2 * progress * p1.y
        + 3 * inverse * progress ** 2 * p2.y
        + progress ** 3 * p3.y,
    };
  }

  _segmentLength(segment) {
    if (segment.kind === "line") return Math.hypot(segment.to.x - segment.from.x, segment.to.y - segment.from.y);
    let length = 0;
    let previous = segment.p0;
    for (let index = 1; index <= 12; index++) {
      const point = this._bezierPoint(segment.p0, segment.p1, segment.p2, segment.p3, index / 12);
      length += Math.hypot(point.x - previous.x, point.y - previous.y);
      previous = point;
    }
    return length;
  }

  _pointOnSegments(segments, progress) {
    const lengths = segments.map((segment) => this._segmentLength(segment));
    const totalLength = lengths.reduce((sum, length) => sum + length, 0);
    if (!totalLength) return null;
    let remaining = Math.max(0, Math.min(1, progress)) * totalLength;
    for (let index = 0; index < segments.length; index++) {
      const segment = segments[index];
      const length = lengths[index];
      if (remaining > length && index < segments.length - 1) {
        remaining -= length;
        continue;
      }
      const localProgress = length ? remaining / length : 1;
      if (segment.kind === "line") {
        return {
          x: segment.from.x + (segment.to.x - segment.from.x) * localProgress,
          y: segment.from.y + (segment.to.y - segment.from.y) * localProgress,
        };
      }
      return this._bezierPoint(segment.p0, segment.p1, segment.p2, segment.p3, localProgress);
    }
    return null;
  }

  _vineGeometry(vine, positions) {
    const source = positions[vine.from];
    if (!source || !vine.branches.length) return null;
    const sourceRadius = this._nodeRadius(this._nodeData[vine.from]);
    const sourceBottomExtent = this._nodeVerticalExtent(this._nodeData[vine.from], "bottom");
    const trunkX = Number.isFinite(vine.stemX) ? vine.stemX : source.x;
    const sourceDirection = Math.sign(trunkX - source.x) || 1;
    const usesSideEntry = vine.entryMode === "side" && Math.abs(trunkX - source.x) > 1;
    const sourceX = usesSideEntry
      ? source.x + sourceDirection * (sourceRadius + 1)
      : source.x;
    const sourceY = usesSideEntry ? source.y : source.y + sourceBottomExtent + 1;
    const routedBranches = vine.branches.map(({ to }) => {
      const target = positions[to];
      if (!target) return null;
      const targetY = target.y - this._nodeVerticalExtent(this._nodeData[to], "top") - 1;
      return { to, target, targetY, branchY: targetY - 34 };
    }).filter(Boolean);
    if (!routedBranches.length) return null;
    return {
      sourceX,
      sourceY,
      trunkX,
      usesSideEntry,
      firstBranchY: Math.min(...routedBranches.map(({ branchY }) => branchY)),
      stemEndY: Math.max(...routedBranches.map(({ branchY }) => branchY)),
      routedBranches,
    };
  }

  _vineEntrySegments(geometry) {
    const start = { x: geometry.sourceX, y: geometry.sourceY };
    const end = { x: geometry.trunkX, y: geometry.firstBranchY };
    if (geometry.usesSideEntry) {
      const direction = Math.sign(geometry.trunkX - geometry.sourceX) || 1;
      const horizontalHandle = Math.min(120, Math.max(36, Math.abs(geometry.trunkX - geometry.sourceX) * 0.48));
      return [{
        kind: "bezier",
        p0: start,
        p1: { x: geometry.sourceX + direction * horizontalHandle, y: geometry.sourceY },
        p2: { x: geometry.trunkX, y: geometry.firstBranchY - 24 },
        p3: end,
      }];
    }
    if (Math.abs(geometry.trunkX - geometry.sourceX) <= 1) return [{ kind: "line", from: start, to: end }];

    const middleX = (geometry.sourceX + geometry.trunkX) / 2;
    const middleY = (geometry.sourceY + geometry.firstBranchY) / 2;
    const direction = Math.sign(geometry.trunkX - geometry.sourceX) || 1;
    const horizontalHandle = Math.min(64, Math.max(20, Math.abs(geometry.trunkX - geometry.sourceX) * 0.16));
    const middle = { x: middleX, y: middleY };
    return [
      {
        kind: "bezier",
        p0: start,
        p1: { x: geometry.sourceX, y: middleY },
        p2: { x: middleX - direction * horizontalHandle, y: middleY },
        p3: middle,
      },
      {
        kind: "bezier",
        p0: middle,
        p1: { x: middleX + direction * horizontalHandle, y: middleY },
        p2: { x: geometry.trunkX, y: middleY },
        p3: end,
      },
    ];
  }

  _vineBranchSegment(geometry, branch) {
    return {
      kind: "bezier",
      p0: { x: geometry.trunkX, y: branch.branchY },
      p1: { x: geometry.trunkX, y: branch.branchY + 18 },
      p2: { x: branch.target.x, y: branch.branchY - 18 },
      p3: { x: branch.target.x, y: branch.targetY },
    };
  }

  _vineParticlePoint(edge, positions, progress) {
    const vine = this._vineEdges.find((candidate) =>
      candidate.from === edge.from && candidate.branches.some(({ to }) => to === edge.to));
    if (!vine) return null;
    const geometry = this._vineGeometry(vine, positions);
    const branch = geometry?.routedBranches.find(({ to }) => to === edge.to);
    if (!geometry || !branch) return null;
    const segments = [
      ...this._vineEntrySegments(geometry),
      {
        kind: "line",
        from: { x: geometry.trunkX, y: geometry.firstBranchY },
        to: { x: geometry.trunkX, y: branch.branchY },
      },
      this._vineBranchSegment(geometry, branch),
    ];
    return this._pointOnSegments(segments, progress);
  }

  _drawActiveFlow(ctx) {
    if (!this._network || !this._activeEdges.length) return;
    const positions = this._network.getPositions();
    const time = this._reduceMotion ? 0 : this._motionTime;

    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const edge of this._activeEdges) {
      const from = positions[edge.from];
      const to = positions[edge.to];
      if (
        !from || !to ||
        !Number.isFinite(from.x) || !Number.isFinite(from.y) ||
        !Number.isFinite(to.x) || !Number.isFinite(to.y)
      ) continue;
      const color = edge.color || STATUS_VISUALS.running;
      const midY = (from.y + to.y) / 2;

      const pointOnCurve = (progress) => {
        const vinePoint = this._vineParticlePoint(edge, positions, progress);
        if (vinePoint) return vinePoint;
        const inverse = 1 - progress;
        return {
          x: inverse ** 3 * from.x
            + 3 * inverse ** 2 * progress * from.x
            + 3 * inverse * progress ** 2 * to.x
            + progress ** 3 * to.x,
          y: inverse ** 3 * from.y
            + 3 * inverse ** 2 * progress * midY
            + 3 * inverse * progress ** 2 * midY
            + progress ** 3 * to.y,
        };
      };

      const particleCount = this._reduceMotion || this._nodes.length >= 500 ? 1 : 2;
      for (let index = 0; index < particleCount; index++) {
        const progress = this._reduceMotion
          ? 0.6
          : ((time / 1500 + index / particleCount + edge.phase) % 1);
        const point = pointOnCurve(progress);
        const fade = Math.sin(progress * Math.PI);
        ctx.beginPath();
        ctx.arc(point.x, point.y, 2.1, 0, Math.PI * 2);
        ctx.fillStyle = rgba(color.edge, 0.28 + fade * 0.62);
        ctx.shadowColor = rgba(color.color, 0.9);
        ctx.shadowBlur = 9;
        ctx.fill();
      }
    }
    ctx.restore();
  }

  _animationInterval() {
    return this._nodes.length >= 500 ? 200 : this._nodes.length >= 150 ? 100 : 32;
  }

  _animationVisible() {
    return !document.hidden && this._viewportVisible;
  }

  _stopAnimation() {
    if (this._animationFrame !== null) cancelAnimationFrame(this._animationFrame);
    if (this._animationTimer !== null) clearTimeout(this._animationTimer);
    this._animationFrame = null;
    this._animationTimer = null;
  }

  _syncAnimation() {
    if (this._reduceMotion) this._nodeTransitions.clear();
    const needsAnimation = !this._reduceMotion && this._animationVisible()
      && (this._hasRunningNodes || this._hasLiveTransitions());
    if (!needsAnimation) {
      this._stopAnimation();
      // Commit terminal status even if a throttled frame has not fired yet.
      this._network?.redraw();
      return;
    }
    if (this._animationFrame !== null || this._animationTimer !== null) return;

    const animate = (time) => {
      this._animationFrame = null;
      if (!this._animationVisible()) return;
      this._motionTime = time;
      const interval = this._animationInterval();
      if (time - this._lastAnimationPaint >= interval) {
        this._lastAnimationPaint = time;
        this._network?.redraw();
      }
      if (!this._reduceMotion && (this._hasRunningNodes || this._hasLiveTransitions())) {
        if (interval === 32) {
          // Preserve the existing small-graph 30fps cadence.
          this._animationFrame = requestAnimationFrame(animate);
        } else {
          // Large graphs sleep between paints instead of waking every frame.
          this._animationTimer = setTimeout(() => {
            this._animationTimer = null;
            this._animationFrame = requestAnimationFrame(animate);
          }, interval);
        }
      } else {
        this._network?.redraw();
      }
    };
    this._animationFrame = requestAnimationFrame(animate);
  }

  _timeKey(node) {
    const value = node?.start_time ? new Date(node.start_time).getTime() : NaN;
    return Number.isFinite(value) ? value : Number.MAX_SAFE_INTEGER;
  }

  _executionBatchId(node, plannerId) {
    // batch_id is optional for older graph snapshots. Untagged direct siblings
    // belong to one legacy batch rather than being split into one layer per
    // node: sequential dispatch is still work from the same planning round.
    // New snapshots carry explicit IDs, so replanning rounds remain separate.
    return String(
      node.batch_id
      ?? node.execution_batch_id
      ?? node.input?.batch_id
      ?? node.input?.execution_batch_id
      ?? `legacy:${plannerId}`,
    );
  }

  _chronologicalTaskRows(nodeIds, nodeMap) {
    const timed = nodeIds.map((id) => {
      const node = nodeMap[id];
      const startValue = node?.start_time ? new Date(node.start_time).getTime() : NaN;
      const endValue = node?.end_time ? new Date(node.end_time).getTime() : NaN;
      return {
        id,
        start: startValue,
        hasStart: Number.isFinite(startValue),
        // An unfinished task keeps its row open. That makes concurrently
        // running work stay together instead of being rendered as a sequence.
        end: Number.isFinite(endValue) ? endValue : Number.MAX_SAFE_INTEGER,
      };
    }).sort((a, b) => {
      if (a.hasStart !== b.hasStart) return a.hasStart ? -1 : 1;
      return a.start - b.start || a.id.localeCompare(b.id);
    });

    if (!timed.some((task) => task.hasStart)) return [nodeIds];

    const rows = [];
    let rowEnd = -Infinity;
    timed.forEach((task) => {
      // A snapshot without a start time has no reliable chronology. Keep it
      // beside the current wave instead of inventing a sequential ordering.
      if (!task.hasStart) {
        rows[rows.length - 1].push(task.id);
        return;
      }
      if (!rows.length || task.start >= rowEnd) {
        rows.push([task.id]);
        rowEnd = task.end;
      } else {
        rows[rows.length - 1].push(task.id);
        rowEnd = Math.max(rowEnd, task.end);
      }
    });
    return rows;
  }

  _sequenceTaskDisplayEdges(displayEdges, nodeMap) {
    // Current graph snapshots include dependency_ids for every step, including
    // roots (where it is an empty list).  Their edge list is therefore the
    // execution DAG itself and must never be rewritten from timing: unrelated
    // tasks can happen to start in adjacent waves.
    const hasExplicitStepDependencies = Object.values(nodeMap).some((node) =>
      node?.type === "step" && Array.isArray(node.dependency_ids));
    if (hasExplicitStepDependencies) return displayEdges;

    const directTaskEdges = new Map();
    displayEdges.forEach((edge) => {
      if (nodeMap[edge.from]?.type !== "execution" || nodeMap[edge.to]?.type !== "step") return;
      if (!directTaskEdges.has(edge.from)) directTaskEdges.set(edge.from, []);
      directTaskEdges.get(edge.from).push(edge);
    });
    if (!directTaskEdges.size) return displayEdges;

    const replacedEdgeIds = new Set();
    const sequenceEdges = [];
    directTaskEdges.forEach((taskEdges, executionId) => {
      const rows = this._chronologicalTaskRows(taskEdges.map((edge) => edge.to), nodeMap);
      if (rows.length < 2) return;
      taskEdges.forEach((edge) => replacedEdgeIds.add(edge.id));

      // The first concurrent wave keeps E as its source. Later waves receive
      // their visual connection from the preceding wave, yielding E -> 1 -> 2
      // for a sequential pair while preserving same-row parallelism.
      rows[0].forEach((to) => sequenceEdges.push({
        id: `sequence__${executionId}__${to}`,
        from: executionId,
        to,
      }));
      for (let rowIndex = 1; rowIndex < rows.length; rowIndex++) {
        const previous = rows[rowIndex - 1];
        // A following wave begins only after the preceding parallel wave has
        // completed. Draw every predecessor so a join such as 1 + 2 -> 3
        // keeps both dependency lines rather than silently choosing task 1.
        previous.forEach((from) => rows[rowIndex].forEach((to) => sequenceEdges.push({
          id: `sequence__${executionId}__${from}__${to}`,
          from,
          to,
        })));
      }
    });
    return [
      ...displayEdges.filter((edge) => !replacedEdgeIds.has(edge.id)),
      ...sequenceEdges,
    ];
  }

  _measureVineSubtree(rootId, children, nodeMap) {
    const rows = [];
    const seen = new Set([rootId]);
    let frontier = [rootId];
    while (frontier.length) {
      const next = [];
      frontier.forEach((parentId) => children[parentId].forEach((childId) => {
        if (!seen.has(childId) && nodeMap[childId]?.type !== "execution") {
          seen.add(childId);
          next.push(childId);
        }
      }));
      if (!next.length) break;
      rows.push(next);
      frontier = next;
    }
    const widestRow = Math.max(0, ...rows.map((ids) => (ids.length - 1) * VINE_NODE_GAP));
    return {
      rootId,
      rows,
      maxDepth: rows.length,
      width: Math.max(VINE_NODE_GAP, widestRow + VINE_NODE_GAP),
    };
  }

  _layoutVineBatches(batchRows, spineX, startY, children, nodeMap, options = {}) {
    const { centerLatest = true } = options;
    const batchPositions = {};
    let previousBatchY = startY - VINE_BATCH_STAGGER;
    // Tree kinds share alternating lanes, subtree measurement, and the final
    // centered tip. Historical batches stay to the sides of the main spine.
    const sideClearY = new Map([[-1, startY], [1, startY]]);

    batchRows.forEach((rootIds, batchIndex) => {
      const orderedRootIds = [...rootIds].sort((a, b) =>
        this._timeKey(nodeMap[a]) - this._timeKey(nodeMap[b]) || a.localeCompare(b));
      const isCenteredTip = centerLatest && batchIndex === batchRows.length - 1;
      const subtrees = orderedRootIds.map((rootId) =>
        this._measureVineSubtree(rootId, children, nodeMap));
      const batchWidth = subtrees.reduce((total, subtree) => total + subtree.width, 0);
      const maxDepth = Math.max(0, ...subtrees.map((subtree) => subtree.maxDepth));
      const subtreeHalfWidth = batchWidth / 2 + this._nodeRadius({ type: "step" });
      const side = batchIndex % 2 === 0 ? 1 : -1;
      const nextStaggerY = previousBatchY + VINE_BATCH_STAGGER;
      const batchY = isCenteredTip
        ? Math.max(nextStaggerY, ...sideClearY.values())
        : Math.max(nextStaggerY, sideClearY.get(side));
      const batchCenterX = isCenteredTip
        ? spineX
        : spineX + side * (subtreeHalfWidth + VINE_STEM_CLEARANCE);

      let subtreeLeft = batchCenterX - batchWidth / 2;
      subtrees.forEach((subtree) => {
        const rootX = subtreeLeft + subtree.width / 2;
        batchPositions[subtree.rootId] = { x: rootX, y: batchY };
        subtree.rows.forEach((ids, depthIndex) => {
          const rowWidth = (ids.length - 1) * VINE_NODE_GAP;
          ids.forEach((id, index) => {
            batchPositions[id] = {
              x: rootX + index * VINE_NODE_GAP - rowWidth / 2,
              y: batchY + (depthIndex + 1) * VINE_DESCENDANT_GAP,
            };
          });
        });
        subtreeLeft += subtree.width;
      });
      previousBatchY = batchY;
      if (!isCenteredTip) {
        sideClearY.set(
          side,
          batchY + maxDepth * VINE_DESCENDANT_GAP + VINE_BATCH_STAGGER,
        );
      }
    });
    return batchPositions;
  }

  _computeVineLayout(rawNodes, edges) {
    const nodeMap = Object.fromEntries(rawNodes.map((node) => [node.id, node]));
    const children = Object.fromEntries(rawNodes.map((node) => [node.id, []]));
    (edges || []).forEach((edge) => {
      if (children[edge.from] && nodeMap[edge.to]) children[edge.from].push(edge.to);
    });
    Object.values(children).forEach((ids) => ids.sort((a, b) =>
      this._timeKey(nodeMap[a]) - this._timeKey(nodeMap[b]) || String(a).localeCompare(String(b))));

    const positions = {};
    const placed = new Set();
    const planners = rawNodes.filter((node) => node.type === "planning")
      .sort((a, b) => this._timeKey(a) - this._timeKey(b) || a.id.localeCompare(b.id));
    const plannerCount = planners.length;
    this._vineStemX = new Map();

    planners.forEach((planner, plannerIndex) => {
      const plannerX = (plannerIndex - (plannerCount - 1) / 2) * VINE_PLANNER_GAP;
      this._vineStemX.set(planner.id, plannerX);
      positions[planner.id] = { x: plannerX, y: 0 };
      placed.add(planner.id);

      const batches = new Map();
      children[planner.id]
        .filter((id) => nodeMap[id]?.type === "execution")
        .forEach((id) => {
          const batchId = this._executionBatchId(nodeMap[id], planner.id);
          if (!batches.has(batchId)) batches.set(batchId, []);
          batches.get(batchId).push(id);
        });
      const orderedBatches = [...batches.entries()].sort(([aId, a], [bId, b]) => {
        const aTime = Math.min(...a.map((id) => this._timeKey(nodeMap[id])));
        const bTime = Math.min(...b.map((id) => this._timeKey(nodeMap[id])));
        return aTime - bTime || aId.localeCompare(bId);
      });

      const plannerPositions = this._layoutVineBatches(
        orderedBatches.map(([, executionIds]) => executionIds),
        plannerX,
        VINE_BATCH_GAP,
        children,
        nodeMap,
      );
      Object.entries(plannerPositions).forEach(([nodeId, position]) => {
        positions[nodeId] = position;
        placed.add(nodeId);
      });
    });

    // Steps directly launched by O are peers of planning, not malformed
    // leftovers. Give them their own right-hand lane while retaining their
    // real O -> step edge and any nested subagent tree below each step.
    const directRoots = rawNodes
      .filter((node) => this._isDirectOrchestratorStep(node))
      .filter((node) => !Array.isArray(node.dependency_ids) || node.dependency_ids.length === 0)
      .sort((a, b) => this._timeKey(a) - this._timeKey(b) || a.id.localeCompare(b.id));
    if (directRoots.length) {
      const rows = this._chronologicalTaskRows(directRoots.map((node) => node.id), nodeMap);
      const rightmostPlannerX = planners.length
        ? Math.max(...planners.map((planner) => positions[planner.id].x))
        : 0;
      const directPositionsForLane = (directLaneX) => this._layoutVineBatches(
        rows,
        directLaneX,
        0,
        children,
        nodeMap,
      );
      const intersectsPlacedNode = (candidatePositions) => Object.entries(candidatePositions).some(
        ([candidateId, candidate]) => [...placed].some((placedId) => {
          const occupied = positions[placedId];
          if (!occupied) return false;
          const minimumDistance = this._nodeRadius(nodeMap[candidateId])
            + this._nodeRadius(nodeMap[placedId])
            + DIRECT_LANE_CLEARANCE;
          return Math.hypot(candidate.x - occupied.x, candidate.y - occupied.y) < minimumDistance;
        }),
      );
      // Start compact and move only when nodes at their actual levels collide.
      // Whole-tree bounding boxes were too conservative: branches at very
      // different heights forced large horizontal gaps despite never meeting.
      let directLaneX = planners.length ? rightmostPlannerX + VINE_NODE_GAP * 1.5 : 0;
      let directPositions = directPositionsForLane(directLaneX);
      while (intersectsPlacedNode(directPositions)) {
        directLaneX += VINE_NODE_GAP / 2;
        directPositions = directPositionsForLane(directLaneX);
      }

      if (planners.length) {
        // O is the fork between two peer trunks. Recenter the already-spaced
        // trees around it instead of leaving P fixed beneath O and pushing
        // only the Flash tree outward.
        const planningSpineCenter = planners.reduce(
          (sum, planner) => sum + this._vineStemX.get(planner.id),
          0,
        ) / planners.length;
        const forkCenter = (planningSpineCenter + directLaneX) / 2;
        placed.forEach((nodeId) => {
          positions[nodeId].x -= forkCenter;
        });
        planners.forEach((planner) => {
          this._vineStemX.set(planner.id, this._vineStemX.get(planner.id) - forkCenter);
        });
        Object.values(directPositions).forEach((position) => {
          position.x -= forkCenter;
        });
        directLaneX -= forkCenter;
      }
      Object.entries(directPositions).forEach(([nodeId, position]) => {
        positions[nodeId] = position;
        placed.add(nodeId);
      });
      this._vineStemX.set("orchestrator", directLaneX);
    }

    // Leave enough headroom for the two root arms to form broad brace curves.
    // Any malformed or unrelated node remains visible in a small fallback
    // strip instead of being silently omitted from the graph.
    rawNodes.filter((node) => node.type === "orchestrator").forEach((node, index) => {
      positions[node.id] = { x: index * VINE_PLANNER_GAP, y: -VINE_ROOT_GAP };
      placed.add(node.id);
    });
    rawNodes.filter((node) => !placed.has(node.id)).forEach((node, index) => {
      positions[node.id] = { x: index * VINE_NODE_GAP, y: VINE_BATCH_GAP };
    });
    return positions;
  }

  _drawVines(ctx) {
    if (!this._network || !this._vineEdges.length) return;
    const positions = this._network.getPositions();
    const isLight = this._graphSurfaceIsLight;
    const color = isLight ? "#8290a3" : "#64748b";
    ctx.save();
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineWidth = 1.7;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    this._vineEdges.forEach((vine) => {
      const geometry = this._vineGeometry(vine, positions);
      if (!geometry) return;

      // The stem is drawn once, so planning rounds and O-dispatched Flash
      // batches read as one tree rather than a bundle of unrelated long edges.
      ctx.beginPath();
      ctx.moveTo(geometry.sourceX, geometry.sourceY);
      this._vineEntrySegments(geometry).forEach((segment) => {
        if (segment.kind === "line") ctx.lineTo(segment.to.x, segment.to.y);
        else ctx.bezierCurveTo(
          segment.p1.x, segment.p1.y,
          segment.p2.x, segment.p2.y,
          segment.p3.x, segment.p3.y,
        );
      });
      ctx.lineTo(geometry.trunkX, geometry.stemEndY);
      ctx.stroke();

      geometry.routedBranches.forEach((branch) => {
        const { target, targetY } = branch;
        const segment = this._vineBranchSegment(geometry, branch);
        ctx.beginPath();
        ctx.moveTo(segment.p0.x, segment.p0.y);
        ctx.bezierCurveTo(
          segment.p1.x, segment.p1.y,
          segment.p2.x, segment.p2.y,
          segment.p3.x, segment.p3.y,
        );
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(target.x, targetY);
        ctx.lineTo(target.x - 4, targetY - 7);
        ctx.lineTo(target.x + 4, targetY - 7);
        ctx.closePath();
        ctx.fill();
      });
    });
    ctx.restore();
  }

  _buildDisplayEdges(rawNodes, edges) {
    const nodeMap = Object.fromEntries(rawNodes.map((n) => [n.id, n]));
    const phaseTypes = new Set(["planning", "execution", "tester"]);
    const displayEdges = [];
    const phaseNodes = rawNodes
      .filter((n) => phaseTypes.has(n.type))
      .sort((a, b) => {
        const ta = a.start_time ? new Date(a.start_time).getTime() : Infinity;
        const tb = b.start_time ? new Date(b.start_time).getTime() : Infinity;
        return ta - tb;
      });

    const planningNodes = phaseNodes.filter((node) => node.type === "planning");
    const childPhaseNodes = phaseNodes.filter((node) => node.type !== "planning");

    planningNodes.forEach((planning) => {
      displayEdges.push({
        id: `phase__orchestrator__${planning.id}`,
        from: "orchestrator",
        to: planning.id,
      });
    });

    // Newer graph records persist the actual planning parent. Older sessions
    // logged every phase under the orchestrator, so retain temporal grouping as
    // a backwards-compatible fallback.
    childPhaseNodes.forEach((node) => {
      const persistedParent = nodeMap[node.parent_id];
      if (persistedParent?.type === "planning") {
        displayEdges.push({
          id: `phase__${persistedParent.id}__${node.id}`,
          from: persistedParent.id,
          to: node.id,
        });
        return;
      }

      const nodeStart = node.start_time ? new Date(node.start_time).getTime() : Infinity;
      let parentPlanning = null;
      for (const planning of planningNodes) {
        const planningStart = planning.start_time
          ? new Date(planning.start_time).getTime()
          : -Infinity;
        if (planningStart <= nodeStart) parentPlanning = planning;
        else break;
      }

      const parentId = parentPlanning?.id || "orchestrator";
      displayEdges.push({
        id: `phase__${parentId}__${node.id}`,
        from: parentId,
        to: node.id,
      });
    });

    (edges || []).forEach((edge) => {
      const fromNode = nodeMap[edge.from];
      const toNode = nodeMap[edge.to];
      if (!fromNode || !toNode) return;

      // Phase relationships are normalized above. Ignore their persisted
      // incoming edges so sessions created by either logger version render
      // with the same Planning -> Execution grouping.
      if (phaseTypes.has(toNode.type)) return;

      displayEdges.push({
        id: edge.id || `${edge.from}__${edge.to}`,
        from: edge.from,
        to: edge.to,
      });
    });

    return this._sequenceTaskDisplayEdges(displayEdges, nodeMap);
  }

  _resizeSurface() {
    if (!this._surfaceEl || !this._graphViewport) return null;

    // Match the canvas to the visible viewport exactly; larger off-screen
    // surfaces make fit() center against hidden space instead of the panel.
    const targetWidth = Math.max(1, Math.round(this._graphViewport.clientWidth || 1));
    const targetHeight = Math.max(1, Math.round(this._graphViewport.clientHeight || 1));
    const width = `${targetWidth}px`;
    const height = `${targetHeight}px`;
    if (this._surfaceEl.style.width === width && this._surfaceEl.style.height === height) return null;
    this._surfaceEl.style.width = width;
    this._surfaceEl.style.height = height;
    return { width, height };
  }

  _fitGraph() {
    if (!this._network || this._nodes.length === 0) return;
    requestAnimationFrame(() => {
      if (!this._network || this._nodes.length === 0) return;
      this._network.redraw();
      this._network.fit({ animation: { duration: 300, easingFunction: "easeInOutQuad" } });
      this._didInitialFit = true;
      this._pendingFit = false;
    });
  }

  _graphLayoutKey(rawNodes, edges) {
    // Conversation/tool payloads can grow without changing graph geometry.
    // Keep them out of this key so those hot updates reuse the cold layout.
    return JSON.stringify({
      nodes: rawNodes.map((node) => [
        node.id,
        node.type,
        node.parent_id || "",
        node.batch_id || node.execution_batch_id || "",
        node.start_time || "",
        node.end_time || "",
        node.input?.node_id || node.input?.step_id || "",
      ]),
      edges: (edges || []).map((edge) => [edge.id || "", edge.from, edge.to]),
    });
  }

  _nodeVisualKey(node) {
    return JSON.stringify([
      node.status,
      node.type,
      node.label,
      node.summary,
      node.start_time,
      node.end_time,
      node.input?.step_number,
    ]);
  }

  _nodeDetailKey(node) {
    return node ? graphNodeRevision(node) : "";
  }

  update(incomingGraphData) {
    if (!incomingGraphData || typeof incomingGraphData.nodes !== "object") return;
    const patch = applyGraphUpdate(this._graphSnapshot, {
      ...incomingGraphData,
      nodes: Object.fromEntries(Object.entries(incomingGraphData.nodes)
        .map(([id, node]) => [id, graphNodeSummary(node)])),
    });
    const graphData = patch.graph;
    this._graphSnapshot = graphData;

    const layoutMayChange = !patch.isDelta || patch.layoutChanged;
    const prevNodeIds = layoutMayChange ? new Set(this._nodes.getIds()) : null;
    const prevEdgeIds = layoutMayChange ? new Set(this._edges.getIds()) : null;
    let rawNodeMap;
    if (patch.isDelta) {
      rawNodeMap = { ...this._nodeData };
      for (const id of patch.changedNodeIds) {
        const node = graphData.nodes[id];
        if (!node) {
          delete rawNodeMap[id];
          continue;
        }
        const status = this._normalizeNodeStatus(node.status);
        rawNodeMap[id] = status === node.status ? node : { ...node, status };
      }
    } else {
      rawNodeMap = Object.fromEntries(Object.values(graphData.nodes).map((node) => {
        const status = this._normalizeNodeStatus(node.status);
        const normalized = status === node.status ? node : { ...node, status };
        return [normalized.id, normalized];
      }));
    }
    const rawNodes = Object.values(rawNodeMap);
    const transitionStartedAt = performance.now();
    const nextNodeStatuses = patch.isDelta ? new Map(this._lastNodeStatuses) : new Map();
    if (!patch.isDelta) this._runningNodeIds.clear();
    const statusNodes = patch.isDelta
      ? [...patch.changedNodeIds].map((id) => rawNodeMap[id]).filter(Boolean)
      : rawNodes;
    patch.changedNodeIds.forEach((id) => {
      if (!rawNodeMap[id]) {
        nextNodeStatuses.delete(id);
        this._runningNodeIds.delete(id);
      }
    });
    statusNodes.forEach((node) => {
      const previousStatus = this._lastNodeStatuses.get(node.id);
      if (!this._reduceMotion && previousStatus && previousStatus !== node.status) {
        this._nodeTransitions.set(node.id, {
          from: previousStatus,
          to: node.status,
          startedAt: transitionStartedAt,
        });
      }
      nextNodeStatuses.set(node.id, node.status);
      if (node.status === "running") this._runningNodeIds.add(node.id);
      else this._runningNodeIds.delete(node.id);
    });
    this._lastNodeStatuses = nextNodeStatuses;
    this._nodeData = rawNodeMap;
    this._stepExecutionFeed.update(graphData, patch);
    const layoutKey = patch.isDelta && !patch.layoutChanged
      ? this._layoutKey
      : this._graphLayoutKey(rawNodes, graphData.edges || []);
    const layoutChanged = patch.isDelta ? patch.layoutChanged : layoutKey !== this._layoutKey;
    if (layoutChanged) {
      this._layoutKey = layoutKey;
      this._cachedDisplayEdges = this._buildDisplayEdges(rawNodes, graphData.edges || []);
      this._displayEdgesByNode = new Map();
      this._edgePhases = new Map();
      this._cachedDisplayEdges.forEach((edge, index) => {
        const edgeId = edge.id || `${edge.from}__${edge.to}`;
        this._edgePhases.set(edgeId, (index * 0.173) % 1);
        for (const nodeId of [edge.from, edge.to]) {
          const adjacent = this._displayEdgesByNode.get(nodeId) || [];
          adjacent.push(edge);
          this._displayEdgesByNode.set(nodeId, adjacent);
        }
      });
      this._cachedPositions = this._computeVineLayout(rawNodes, this._cachedDisplayEdges);
      this._cachedVineEdgeIds = new Set(this._cachedDisplayEdges
        .filter((edge) => this._isRoutedVineEdge(edge, rawNodeMap))
        .map((edge) => edge.id || `${edge.from}__${edge.to}`));
    }
    const displayEdges = this._cachedDisplayEdges;
    this._hasRunningNodes = this._runningNodeIds.size > 0;
    const activeEdgeIds = new Set();
    this._activeEdges = [];
    for (const nodeId of this._runningNodeIds) {
      for (const edge of this._displayEdgesByNode.get(nodeId) || []) {
        const edgeId = edge.id || `${edge.from}__${edge.to}`;
        if (activeEdgeIds.has(edgeId)
          || rawNodeMap[edge.from]?.status !== "running"
          || rawNodeMap[edge.to]?.status !== "running") continue;
        activeEdgeIds.add(edgeId);
        this._activeEdges.push({
          ...edge,
          color: STATUS_VISUALS.running,
          phase: this._edgePhases.get(edgeId) || 0,
        });
      }
    }
    const positions = this._cachedPositions;
    const vineEdgeIds = this._cachedVineEdgeIds;
    if (layoutChanged) {
      const vineGroups = new Map();
      displayEdges.forEach((edge) => {
        if (!vineEdgeIds.has(edge.id || `${edge.from}__${edge.to}`)) return;
        const route = this._vineRouteForEdge(edge, rawNodeMap);
        if (!route) return;
        if (!vineGroups.has(route.key)) {
          vineGroups.set(route.key, {
            from: edge.from,
            stemX: route.stemX,
            entryMode: route.entryMode,
            targetIds: [],
          });
        }
        vineGroups.get(route.key).targetIds.push(edge.to);
      });
      this._vineEdges = [...vineGroups.values()].map((group) => {
        const { from, stemX, targetIds } = group;
        const sourceX = this._cachedPositions[from]?.x;
        return {
          from,
          stemX,
          entryMode: Number.isFinite(stemX)
            && Number.isFinite(sourceX)
            && Math.abs(stemX - sourceX) > 1
            ? group.entryMode
            : "bottom",
          branches: targetIds
            .sort((a, b) => this._timeKey(rawNodeMap[a]) - this._timeKey(rawNodeMap[b]) || a.localeCompare(b))
            .map((to) => ({ to })),
        };
      });
    }
    this._resizeSurface();
    const nextNodeIds = layoutChanged ? new Set(rawNodes.map((raw) => raw.id)) : null;
    const nextEdgeIds = layoutChanged
      ? new Set(displayEdges.map((e) => e.id || `${e.from}__${e.to}`))
      : null;
    const topologyChanged = layoutChanged && (
      prevNodeIds.size !== nextNodeIds.size ||
      prevEdgeIds.size !== nextEdgeIds.size ||
      [...nextNodeIds].some((id) => !prevNodeIds.has(id)) ||
      [...nextEdgeIds].some((id) => !prevEdgeIds.has(id))
    );

    if (layoutChanged) this._nodes.getIds().forEach((nodeId) => {
      if (!nextNodeIds.has(nodeId)) this._nodes.remove(nodeId);
    });

    const nextNodeVisualKeys = layoutChanged || !patch.isDelta
      ? new Map()
      : new Map(this._nodeVisualKeys);
    const nodesToUpdate = layoutChanged || !patch.isDelta
      ? rawNodes
      : [...patch.changedNodeIds].map((id) => rawNodeMap[id]).filter(Boolean);
    patch.changedNodeIds.forEach((id) => {
      if (!rawNodeMap[id]) nextNodeVisualKeys.delete(id);
    });
    nodesToUpdate.forEach((raw) => {
      const visualKey = this._nodeVisualKey(raw);
      nextNodeVisualKeys.set(raw.id, visualKey);
      const isNew = !this._nodes.get(raw.id);
      if (!isNew && !layoutChanged && this._nodeVisualKeys.get(raw.id) === visualKey) return;
      const vis = this._visNode(raw);
      const position = positions[raw.id] || { x: 0, y: 0 };
      vis.x = position.x;
      vis.y = position.y;
      vis.fixed = { x: true, y: true };
      if (!isNew) {
        this._nodes.update(vis);
      } else {
        this._nodes.add(vis);
      }
    });
    this._nodeVisualKeys = nextNodeVisualKeys;

    if (layoutChanged) this._edges.getIds().forEach((edgeId) => {
      if (!nextEdgeIds.has(edgeId)) this._edges.remove(edgeId);
    });

    if (layoutChanged) displayEdges.forEach((e) => {
      const edgeId = e.id || `${e.from}__${e.to}`;
      const visEdge = {
        id: edgeId,
        from: e.from,
        to: e.to,
        // Root forks, planner batches, and O-dispatched Flash roots are
        // painted by the same routed-vine renderer in beforeDrawing. The
        // edges stay in the DataSet for interaction and future consumers.
        hidden: vineEdgeIds.has(edgeId),
        physics: false,
        width: 1.35,
        color: this._edgeColors(),
        smooth: { type: "cubicBezier", forceDirection: "vertical" },
      };
      if (this._edges.get(edgeId)) this._edges.update(visEdge);
      else this._edges.add(visEdge);
    });

    if (rawNodes.length > 0 && (topologyChanged || !this._didInitialFit || this._pendingFit)) {
      this._fitGraph();
    }
    this._syncAnimation();

    if (this._activeDetailNodeId) {
      if (this._nodeData[this._activeDetailNodeId]) {
        const detailKey = this._nodeDetailKey(this._nodeData[this._activeDetailNodeId]);
        if (detailKey !== this._detailRenderKey) {
          this._showDetail(this._activeDetailNodeId, { preserveScroll: true, scrollToStep: false });
        }
      } else {
        this._hideDetail();
      }
    }
  }

  startPolling(sessionId) {
    this.stopPolling();
    if (this._currentSessionId !== sessionId) this._hideDetail();
    this._currentSessionId = sessionId;
    void this._poll(sessionId);
    const eventStream = new EventSource(`/api/agent-graph/${encodeURIComponent(sessionId)}/events`);
    this._eventStream = eventStream;
    eventStream.onmessage = (event) => {
      try {
        if (sessionId !== this._currentSessionId) return;
        this.update(JSON.parse(event.data));
      } catch (_) {
        // Ignore a malformed snapshot; EventSource will deliver the next one.
      }
    };
    // Keep a low-frequency fallback for deployments running an older web
    // backend that does not yet expose the graph event endpoint. Close the
    // EventSource before starting it so browser reconnects cannot deliver the
    // same snapshots alongside the fallback poller.
    eventStream.onerror = () => {
      if (this._eventStream !== eventStream) return;
      eventStream.close();
      this._eventStream = null;
      if (!this._pollInterval) this._pollInterval = setInterval(() => this._poll(sessionId), 2000);
    };
  }

  stopPolling() {
    this._eventStream?.close();
    this._eventStream = null;
    if (this._pollInterval) {
      clearInterval(this._pollInterval);
      this._pollInterval = null;
    }
    // Polling owns the running-node animation lifecycle. A cancellation can
    // stop updates while the last received snapshot still says "running";
    // without clearing that stale flag the canvas redraw loop never ends.
    this._hasRunningNodes = false;
    this._activeEdges = [];
    this._nodeTransitions.clear();
    this._lastNodeStatuses.clear();
    this._runningNodeIds.clear();
    if (this._animationFrame !== null) cancelAnimationFrame(this._animationFrame);
    this._animationFrame = null;
    this._stopAnimation();
    this._network?.redraw();
  }

  async _poll(sessionId) {
    try {
      const data = await httpClient.getJson(`/api/agent-graph/${encodeURIComponent(sessionId)}`);
      if (data === null) return;
      if (sessionId !== this._currentSessionId) return;
      this.update(data);
    } catch (_) {
      // silently ignore network errors during polling
    }
  }

  reset() {
    this._currentSessionId = null;
    this._nodes.clear();
    this._edges.clear();
    this._nodeData = {};
    this._graphSnapshot = null;
    this._layoutKey = null;
    this._cachedDisplayEdges = [];
    this._cachedPositions = {};
    this._cachedVineEdgeIds = new Set();
    this._vineStemX.clear();
    this._displayEdgesByNode.clear();
    this._edgePhases.clear();
    this._nodeVisualKeys.clear();
    this._detailRenderKey = null;
    this._didInitialFit = false;
    this._pendingFit = true;
    this._hasRunningNodes = false;
    this._activeEdges = [];
    this._runningNodeIds.clear();
    this._detailDisclosures.clear();
    if (this._animationFrame !== null) cancelAnimationFrame(this._animationFrame);
    this._animationFrame = null;
    this._lastAnimationPaint = 0;
    this._resizeSurface([], { 0: 1 });
    this._hideDetail();
    this.stopPolling();
  }

  async _showDetail(nodeId, options = {}) {
    const summary = this._nodeData[nodeId];
    if (!summary) return;
    const key = this._nodeDetailKey(summary);
    if (this._activeDetailNodeId === nodeId && this._detailRequest) return;
    this._detailRequest?.abort();
    this._activeDetailNodeId = nodeId;
    this._detailRenderKey = key;
    const sessionId = this._currentSessionId;
    const controller = new AbortController();
    this._detailRequest = controller;
    // Render cheap metadata immediately and discard the previous node's DOM.
    this._renderDetail(nodeId, summary, options);
    this._detailSummary.textContent = "Loading task details…";
    try {
      const detail = await fetchAgentNodeDetail(sessionId, nodeId, controller.signal);
      if (controller.signal.aborted || this._currentSessionId !== sessionId || this._activeDetailNodeId !== nodeId) return;
      this._renderDetail(nodeId, detail, { ...options, scrollToStep: false });
    } catch (error) {
      if (!controller.signal.aborted) {
        this._detailSummary.textContent = "Could not load task details. Select the node to retry.";
      }
    } finally {
      if (this._detailRequest === controller) {
        this._detailRequest = null;
        if (!controller.signal.aborted && this._activeDetailNodeId === nodeId
          && key !== this._nodeDetailKey(this._nodeData[nodeId])) {
          void this._showDetail(nodeId, { preserveScroll: true, scrollToStep: false });
        }
      }
    }
  }

  _renderDetail(nodeId, raw, options = {}) {
    const preserveScroll = Boolean(options.preserveScroll);
    const prevScrollTop = preserveScroll ? this._detailEl.scrollTop : 0;
    this._detailLabel.textContent = raw.label;
    this._detailStatus.textContent = raw.status;
    this._detailStatus.className = `badge badge-${raw.status}`;
    this._detailSummary.textContent = raw.summary || "—";

    // Timing
    if (raw.start_time) {
      const start = new Date(raw.start_time);
      if (raw.end_time) {
        const end = new Date(raw.end_time);
        const secs = ((end - start) / 1000).toFixed(1);
        this._detailTiming.textContent = `${secs}s`;
      } else {
        this._detailTiming.textContent = "running…";
      }
    } else {
      this._detailTiming.textContent = "—";
    }

    // Stop-step button (only for running step nodes)
    const actionsRow = document.getElementById("detail-actions-row");
    const stopStepBtn = document.getElementById("detail-stop-step-btn");
    const stepNumber = raw.input && raw.input.step_number;
    if (raw.type === "step" && raw.status === "running" && stepNumber !== undefined && stepNumber !== null) {
      stopStepBtn.disabled = false;
      stopStepBtn.textContent = "Stop step";
      stopStepBtn.onclick = async () => {
        stopStepBtn.disabled = true;
        stopStepBtn.textContent = "Stopping…";
        await this._requestStepCancellation(stepNumber);
      };
      actionsRow.style.display = "";
    } else {
      stopStepBtn.onclick = null;
      actionsRow.style.display = "none";
    }
    this._detailArtifacts.innerHTML = "";
    const arts = raw.artifacts || [];
    if (arts.length) {
      arts.forEach((a) => {
        this._detailArtifacts.appendChild(this._createArtifactListItem(a));
      });
    } else {
      const li = document.createElement("li");
      li.textContent = "none";
      this._detailArtifacts.appendChild(li);
    }

    // Input parameters
    if (raw.input && Object.keys(raw.input).length) {
      this._detailInput.textContent = JSON.stringify(raw.input, null, 2);
      document.getElementById("detail-input-row").style.display = "";
    } else {
      this._detailInput.textContent = "";
      document.getElementById("detail-input-row").style.display = "none";
    }

    // Tool calls
    const toolCalls = raw.tool_calls || [];
    this._detailToolcallsCount.textContent = toolCalls.length;
    this._detailToolcalls.innerHTML = "";
    if (toolCalls.length) {
      toolCalls.forEach((tc, index) => {
        const d = this._renderStepToolCall(tc);
        const disclosureKey = `detail:${nodeId}:tool:${tc.id || `${index}:${tc.name}:${tc.start_time || ""}`}`;
        if (d?.tagName === "DETAILS") this._detailDisclosures.wire(d, disclosureKey);
        this._detailToolcalls.appendChild(d);
      });
      document.getElementById("detail-toolcalls-row").style.display = "";
    } else {
      document.getElementById("detail-toolcalls-row").style.display = "none";
    }

    // Conversation transcript is rendered live in the main chat step feed.
    const conversation = raw.type === "step" ? [] : (raw.conversation || []);
    this._detailConversation.innerHTML = "";
    this._detailConversationCount.textContent = conversation.length;
    if (conversation.length) {
      conversation.forEach((evt, index) => {
        const d = this._renderStepConversationEvent(evt);
        if (d?.tagName === "DETAILS") {
          this._detailDisclosures.wire(d, `detail:${nodeId}:conversation:${index}:${evt.timestamp || ""}:${evt.type || ""}`);
        }
        this._detailConversation.appendChild(d);
      });
      document.getElementById("detail-conversation-row").style.display = "";
    } else {
      document.getElementById("detail-conversation-row").style.display = "none";
    }

    this._detailEl.classList.remove("hidden");
    if (raw.type === "step" && options.scrollToStep !== false) this._stepExecutionFeed.highlight(raw.id);
    this._syncPanelResizerVisibility();
    if (preserveScroll) {
      this._detailEl.scrollTop = prevScrollTop;
    }
  }

  _hideDetail() {
    this._detailRequest?.abort();
    this._detailRequest = null;
    for (const element of [this._detailArtifacts, this._detailInput, this._detailToolcalls, this._detailConversation, this._detailSummary]) {
      element?.replaceChildren();
    }
    this._detailDisclosures.clear();
    const stopButton = document.getElementById("detail-stop-step-btn");
    if (stopButton) stopButton.onclick = null;
    this._activeDetailNodeId = null;
    this._detailRenderKey = null;
    this._detailEl.classList.add("hidden");
    this._syncPanelResizerVisibility();
  }

  notifyLayoutChanged() {
    this._syncAnimation();
    if (!this._network) return;
    const size = this._resizeSurface();
    if (size) {
      // vis-network's automatic resize observer can trail a CSS transition by
      // a frame. Resize its canvas explicitly so it never paints below the
      // adjacent Remote Jobs pane while the pane is moving.
      this._network.setSize(size.width, size.height);
      return;
    }
    this._network.redraw();
  }
}

// ---------------------------------------------------------------------------
// Execution Plan Graph (floating popup in chat column)
// ---------------------------------------------------------------------------
