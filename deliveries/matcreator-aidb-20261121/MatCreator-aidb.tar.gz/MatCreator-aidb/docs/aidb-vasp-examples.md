# AIDB 与 VASP 对话样例

第一个样例使用仓库已有的 Si PBE 弛豫输出，覆盖绑定、归档、查询和下载，不运行 VASP。后面的托管计算示例需要准备自己的输入与运行环境。

## 1. 本地演练：保存、查询与导出 Si 弛豫结果

在 Bash 中从包含 AIDB 改动的 MatCreator 仓库根目录运行。把 `session_workspace` 改为 Web 对话实际使用的工作区绝对路径。复制文件后，对话能通过 `aidb-demo/si-pbe-relax` 找到这对输出。

```bash
session_workspace=/absolute/path/to/session-workspace
fixture=tests/aidb/fixtures/vasp/si-pbe-relax
demo_dir=$(mktemp -d)
mkdir -p "$session_workspace/aidb-demo/si-pbe-relax"
cp "$fixture/vasprun.xml" "$fixture/OUTCAR" "$fixture/INCAR" "$fixture/KPOINTS" \
  "$session_workspace/aidb-demo/si-pbe-relax/"

python - "$demo_dir" <<'PY'
import json
import sys
from pathlib import Path

from ase.db import connect

demo_dir = Path(sys.argv[1]).resolve()
database = demo_dir / "archive.db"
sidecar = demo_dir / "archive.sidecar.json"
config = demo_dir / "config.json"

with connect(str(database)) as db:
    db.count()
sidecar.write_text('{"records": {}}\n', encoding="utf-8")
config.write_text(json.dumps({
    "database": {"backend": "ase_sqlite"},
    "ase_sqlite": {
        "path": str(database),
        "json_sidecar_path": str(sidecar),
        "max_query_keys_per_row": 64,
    },
}, indent=2) + "\n", encoding="utf-8")
print(config)
PY
```

在能访问这些文件的同一 Web 对话中依次发送。第一句填入脚本打印的配置路径。

```text
请把本次对话绑定到 /实际路径/config.json 这份 AIDB 配置。
```

```text
请把 aidb-demo/si-pbe-relax 目录里已经完成的 VASP 弛豫结果保存到 AIDB，告诉我读回的记录 ID。
```

```text
在当前 AIDB 中查询化学式为 Si、使用 PBE 且有逐原子力的记录。
```

查询结果应有一条记录。点击「详情」可核对 8 个 Si 原子、源帧索引 `2` 和约 `−43.38227814 eV/cell` 的总能量。点击「导出」获取 EXTXYZ，也可以使用对话：

```text
把上面那条 Si 记录导出成 EXTXYZ、POSCAR 和完整详情 HTML。
```

再次发送保存请求，核对记录 ID 与第一次相同。若需检查下载中的结构和标签，用运行 MatCreator 的 Python 环境打开文件：

```bash
python - /path/to/download.extxyz <<'PY'
import sys
from ase.io import read

frame = read(sys.argv[1])
print("atoms:", len(frame))
print("energy (eV/cell):", frame.get_potential_energy())
print("forces shape:", frame.get_forces().shape)
PY
```

预期力数组形状为 `(8, 3)`。能量和力可读说明文件携带这些标签，训练前仍需核对来源、方法和数据集口径。[样例验收记录](aidb-implementation/ticket02.md)

## 2. 计算前匹配与选择

将下面的目录换成自己的完整输入目录，选择已配置的后端。历史输出样例用于归档演练，托管计算需要独立准备 `POSCAR`、`INCAR`、`KPOINTS` 和 `POTCAR`。计算请求可能发起真实付费作业。

```text
请用 run/si-relax 中准备好的 VASP 输入，在 Bohrium Batch Job 上做 Si 弛豫。保留原始 vasprun.xml 和 OUTCAR。
```

若对话显示完全匹配的候选，可点击「详情」，再任选一种回答。用当前对话显示的编号替换示例中的编号。

```text
用第 1 条候选，给我可用的结果文件。
```

```text
继续用这批输入提交新的弛豫计算。
```

```text
取消本次计算。
```

选用分支直接交付已有结果。新计算分支可在原对话等待完成，检查原始文件、归档状态和记录 ID。[候选选择](aidb-implementation/ticket05.md) · [真实 Batch Job 验收](aidb-implementation/ticket06.md)

## 3. 其他计算请求

下列提示词可在各自的独立对话中使用。将示例路径替换为工作区文件或目录，补充所用计算参数和运行后端。

| 场景 | 示例请求 | 完成后核对 |
| --- | --- | --- |
| 静态 SCF | 用 `run/nacl-static` 中的 VASP 输入做 NaCl 静态 SCF，保留收敛结果和 CHGCAR。 | 静态能量、收敛状态，以及 CHGCAR 是否实际可用。 |
| 能带 | 对 `structures/Si.vasp` 先做均匀 k 网格的 SCF，再沿高对称路径做 NSCF 能带，给我能带数据和图。 | NSCF 使用的上游 SCF 产物，以及 `bands.json` 和 `bands.svg`。 |
| AIMD | 对 `structures/H2O.vasp` 做 300 K NVT，步长 1 fs，共 20 步，给我温度曲线和末帧。 | 实测温度点数、末帧 EXTXYZ 和原始输出。 |
| EOS | 以已验证的弛豫 Si 结构为基准，在体积 ±5% 内均匀取 11 个点做固定体积静态计算，给我 E–V 数据和图。 | 逐点状态和实际体积、能量，以及 E–V CSV 和 PNG。 |
| MatPES | 用 MatPES 对 `structures/batch.extxyz` 的各帧做静态标注，按源帧顺序返回可用的数据并列出失败项。 | 逐帧状态，有效数据顺序和导出文件。 |

[各工作流的输入、验证条件和证据](aidb-implementation/ticket14.md)

## 4. 回收已有作业

```text
请继续回收当前对话里作业 <作业 ID> 的已有输出，并重试 AIDB 归档。
```

在原对话核对作业 ID、沿用的产物以及按 ID 读回的记录。对于已有的本地输出，也可以在恢复数据库后重试最初的保存请求。[恢复与重复回收验收](aidb-implementation/ticket13.md)
