"""Markdown-backed workflow skills and search utilities for MatCreator.

Skills are now loaded in standard ADK format via the top-level skill.py
(google.adk.skills.load_skill_from_dir).  This module bridges ADK Skill
objects to the interface expected by the planning/execution agents and keeps
the guide system unchanged.
"""


import logging
import os
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from mimetypes import guess_type

from google.adk.skills import load_skill_from_dir
from google.adk.tools import skill_toolset
from google.adk.tools.function_tool import FunctionTool
from .workspace import workspace_skills_dir
from .tools.workspace_tools import run_skill_script
from .config import get_planning_skills
from .knowledge.kdg_memory import (
    is_entry_disabled,
    is_official_skill_entry,
    iter_entries_including_disabled,
    set_entry_disabled,
)
from pathlib import Path

logger = logging.getLogger(__name__)


def _discover_skill_dirs(skills_root: Path) -> list[Path]:
    """Return every directory under *skills_root* that contains ``SKILL.md``.

    This supports both the original one-level layout::

        skills/<name>/SKILL.md

    and nested skill bundles such as::

        skills/mattergen/mattergen_generation/SKILL.md
    """
    if not skills_root.exists():
        return []

    skill_dirs = {
        skill_md.parent
        for skill_md in skills_root.rglob("SKILL.md")
        if skill_md.is_file()
    }
    return sorted(skill_dirs, key=lambda path: path.relative_to(skills_root).as_posix())


@dataclass(frozen=True)
class SkillSource:
    """Skill source metadata used by the loader and UI."""

    name: str
    root: Path
    editable: bool
    managed: bool
    trusted: bool


_MATCREATOR_HOME = Path(
    os.environ.get("MATCREATOR_HOME", str(Path.home() / ".matcreator"))
).expanduser()
MODULE_SKILLS_ROOT_ENV = "MATCREATOR_MODULE_SKILLS_ROOT"
_DEFAULT_MODULE_SKILLS_ROOT = Path(__file__).parent / "skills"
_MODULE_SKILLS_ROOT = Path(
    os.environ.get(MODULE_SKILLS_ROOT_ENV, str(_DEFAULT_MODULE_SKILLS_ROOT))
).expanduser()
_USER_SKILLS_ROOT = _MATCREATOR_HOME / "skills"
_OFFICIAL_SKILLS_ROOT = _USER_SKILLS_ROOT / "official"
_RESERVED_USER_SKILL_DIRS = frozenset({"builtin", "official"})


def user_skills_dir() -> Path:
    """Return the user-global ADK skill root."""
    return _USER_SKILLS_ROOT


def official_skills_dir() -> Path:
    """Return the corporation-maintained official skill root."""
    return _OFFICIAL_SKILLS_ROOT


def skill_sources() -> list[SkillSource]:
    """Return skill sources in precedence order."""
    return [
        SkillSource("builtin", _MODULE_SKILLS_ROOT, editable=True, managed=True, trusted=True),
        SkillSource("official", official_skills_dir(), editable=True, managed=True, trusted=True),
        SkillSource("custom", user_skills_dir(), editable=True, managed=False, trusted=False),
        SkillSource("workspace", workspace_skills_dir(), editable=True, managed=False, trusted=False),
    ]


def _discover_custom_skill_dirs(skills_root: Path) -> list[Path]:
    """Discover user custom skills, excluding managed subdirectories."""
    skill_dirs = []
    for path in _discover_skill_dirs(skills_root):
        try:
            rel_parts = path.relative_to(skills_root).parts
        except ValueError:
            rel_parts = ()
        if rel_parts and rel_parts[0] in _RESERVED_USER_SKILL_DIRS:
            continue
        skill_dirs.append(path)
    return skill_dirs


def _discover_skill_dirs_for_source(source: SkillSource) -> list[Path]:
    if source.name == "custom":
        return _discover_custom_skill_dirs(source.root)
    return _discover_skill_dirs(source.root)


def _skill_dir_map() -> dict[str, Path]:
    """Map loaded skill names to their backing directories."""
    return {name: path for name, (path, _) in _skill_dir_source_map().items()}


def _skill_dir_source_map() -> dict[str, tuple[Path, SkillSource]]:
    """Map loaded skill names to backing directories and source metadata."""
    mapping: dict[str, tuple[Path, SkillSource]] = {}
    for source in skill_sources():
        for path in _discover_skill_dirs_for_source(source):
            mapping.setdefault(path.name, (path, source))
    return mapping


def get_skill_source(skill_name: str) -> SkillSource | None:
    """Return source metadata for a loaded skill name."""
    item = _skill_dir_source_map().get(skill_name)
    return item[1] if item else None


def _language_for_path(path: str) -> str | None:
    suffix = Path(path).suffix.lower()
    return {
        ".md": "markdown",
        ".py": "python",
        ".sh": "bash",
        ".yaml": "yaml",
        ".yml": "yaml",
        ".json": "json",
        ".toml": "toml",
        ".txt": "text",
        ".csv": "csv",
    }.get(suffix)


def get_default_skill_names() -> set[str]:
    """Return the set of skill names bundled with the module (not workspace overrides)."""
    return {p.name for p in _discover_skill_dirs(_MODULE_SKILLS_ROOT)}


def get_official_skill_names() -> set[str]:
    """Return the set of installed official skill names."""
    return {p.name for p in _discover_skill_dirs(official_skills_dir())}


def get_managed_skill_names() -> set[str]:
    """Return skill names from managed builtin and official sources."""
    return get_default_skill_names() | get_official_skill_names()


def set_unofficial_skill_nodes_disabled(disabled: bool = True) -> dict[str, object]:
    """Enable or disable every non-official KDG node through KDG.

    This intentionally changes KDG's native ``metadata.disabled`` state rather
    than MatCreator's config-only skill filter.  Consequently the setting is
    observed by KDG search and retrieval APIs as well as MatCreator's tools.
    Maintained base skills (``skill_source=builtin`` or ``official``) are left
    intact. Custom, workspace, legacy, memory, experience, and attached
    heuristic/limitation nodes are all considered unofficial.
    """
    from .knowledge.query import _get_kg

    graph = _get_kg()
    affected: list[str] = []
    changed: list[str] = []
    restored_official: list[str] = []
    for entry in iter_entries_including_disabled(graph):
        if is_official_skill_entry(entry):
            # Correct nodes disabled by an earlier bulk run that treated
            # MatCreator's builtin source as unofficial.
            if is_entry_disabled(entry):
                set_entry_disabled(graph, entry.id, False)
                restored_official.append(entry.id)
            continue
        affected.append(entry.id)
        if is_entry_disabled(entry) != disabled:
            set_entry_disabled(graph, entry.id, disabled)
            changed.append(entry.id)

    if changed or restored_official:
        graph.refresh()
    return {
        "disabled": disabled,
        "affected": len(affected),
        "changed": len(changed),
        "node_ids": affected,
        "restored_official": len(restored_official),
    }


def get_disabled_skill_names() -> set[str]:
    """Return installed skill names disabled in the Know-Do Graph.

    The graph is the sole runtime source of truth for skill availability.  Use
    ``iter_entries_including_disabled`` because KDG's normal search APIs may
    intentionally omit disabled nodes.
    """
    from .knowledge.query import _get_kg

    installed_names = {skill.name for skill in ALL_SKILLS}
    return {
        entry.title
        for entry in iter_entries_including_disabled(_get_kg())
        if "matcreator-skill" in entry.tags
        and not entry.metadata.custom.get("virtual")
        and entry.title in installed_names
        and is_entry_disabled(entry)
    }


def is_skill_disabled(skill_name: str) -> bool:
    """Return whether the installed skill named *skill_name* is disabled."""
    return skill_name in get_disabled_skill_names()


def set_disabled_skill_names(disabled_skill_names: set[str]) -> dict[str, object]:
    """Synchronize installed skill-node disabled state with a desired name set.

    This powers the Settings UI.  It deliberately affects only installed,
    non-virtual skill nodes, leaving manually managed knowledge-only nodes and
    guides untouched.
    """
    from .knowledge.query import _get_kg

    graph = _get_kg()
    installed_names = {skill.name for skill in ALL_SKILLS}
    desired = {name for name in disabled_skill_names if name in installed_names}
    affected: list[str] = []
    changed: list[str] = []
    for entry in iter_entries_including_disabled(graph):
        if (
            "matcreator-skill" not in entry.tags
            or entry.metadata.custom.get("virtual")
            or entry.title not in installed_names
        ):
            continue
        affected.append(entry.id)
        disabled = entry.title in desired
        if is_entry_disabled(entry) != disabled:
            set_entry_disabled(graph, entry.id, disabled)
            changed.append(entry.id)
    if changed:
        graph.refresh()
    return {
        "disabled": sorted(desired),
        "affected": len(affected),
        "changed": len(changed),
        "node_ids": affected,
    }


def migrate_legacy_disabled_skill_config() -> dict[str, object]:
    """Move legacy ``skills.disabled`` config state into graph nodes once.

    Older releases stored availability in config.yaml.  Keep that state when
    upgrading, then remove the retired key so later graph toggles cannot drift
    from a second source of truth.
    """
    from .config import load_config, save_config

    config = load_config()
    skill_config = config.get("skills")
    if not isinstance(skill_config, dict) or "disabled" not in skill_config:
        return {"migrated": False, "disabled": []}
    disabled = {
        str(name)
        for name in skill_config.pop("disabled") or []
        if str(name).strip()
    }
    if not skill_config:
        config.pop("skills", None)
    # An empty legacy list conveys no disabled skill to migrate.  In
    # particular, do not use it to re-enable graph nodes that were disabled
    # directly through the graph UI in a previous release.
    result = (
        set_disabled_skill_names(disabled)
        if disabled
        else {"disabled": [], "affected": 0, "changed": 0, "node_ids": []}
    )
    save_config(config)
    return {"migrated": True, **result}


def load_skills() -> list:
    """Load builtin, official, user-global custom, then workspace custom skills.

    Skills from later sources whose name collides with an earlier source are rejected
    with a warning.
    """
    seen: dict[str, str] = {}
    skills = []
    for source in skill_sources():
        for path in _discover_skill_dirs_for_source(source):
            if path.name in seen:
                logger.warning(
                    "Skill '%s' in %s conflicts with %s and will be ignored.",
                    path.name,
                    source.name,
                    seen[path.name],
                )
                continue
            seen[path.name] = source.name
            try:
                skills.append(load_skill_from_dir(path))
            except Exception as exc:
                logger.error("Failed to load %s skill '%s', skipping: %s", source.name, path.name, exc)
    return skills


ALL_SKILLS = load_skills()

_PLANNING_CATEGORIES = frozenset({"concepts", "guides"})
_DEFAULT_PLANNING_SKILLS = frozenset({"dpa4"})


def _build_planning_skill_names() -> frozenset[str]:
    names: set[str] = set()
    for source in skill_sources():
        for path in _discover_skill_dirs_for_source(source):
            if path.parent.name in _PLANNING_CATEGORIES:
                names.add(path.name)
    for name in _DEFAULT_PLANNING_SKILLS:
        names.add(name)
    for name in get_planning_skills():
        names.add(name)
    return frozenset(names)


PLANNING_SKILL_NAMES: set[str] = set(_build_planning_skill_names())


def skill_bundle_info(skill_name: str) -> dict[str, object] | None:
    """Return a skill's on-disk folder and bundled sidecar file paths.

    Agents receive this metadata whenever they load a skill's full content so
    they know which ``references/``, ``assets/``, and ``scripts/`` files exist
    and where the skill bundle lives, instead of having to guess or enumerate
    directories themselves. Returns ``None`` for unknown or registry-fetched
    skills.
    """
    loaded = next((s for s in ALL_SKILLS if s.name == skill_name), None)
    if loaded is None:
        return None
    bundle: dict[str, object] = {
        "references": [f"references/{p}" for p in sorted(loaded.resources.list_references())],
        "assets": [f"assets/{p}" for p in sorted(loaded.resources.list_assets())],
        "scripts": [f"scripts/{p}" for p in sorted(loaded.resources.list_scripts())],
    }
    skill_dir = _skill_dir_map().get(skill_name)
    if skill_dir is not None:
        bundle["skill_dir"] = str(skill_dir)
    return bundle


def format_skill_bundle_hint(skill_name: str, bundle: dict[str, object] | None) -> str | None:
    """Describe a skill's bundled files and how the agent can access them."""
    if not bundle:
        return None
    files = [
        *(bundle.get("references") or []),
        *(bundle.get("assets") or []),
        *(bundle.get("scripts") or []),
    ]
    if not files:
        return None
    skill_dir = bundle.get("skill_dir")
    location = f" in {skill_dir}" if skill_dir else ""
    lines = [f"This skill bundles {len(files)} sidecar file(s){location}:"]
    lines.extend(f"- {path}" for path in files)
    lines.append(
        f"Read one with load_skill_resource(skill_name='{skill_name}', file_path='<a path above>'); "
        "run scripts/ files with run_skill_script."
    )
    return "\n".join(lines)


class MatCreatorLoadSkillTool(skill_toolset.LoadSkillTool):
    """Augment ADK skill loads with bundle-file and L3/L4 attachment metadata."""

    async def run_async(self, *, args, tool_context):
        result = await super().run_async(args=args, tool_context=tool_context)
        if not isinstance(result, dict) or result.get("error"):
            return result

        skill_name = result.get("skill_name")
        if not isinstance(skill_name, str):
            return result

        bundle = skill_bundle_info(skill_name)
        if bundle is not None:
            result["bundled_files"] = bundle
            bundle_hint = format_skill_bundle_hint(skill_name, bundle)
            if bundle_hint:
                result["bundled_files_hint"] = bundle_hint

        from .knowledge.query import format_node_context_hint, get_node_context_summary

        context = get_node_context_summary(skill_name)
        if context is None:
            return result
        result["attached_context"] = context
        hint = format_node_context_hint(context)
        if hint:
            result["attached_context_hint"] = hint
        return result


class MatCreatorSkillToolset(skill_toolset.SkillToolset):
    """SkillToolset with workspace-aware list and run tools."""

    def __init__(self, skills: list):
        super().__init__(skills=skills)
        kept = [
            MatCreatorLoadSkillTool(self)
            if isinstance(t, skill_toolset.LoadSkillTool)
            else t
            for t in self._tools
            if isinstance(t, (skill_toolset.LoadSkillTool, skill_toolset.LoadSkillResourceTool))
        ]
        self._tools = [
            #FunctionTool(list_workspace_skills),
            *kept,
            FunctionTool(run_skill_script),
        ]

    def _get_skill(self, skill_name: str):
        skill = super()._get_skill(skill_name)
        if skill is not None and is_skill_disabled(skill.name):
            return None
        return skill

    def _list_skills(self) -> list:
        disabled = get_disabled_skill_names()
        return [skill for skill in super()._list_skills() if skill.name not in disabled]

    async def process_llm_request(self, *, tool_context, llm_request) -> None:
        # Suppress the default XML skill-list injection; agents use graph discovery instead.
        pass


ALL_SKILLS_TOOLSET = MatCreatorSkillToolset(ALL_SKILLS)


def seed_skills_to_graph() -> dict:
    """Upsert all workspace skills and guides into Know-Do Graph.

    The primary skill node stores the full SKILL.md instruction body so graph
    search can retrieve the same text the agent actually reads. Sidecar files
    such as ``references/*``, ``assets/*``, ``scripts/*``, and ``README.md``
    are attached directly to that node using the Know-Do Graph's native
    attachment fields. Skill and guide nodes are marked immutable — they are
    dev-maintained and will not be silently updated by the extractor or
    synthesizer.

    After all nodes are seeded, ``depends_on`` edges are created between skill
    nodes based on the ``dependent_skills`` field in each SKILL.md's metadata.
    """
    from know_do_graph import (
        EdgeRelation,
        EntryMetadata,
        EntryType,
        NodeAsset,
        RefinementStatus,
        ScriptAttachment,
        SkillLevel,
        VerificationStatus,
    )
    from .knowledge.kdg_memory import connect_once, iter_entries, upsert_entry
    from .knowledge.query import _get_kg
    from .guide import ALL_GUIDES

    kg = _get_kg()
    seeded = 0
    attachments_seeded = 0
    skill_node_ids: dict[str, str] = {}
    active_skill_names = {skill.name for skill in ALL_SKILLS}
    skill_dirs = _skill_dir_map()

    for skill in ALL_SKILLS:
        content = (skill.instructions or skill.description or "").strip()
        assets: list[NodeAsset] = []
        internal_refs: list[str] = []
        for relative_path, resource_content in skill.resources.references.items():
            assets.append(
                NodeAsset(
                    folder="references",
                    filename=relative_path,
                    kind="reference",
                    content=resource_content.strip(),
                    language=_language_for_path(relative_path),
                    mime_type=guess_type(relative_path)[0],
                    metadata={"skill_name": skill.name, "relative_path": f"references/{relative_path}"},
                )
            )
            internal_refs.append(f"references/{relative_path}")
        for relative_path, resource_content in skill.resources.assets.items():
            assets.append(
                NodeAsset(
                    folder="assets",
                    filename=relative_path,
                    kind="asset",
                    content=resource_content.strip(),
                    language=_language_for_path(relative_path),
                    mime_type=guess_type(relative_path)[0],
                    metadata={"skill_name": skill.name, "relative_path": f"assets/{relative_path}"},
                )
            )
        scripts = [
            ScriptAttachment(
                filename=relative_path,
                language=_language_for_path(relative_path) or "text",
                content=resource_content.src.strip(),
                description=f"Bundled script for skill '{skill.name}'.",
            )
            for relative_path, resource_content in skill.resources.scripts.items()
            if resource_content.src.strip()
        ]
        # Mirror scripts into assets because the current Know-Do Graph build
        # persists assets/internal_refs but drops scripts on write.
        for relative_path, resource_content in skill.resources.scripts.items():
            script_content = resource_content.src.strip()
            if not script_content:
                continue
            assets.append(
                NodeAsset(
                    folder="scripts",
                    filename=relative_path,
                    kind="script",
                    content=script_content,
                    language=_language_for_path(relative_path),
                    mime_type=guess_type(relative_path)[0],
                    metadata={"skill_name": skill.name, "relative_path": f"scripts/{relative_path}"},
                )
            )
        skill_dir = skill_dirs.get(skill.name)
        if skill_dir is not None:
            readme_path = skill_dir / "README.md"
            if readme_path.exists():
                try:
                    readme_content = readme_path.read_text(encoding="utf-8").strip()
                    if readme_content:
                        assets.append(
                            NodeAsset(
                                folder="docs",
                                filename="README.md",
                                kind="readme",
                                content=readme_content,
                                language="markdown",
                                mime_type="text/markdown",
                                metadata={"skill_name": skill.name, "relative_path": "README.md"},
                            )
                        )
                        internal_refs.append("README.md")
                except OSError as exc:
                    logger.warning("Failed to read %s: %s", readme_path, exc)
        frontmatter_metadata = skill.frontmatter.metadata or {}
        entry_type_value = frontmatter_metadata.get("entry_type") or frontmatter_metadata.get("type")
        entry_type = EntryType.capability
        if entry_type_value:
            try:
                entry_type = EntryType(str(entry_type_value))
            except ValueError:
                logger.warning("Ignoring invalid entry_type for skill '%s': %s", skill.name, entry_type_value)
        skill_level_value = frontmatter_metadata.get("skill_level")
        skill_level = SkillLevel.L1
        if skill_level_value:
            try:
                skill_level = SkillLevel(str(skill_level_value))
            except ValueError:
                logger.warning("Ignoring invalid skill_level for skill '%s': %s", skill.name, skill_level_value)
        extra_tags = [
            str(tag).strip()
            for tag in frontmatter_metadata.get("tags", [])
            if str(tag).strip()
        ]
        source = get_skill_source(skill.name)
        source_name = source.name if source else "unknown"
        tags = list(dict.fromkeys([
            "matcreator-skill",
            "managed",
            f"skill-source:{source_name}",
            *[tag for tag in extra_tags if tag != "virtual"],
        ]))
        node, created = upsert_entry(
            kg,
            title=skill.name,
            content=content,
            entry_type=entry_type,
            tags=tags,
            internal_refs=internal_refs,
            scripts=scripts,
            assets=assets,
            metadata=EntryMetadata(
                source_provenance="SKILL.md",
                refinement_status=RefinementStatus.validated,
                verification_status=VerificationStatus.peer_reviewed,
                skill_level=skill_level,
                custom={
                    "managed_by": "matcreator",
                    "kind": "skill",
                    "description": (skill.description or "").strip(),
                    "skill_source": source_name,
                    "virtual": False,
                    "virtual_reason": None,
                },
            ),
        )
        normalized_tags = [
            tag
            for tag in node.tags
            if tag != "virtual" and not tag.startswith("skill-source:")
        ]
        normalized_tags.append(f"skill-source:{source_name}")
        if normalized_tags != node.tags:
            node = kg.update(
                node.id,
                tags=normalized_tags,
            )
        skill_node_ids[skill.name] = node.id
        seeded += int(created)
        attachments_seeded += len(internal_refs) + len(assets)

    # Older releases could create a second managed node when the original was
    # disabled, because their upsert lookup only saw enabled nodes.  Collapse
    # those duplicates before rebuilding dependency edges below.
    duplicate_groups: dict[str, list] = {}
    for entry in iter_entries_including_disabled(kg):
        if (
            "matcreator-skill" in entry.tags
            and "managed" in entry.tags
            and not entry.metadata.custom.get("virtual")
            and entry.title in active_skill_names
        ):
            duplicate_groups.setdefault(entry.title, []).append(entry)

    deduplicated = 0
    for skill_name, entries in duplicate_groups.items():
        if len(entries) < 2:
            continue
        canonical = min(
            entries,
            key=lambda entry: str(
                getattr(entry.metadata, "timestamp", None)
                or getattr(entry, "created_at", None)
                or entry.id
            ),
        )
        duplicates = [entry for entry in entries if entry.id != canonical.id]
        try:
            with sqlite3.connect(kg.path) as conn:
                for duplicate in duplicates:
                    conn.execute(
                        "UPDATE edges SET source_id = ? WHERE source_id = ?",
                        (canonical.id, duplicate.id),
                    )
                    conn.execute(
                        "UPDATE edges SET target_id = ? WHERE target_id = ?",
                        (canonical.id, duplicate.id),
                    )
                conn.commit()
        except sqlite3.Error as exc:
            logger.warning("Failed to merge duplicate skill '%s': %s", skill_name, exc)
            continue

        # A disabled duplicate records an explicit user choice; preserve it on
        # the canonical node rather than silently re-enabling the skill.
        if any(is_entry_disabled(entry) for entry in entries) and not is_entry_disabled(canonical):
            set_entry_disabled(kg, canonical.id, True)
        for duplicate in duplicates:
            kg.delete(duplicate.id)
        skill_node_ids[skill_name] = canonical.id
        deduplicated += len(duplicates)
    if deduplicated:
        kg.refresh()

    for guide in ALL_GUIDES:
        _, created = upsert_entry(
            kg,
            title=guide.name,
            content=guide.instructions or guide.description or "",
            entry_type=EntryType.procedure,
            tags=["matcreator-skill", "matcreator-guide", "managed"],
            metadata=EntryMetadata(
                source_provenance="guide",
                refinement_status=RefinementStatus.validated,
                verification_status=VerificationStatus.peer_reviewed,
                skill_level=SkillLevel.L2,
                custom={"managed_by": "matcreator", "kind": "guide"},
            ),
        )
        seeded += int(created)

    # The dependency declarations in SKILL.md are authoritative.  Remove the
    # relations previously seeded from those declarations before rebuilding
    # them below, so deselecting a dependency in the UI actually removes the
    # corresponding graph edge instead of leaving a stale connection behind.
    if skill_node_ids:
        placeholders = ",".join("?" for _ in skill_node_ids)
        try:
            with sqlite3.connect(kg.path) as conn:
                conn.execute(
                    f"""
                    DELETE FROM edges
                    WHERE source_id IN ({placeholders})
                      AND relation IN ('dependency', 'heuristic_for', 'constraint_on')
                    """,
                    list(skill_node_ids.values()),
                )
                conn.commit()
        except sqlite3.Error as exc:
            logger.warning("Failed to refresh seeded skill dependencies: %s", exc)
        else:
            # ``connect_once`` consults the in-memory traversal graph, so it
            # must not retain relations that were just removed from SQLite.
            kg.refresh()

    def normalize_dependency_name(value: object) -> str:
        """Match the name resolution used when dependency edges are seeded."""

        dep_name = str(value).strip().rstrip("/")
        if dep_name not in active_skill_names and "/" in dep_name:
            basename = dep_name.rsplit("/", 1)[-1]
            if basename in active_skill_names:
                return basename
        return dep_name

    declared_dependency_names = {
        normalize_dependency_name(declared_dep)
        for skill in ALL_SKILLS
        for declared_dep in (skill.frontmatter.metadata or {}).get("dependent_skills", [])
        if normalize_dependency_name(declared_dep)
    }

    # A missing skill is represented by a virtual node.  Do not cascade-delete
    # it if an agent-created node still points to it: strip its backed-skill
    # content and retain the placeholder so the user can relink or remove the
    # attached node.  Truly unreferenced placeholders disappear.
    removed = 0
    virtualized = 0
    stale_entries = [
        entry
        for entry in iter_entries(kg)
        if (
            "matcreator-skill" in entry.tags
            and "matcreator-guide" not in entry.tags
            and entry.title not in active_skill_names
            and ("managed" in entry.tags or entry.metadata.custom.get("virtual"))
        )
    ]
    # Be conservative if the edge inspection fails: preserving a placeholder
    # is safe, while deleting one would lose its incident agent links.
    connected_stale_ids: set[str] = {entry.id for entry in stale_entries}
    if stale_entries:
        placeholders = ",".join("?" for _ in stale_entries)
        stale_ids = [entry.id for entry in stale_entries]
        try:
            with sqlite3.connect(kg.path) as conn:
                rows = conn.execute(
                    f"""
                    SELECT source_id, target_id
                    FROM edges
                    WHERE (source_id IN ({placeholders}) OR target_id IN ({placeholders}))
                      AND NOT (
                        source_id IN ({placeholders})
                        AND relation IN ('dependency', 'heuristic_for', 'constraint_on')
                      )
                    """,
                    [*stale_ids, *stale_ids, *stale_ids],
                ).fetchall()
                conn.execute(
                    f"""
                    DELETE FROM edges
                    WHERE source_id IN ({placeholders})
                      AND relation IN ('dependency', 'heuristic_for', 'constraint_on')
                    """,
                    stale_ids,
                )
                conn.commit()
            connected_stale_ids = {
                node_id
                for row in rows
                for node_id in row
                if node_id in stale_ids
            }
        except sqlite3.Error as exc:
            logger.warning("Failed to inspect stale skill graph nodes: %s", exc)

    for entry in stale_entries:
        if entry.id not in connected_stale_ids and entry.title not in declared_dependency_names:
            removed += int(kg.delete(entry.id))
            continue
        metadata = entry.metadata.model_copy(deep=True)
        metadata.source_provenance = "missing skill backing"
        metadata.custom = {
            **metadata.custom,
            "managed_by": "matcreator",
            "kind": "virtual_dependency",
            "virtual": True,
            "virtual_reason": "backing skill is no longer installed",
        }
        virtual = kg.update(
            entry.id,
            content="",
            entry_type=EntryType.capability,
            tags=["matcreator-skill", "virtual"],
            aliases=[],
            internal_refs=[],
            scripts=[],
            assets=[],
            metadata=metadata,
        )
        skill_node_ids[virtual.title] = virtual.id
        virtualized += 1
    kg.refresh()

    # Create edges from dependent_skills metadata. For L3/L4 nodes this field
    # means "attached parent skills" so progressive retrieval can scope them.
    edges_created = 0
    for skill in ALL_SKILLS:
        metadata = skill.frontmatter.metadata or {}
        deps = metadata.get("dependent_skills", [])
        entry_type_value = metadata.get("entry_type") or metadata.get("type")
        skill_level_value = metadata.get("skill_level")
        relation = EdgeRelation.dependency
        if entry_type_value == "heuristic" or skill_level_value == "L3":
            relation = EdgeRelation.heuristic_for
        elif entry_type_value == "constraint" or skill_level_value == "L4":
            relation = EdgeRelation.constraint_on
        src_id = skill_node_ids.get(skill.name)
        for declared_dep in deps:
            dep_name = normalize_dependency_name(declared_dep)
            tgt_id = skill_node_ids.get(dep_name)
            if src_id and not tgt_id:
                virtual = kg.add(
                    dep_name,
                    content="",
                    entry_type=EntryType.capability,
                    tags=["matcreator-skill", "virtual"],
                    metadata=EntryMetadata(
                        source_provenance="dependency declaration",
                        refinement_status=RefinementStatus.raw,
                        verification_status=VerificationStatus.unverified,
                        skill_level=SkillLevel.L1,
                        custom={
                            "managed_by": "matcreator",
                            "kind": "virtual_dependency",
                            "virtual": True,
                            "virtual_reason": "referenced skill is not installed",
                        },
                    ),
                )
                tgt_id = virtual.id
                skill_node_ids[dep_name] = tgt_id
                virtualized += 1
            if src_id and tgt_id:
                edges_created += int(
                    connect_once(
                        kg,
                        src_id,
                        tgt_id,
                        relation=relation,
                    )
                )
            else:
                logger.warning(
                    "dependent_skills: '%s' references unknown skill '%s'",
                    skill.name, dep_name,
                )

    kg.refresh()
    migrate_legacy_disabled_skill_config()
    return {
        "status": "ok",
        "seeded": seeded,
        "attachments_seeded": attachments_seeded,
        "edges_created": edges_created,
        "removed": removed,
        "virtualized": virtualized,
        "deduplicated": deduplicated,
    }


def refresh_skills() -> dict:
    """Reload all skills from the workspace and re-seed the knowledge graph.

    Call this after creating or modifying a skill to make it available
    in the current session without restarting.
    """
    new_skills = load_skills()
    ALL_SKILLS.clear()
    ALL_SKILLS.extend(new_skills)
    PLANNING_SKILL_NAMES.clear()
    PLANNING_SKILL_NAMES.update(_build_planning_skill_names())
    seed_result = seed_skills_to_graph()
    return {
        "status": "ok",
        "skills": [s.name for s in new_skills],
        "count": len(new_skills),
        "message": f"Refreshed {len(new_skills)} skills; seeded {seed_result['seeded']} nodes into knowledge graph.",
    }


def _backup_skill_graph(graph) -> Path:
    """Create and return a transactionally consistent SQLite graph backup."""
    source_path = Path(graph.path)
    if not source_path.exists():
        raise RuntimeError(f"Cannot back up missing skill graph database: {source_path}")
    backup_dir = source_path.parent / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    backup_path = backup_dir / f"{source_path.stem}-{timestamp}{source_path.suffix or '.db'}"
    try:
        with sqlite3.connect(source_path) as source, sqlite3.connect(backup_path) as target:
            source.backup(target)
    except (OSError, sqlite3.Error) as exc:
        backup_path.unlink(missing_ok=True)
        raise RuntimeError(f"Failed to back up skill graph: {exc}") from exc
    return backup_path


def clear_skill_graph_memory(*, create_backup: bool = True) -> dict:
    """Delete every memory node while leaving durable skill graph nodes intact."""
    from know_do_graph import EntryType
    from .knowledge.kdg_memory import iter_entries
    from .knowledge.query import _get_kg

    graph = _get_kg()
    backup_path = _backup_skill_graph(graph) if create_backup else None
    memory_ids = [
        entry.id
        for entry in iter_entries(graph)
        if entry.entry_type == EntryType.memory
    ]
    deleted = sum(int(bool(graph.delete(entry_id))) for entry_id in memory_ids)
    graph.refresh()
    if deleted != len(memory_ids):
        raise RuntimeError(
            f"Memory clear stopped after deleting {deleted}/{len(memory_ids)} nodes; "
            "one or more memory nodes could not be removed."
        )
    return {
        "status": "ok",
        "deleted": deleted,
        "failed": 0,
        "backup_path": str(backup_path) if backup_path else None,
        "message": f"Cleared {deleted} memory node(s).",
    }


def reset_skill_graph(*, create_backup: bool = True) -> dict:
    """Rebuild the graph from currently installed built-in and custom skills.

    Skill files are the source of truth. All graph nodes are removed first,
    then active built-in, official, user-global, and workspace skills (plus
    bundled guides and declared dependency topology) are freshly seeded.
    """
    from .knowledge.kdg_memory import iter_entries
    from .knowledge.query import _get_kg

    graph = _get_kg()
    backup_path = _backup_skill_graph(graph) if create_backup else None
    entry_ids = [entry.id for entry in iter_entries(graph)]
    deleted = sum(int(bool(graph.delete(entry_id))) for entry_id in entry_ids)
    if deleted != len(entry_ids):
        graph.refresh()
        raise RuntimeError(
            f"Graph reset stopped after deleting {deleted}/{len(entry_ids)} nodes; "
            "one or more nodes could not be removed."
        )

    graph.refresh()
    refresh_result = refresh_skills()
    return {
        "status": "ok",
        "deleted": deleted,
        "skills": refresh_result["count"],
        "backup_path": str(backup_path) if backup_path else None,
        "message": (
            f"Reset the skill graph: removed {deleted} node(s) and restored "
            f"{refresh_result['count']} installed skill(s)."
        ),
    }
