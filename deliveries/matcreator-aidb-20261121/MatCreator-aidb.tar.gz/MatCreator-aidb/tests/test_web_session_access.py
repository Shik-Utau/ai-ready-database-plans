from __future__ import annotations

import asyncio
import ast
import importlib.util
import json
import sqlite3
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi import HTTPException


class _FakeImage:
    def __init__(self, image_id: str):
        self.id = image_id


class _FakeContainer:
    def __init__(self, image_id: str):
        self.image = _FakeImage(image_id)


class _FakeImages:
    def __init__(self, image_id: str):
        self._image = _FakeImage(image_id)

    def get(self, _name: str):
        return self._image


class _FakeDockerClient:
    def __init__(self, image_id: str):
        self.images = _FakeImages(image_id)


def _load_web_main(monkeypatch, matcreator_home: Path | None = None):
    root = Path(__file__).resolve().parents[1]
    monkeypatch.setenv("MATCREATOR_MODE", "local")
    if matcreator_home is not None:
        monkeypatch.setenv("MATCREATOR_HOME", str(matcreator_home))
    else:
        monkeypatch.delenv("MATCREATOR_HOME", raising=False)
    for path in (root / "web", root / "src"):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))
    for module_name in ("matcreator.config", "matcreator.constants", "matcreator.ports", "matcreator.workspace"):
        sys.modules.pop(module_name, None)

    spec = importlib.util.spec_from_file_location(
        "web_main_session_access_test",
        root / "web" / "main.py",
    )
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def _load_web_main_server(monkeypatch, control_home: Path, data_root: Path, host_data_root: Path | None = None):
    root = Path(__file__).resolve().parents[1]
    monkeypatch.setenv("MATCREATOR_MODE", "server")
    monkeypatch.setenv("MATCREATOR_CONTROL_PLANE_HOME", str(control_home))
    monkeypatch.setenv("MATCREATOR_DATA_ROOT", str(data_root))
    if host_data_root is not None:
        monkeypatch.setenv("MATCREATOR_HOST_DATA_ROOT", str(host_data_root))
    else:
        monkeypatch.delenv("MATCREATOR_HOST_DATA_ROOT", raising=False)
    monkeypatch.delenv("MATCREATOR_HOME", raising=False)
    for env_key in (
        "LLM_MODEL",
        "LLM_API_KEY",
        "LLM_BASE_URL",
        "MP_API_KEY",
        "SERVER_ONLY_FLAG",
        "MATCREATOR_MODULE_SKILLS_ROOT",
    ):
        monkeypatch.delenv(env_key, raising=False)
    for path in (root / "web", root / "src"):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))
    for module_name in ("matcreator.config", "matcreator.constants", "matcreator.ports", "matcreator.workspace"):
        sys.modules.pop(module_name, None)

    spec = importlib.util.spec_from_file_location(
        "web_main_server_env_test",
        root / "web" / "main.py",
    )
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def test_graph_filter_uses_durable_launcher_ids_not_child_step_numbers(monkeypatch, tmp_path):
    del monkeypatch, tmp_path
    source_path = Path(__file__).resolve().parents[1] / "web" / "main.py"
    module = ast.parse(source_path.read_text(encoding="utf-8"))
    filter_node = next(
        node for node in module.body
        if isinstance(node, ast.FunctionDef) and node.name == "_filter_agent_graph_nodes"
    )
    namespace: dict[str, object] = {}
    exec(compile(ast.Module(body=[filter_node], type_ignores=[]), str(source_path), "exec"), namespace)
    filter_graph_nodes = namespace["_filter_agent_graph_nodes"]
    graph = {
        "nodes": {
            "execution__node_relax": {
                "id": "execution__node_relax", "type": "step", "parent_id": "execution",
                "input": {"node_id": "relax"},
            },
            "execution__node_relax__node_1": {
                "id": "execution__node_relax__node_1", "type": "step", "parent_id": "execution__node_relax",
                "input": {"node_id": "1", "step_number": 1},
            },
            "execution__node_static": {
                "id": "execution__node_static", "type": "step", "parent_id": "execution",
                "input": {"node_id": "static"},
            },
            "execution__node_static__node_1": {
                "id": "execution__node_static__node_1", "type": "step", "parent_id": "execution__node_static",
                "input": {"node_id": "1", "step_number": 1},
            },
        },
        "edges": [],
    }

    filtered = filter_graph_nodes(graph, ["relax"])
    assert set(filtered["nodes"]) == {"execution__node_relax", "execution__node_relax__node_1"}
    assert filter_graph_nodes(graph, ["1"])["nodes"] == {}


def test_graph_filter_matches_direct_flash_launch_by_action(monkeypatch, tmp_path):
    del monkeypatch, tmp_path
    source_path = Path(__file__).resolve().parents[1] / "web" / "main.py"
    module = ast.parse(source_path.read_text(encoding="utf-8"))
    filter_nodes = [
        node for node in module.body
        if isinstance(node, ast.FunctionDef) and node.name in {
            "_filter_agent_graph_nodes", "_filter_agent_graph_nodes_by_actions",
        }
    ]
    namespace: dict[str, object] = {}
    exec(compile(ast.Module(body=filter_nodes, type_ignores=[]), str(source_path), "exec"), namespace)
    filter_graph_nodes = namespace["_filter_agent_graph_nodes_by_actions"]
    graph = {
        "nodes": {
            "orchestrator__node_flash": {
                "id": "orchestrator__node_flash", "type": "step", "parent_id": "orchestrator",
                "input": {"node_id": "flash_abc", "action": "Relax the candidate"},
            },
            "orchestrator__node_flash__node_1": {
                "id": "orchestrator__node_flash__node_1", "type": "step",
                "parent_id": "orchestrator__node_flash",
                "input": {"node_id": "1", "action": "Inspect the result"},
            },
        },
        "edges": [],
    }

    filtered = filter_graph_nodes(graph, [], ["Relax the candidate"])
    assert set(filtered["nodes"]) == {
        "orchestrator__node_flash",
        "orchestrator__node_flash__node_1",
    }


def _create_session_db(path: Path, app_name: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path) as conn:
        conn.execute(
            """
            CREATE TABLE sessions (
                app_name TEXT,
                user_id TEXT,
                id TEXT,
                state TEXT,
                create_time TEXT,
                update_time TEXT
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE events (
                app_name TEXT,
                user_id TEXT,
                session_id TEXT,
                event_data TEXT,
                timestamp REAL
            )
            """
        )
        conn.execute(
            "INSERT INTO sessions VALUES (?, ?, ?, ?, ?, ?)",
            (app_name, "legacy-display-name", "session-1", '{"answer": 42}', "1", "2"),
        )
        conn.execute(
            "INSERT INTO events VALUES (?, ?, ?, ?, ?)",
            (app_name, "another-legacy-name", "session-1", '{"event": "persisted"}', 1.0),
        )
        conn.commit()


def test_server_worker_env_uses_persistent_control_plane_config(monkeypatch, tmp_path):
    control_home = tmp_path / "control-plane" / ".matcreator"
    control_home.mkdir(parents=True)
    selected_skills = tmp_path / "selected-skills"
    selected_skills.mkdir()
    (control_home / "config.yaml").write_text(
        "llm:\n"
        "  model: openai/server-default\n"
        "  api_key: server-secret\n"
        "  base_url: https://server.example/v1\n"
        "benchmark:\n"
        "  server_url: https://bench.example\n"
        "  token: control-plane-token\n"
        "skills:\n"
        f"  module_root: {selected_skills}\n"
        "env:\n"
        "  MP_API_KEY: default-mp-key\n"
        "  SERVER_ONLY_FLAG: enabled\n",
        encoding="utf-8",
    )
    web_main = _load_web_main_server(monkeypatch, control_home, tmp_path / "server-data")

    env_vars = web_main._worker_env_vars()

    assert env_vars["LLM_MODEL"] == "openai/server-default"
    assert env_vars["LLM_API_KEY"] == "server-secret"
    assert env_vars["LLM_BASE_URL"] == "https://server.example/v1"
    assert env_vars["MAT_BENCH_SERVER_URL"] == "https://bench.example"
    assert "MAT_BENCH_TOKEN" not in env_vars
    assert env_vars["MP_API_KEY"] == "default-mp-key"
    assert env_vars["SERVER_ONLY_FLAG"] == "enabled"
    assert env_vars["MATCREATOR_MODULE_SKILLS_ROOT"] == str(selected_skills)


def test_worker_image_check_detects_stale_container(monkeypatch, tmp_path):
    control_home = tmp_path / "control-plane" / ".matcreator"
    control_home.mkdir(parents=True)
    web_main = _load_web_main_server(monkeypatch, control_home, tmp_path / "server-data")

    assert web_main._worker_container_uses_current_image(
        _FakeDockerClient("sha256:new-image"),
        _FakeContainer("sha256:old-image"),
    ) is False
    assert web_main._worker_container_uses_current_image(
        _FakeDockerClient("sha256:new-image"),
        _FakeContainer("sha256:new-image"),
    ) is True


def test_server_worker_image_uses_deployment_override(monkeypatch, tmp_path):
    control_home = tmp_path / "control-plane" / ".matcreator"
    control_home.mkdir(parents=True)
    monkeypatch.setenv("MATCREATOR_WORKER_IMAGE", "registry.example/matcreator-worker:v2")

    web_main = _load_web_main_server(monkeypatch, control_home, tmp_path / "server-data")

    assert web_main._WORKER_IMAGE == "registry.example/matcreator-worker:v2"
    assert web_main._worker_supervisor.image == "registry.example/matcreator-worker:v2"


def test_session_event_meta_keeps_delegated_events_in_their_user_turn(monkeypatch):
    web_main = _load_web_main(monkeypatch)
    events = [
        {"author": "user", "invocationId": "user-turn"},
        {"author": "agent", "invocationId": "planner-invocation"},
        {"author": "agent", "invocationId": "sub-agent-invocation"},
        {"author": "agent", "invocationId": "tool-invocation"},
    ]
    rows = [
        {"event_timestamp": 10 + index, "event_row_id": 100 + index}
        for index in range(len(events))
    ]

    meta = web_main._session_event_meta(events, rows, 0)

    assert [item["turn_id"] for item in meta] == ["10,100"] * len(events)


def test_server_worker_shared_mounts_parse_extra_binds(monkeypatch, tmp_path):
    control_home = tmp_path / "control-plane" / ".matcreator"
    control_home.mkdir(parents=True)
    shared_dir = tmp_path / "share"
    writable_dir = tmp_path / "scratch"
    monkeypatch.setenv(
        "MATCREATOR_WORKER_SHARED_MOUNTS",
        f"{shared_dir}:/share,{writable_dir}:/scratch:rw",
    )
    web_main = _load_web_main_server(monkeypatch, control_home, tmp_path / "server-data")

    mounts = web_main._worker_shared_mounts()

    assert mounts[str(shared_dir)] == {"bind": "/share", "mode": "ro"}
    assert mounts[str(writable_dir)] == {"bind": "/scratch", "mode": "rw"}


def test_server_env_config_writes_worker_mounted_user_config(monkeypatch, tmp_path):
    control_home = tmp_path / "control-plane" / ".matcreator"
    control_home.mkdir(parents=True)
    data_root = tmp_path / "container-data"
    host_data_root = tmp_path / "host-data"
    web_main = _load_web_main_server(monkeypatch, control_home, data_root, host_data_root)

    body = SimpleNamespace(values={
        web_main._CUSTOM_ENV_CONFIG_KEY: {"FRONTEND_SET_FLAG": "visible-to-worker"},
    })
    asyncio.run(web_main.update_env_config(body, user_id="alice"))

    host_config = host_data_root / "users" / "alice" / ".matcreator" / "config.yaml"
    container_config = data_root / "users" / "alice" / ".matcreator" / "config.yaml"
    assert "FRONTEND_SET_FLAG: visible-to-worker" in host_config.read_text(encoding="utf-8")
    assert "FRONTEND_SET_FLAG: visible-to-worker" in container_config.read_text(encoding="utf-8")


def test_server_session_summaries_are_scoped_to_user_home(monkeypatch, tmp_path):
    control_home = tmp_path / "control-plane" / ".matcreator"
    control_home.mkdir(parents=True)
    data_root = tmp_path / "server-data"
    web_main = _load_web_main_server(monkeypatch, control_home, data_root)
    db_path = data_root / "users" / "alice" / ".matcreator" / ".adk" / "session.db"
    _create_session_db(db_path, web_main.APP_NAME)

    body = SimpleNamespace(summary="Manual summary")
    asyncio.run(web_main.update_session_summary("session-1", body, user_id="alice"))

    summary_path = data_root / "users" / "alice" / ".matcreator" / ".adk" / "session_summaries.json"
    assert summary_path.exists()
    assert web_main._get_session_summary("session-1", "alice") == "Manual summary"
    sessions = web_main._query_session_summaries("alice")
    assert sessions[0]["summary"] == "Manual summary"


def test_local_adk_restart_env_uses_frontend_config(monkeypatch, tmp_path):
    matcreator_home = tmp_path / ".matcreator"
    matcreator_home.mkdir()
    monkeypatch.setenv("FRONTEND_SET_FLAG", "stale-inherited-value")
    web_main = _load_web_main(monkeypatch, matcreator_home)

    body = SimpleNamespace(values={
        "LLM_MODEL": "openai/local-config-model",
        "GRAPH_AGENT_MODEL": "openai/local-graph-model",
        "REVIEW_AGENT_MODEL": "openai/local-review-model",
        web_main._CUSTOM_ENV_CONFIG_KEY: {"FRONTEND_SET_FLAG": "visible-locally"},
    })
    asyncio.run(web_main.update_env_config(body))
    settings_body = SimpleNamespace(
        planning=None,
        user=None,
        skills=None,
        workspace=None,
        llm={
            "executor_cards": {
                "default": "balanced",
                "cards": {
                    "balanced": {
                        "model": "openai/local-executor-model",
                        "description": "Local executor model",
                    },
                },
            },
        },
    )
    asyncio.run(web_main.update_settings(settings_body))

    env = web_main._local_adk_env()

    assert env["LLM_MODEL"] == "openai/local-config-model"
    assert env["GRAPH_AGENT_MODEL"] == "openai/local-graph-model"
    assert env["REVIEW_AGENT_MODEL"] == "openai/local-review-model"
    assert env["FRONTEND_SET_FLAG"] == "visible-locally"
    config_text = (matcreator_home / "config.yaml").read_text(encoding="utf-8")
    assert "model: openai/local-config-model" in config_text
    assert "graph_agent_model: openai/local-graph-model" in config_text
    assert "review_agent_model: openai/local-review-model" in config_text
    assert "executor_cards:" in config_text
    assert "model: openai/local-executor-model" in config_text
    assert "FRONTEND_SET_FLAG: visible-locally" in config_text


def test_server_runtime_and_benchmark_settings_are_persisted(monkeypatch, tmp_path):
    control_home = tmp_path / "control-plane" / ".matcreator"
    control_home.mkdir(parents=True)
    web_main = _load_web_main_server(monkeypatch, control_home, tmp_path / "server-data")

    body = SimpleNamespace(values={
        "MATCREATOR_EXEC_TIMEOUT_SECONDS": "7200",
        "MATCREATOR_MEMORIZATION_FREQUENCY": "0",
        "MATCREATOR_REVIEW_FREQUENCY": "25",
        "MAT_BENCH_SERVER_URL": "http://127.0.0.1:8080/bench",
        "MAT_BENCH_TOKEN": "benchmark-secret",
        "MAT_BENCH_QUESTION_BANK_ROOT": "/tmp/question-bank",
    })
    asyncio.run(web_main.update_env_config(body, user_id="alice"))

    config = web_main._load_config_for_user("alice")
    assert config["runtime"]["execution_timeout_seconds"] == "7200"
    assert config["knowledge"] == {
        "memorization_frequency": "0",
        "review_frequency": "25",
    }
    assert config["benchmark"] == {
        "server_url": "http://127.0.0.1:8080/bench",
        "token": "benchmark-secret",
        "question_bank_root": "/tmp/question-bank",
    }

    response = asyncio.run(web_main.get_env_config(user_id="alice"))
    values = json.loads(response.body)
    assert values["MAT_BENCH_TOKEN"] == "***"


def test_runtime_timeout_must_be_positive(monkeypatch, tmp_path):
    control_home = tmp_path / "control-plane" / ".matcreator"
    control_home.mkdir(parents=True)
    web_main = _load_web_main_server(monkeypatch, control_home, tmp_path / "server-data")

    body = SimpleNamespace(values={"MATCREATOR_EXEC_TIMEOUT_SECONDS": "0"})
    with pytest.raises(HTTPException, match="positive integer"):
        asyncio.run(web_main.update_env_config(body, user_id="alice"))


def test_local_mode_lists_sessions_regardless_of_requested_user(monkeypatch, tmp_path):
    web_main = _load_web_main(monkeypatch)
    db_path = tmp_path / "session.db"
    _create_session_db(db_path, web_main.APP_NAME)
    monkeypatch.setattr(web_main, "SESSION_DB_PATH", db_path)
    monkeypatch.setattr(web_main, "_MATCREATOR_MODE", "local")

    sessions = web_main._query_session_summaries("current-user")

    assert [session["id"] for session in sessions] == ["session-1"]
    assert sessions[0]["userId"] == "legacy-display-name"


def test_local_mode_reads_session_detail_regardless_of_requested_user(monkeypatch, tmp_path):
    web_main = _load_web_main(monkeypatch)
    db_path = tmp_path / "session.db"
    _create_session_db(db_path, web_main.APP_NAME)
    monkeypatch.setattr(web_main, "SESSION_DB_PATH", db_path)
    monkeypatch.setattr(web_main, "_MATCREATOR_MODE", "local")

    response = asyncio.run(web_main.get_user_session("current-user", "session-1"))
    payload = json.loads(response.body)

    assert payload["userId"] == "legacy-display-name"
    assert payload["state"] == {"answer": 42}
    assert payload["events"] == [{"event": "persisted"}]
    assert payload["pagination"]["has_more"] is False
    assert payload["pagination"]["next_before"] == ""

    compact = json.loads(asyncio.run(web_main.get_user_session(
        "current-user", "session-1", compact=True,
    )).body)
    assert compact["state"] == {}


def test_session_detail_pages_events_in_chronological_order(monkeypatch, tmp_path):
    web_main = _load_web_main(monkeypatch)
    db_path = tmp_path / "session.db"
    _create_session_db(db_path, web_main.APP_NAME)
    with sqlite3.connect(db_path) as conn:
        conn.executemany(
            "INSERT INTO events VALUES (?, ?, ?, ?, ?)",
            [
                (web_main.APP_NAME, "legacy-display-name", "session-1", json.dumps({"event": "second"}), 2.0),
                (web_main.APP_NAME, "legacy-display-name", "session-1", json.dumps({"event": "third"}), 3.0),
                (web_main.APP_NAME, "legacy-display-name", "session-1", json.dumps({"event": "fourth"}), 4.0),
            ],
        )
        conn.commit()
    monkeypatch.setattr(web_main, "SESSION_DB_PATH", db_path)
    monkeypatch.setattr(web_main, "_MATCREATOR_MODE", "local")

    latest = json.loads(asyncio.run(web_main.get_user_session("current-user", "session-1", limit=2)).body)

    assert [event["event"] for event in latest["events"]] == ["third", "fourth"]
    assert latest["pagination"]["has_more"] is True
    earlier = json.loads(asyncio.run(web_main.get_user_session(
        "current-user", "session-1", limit=2, before=latest["pagination"]["next_before"],
    )).body)
    assert [event["event"] for event in earlier["events"]] == ["persisted", "second"]
    assert earlier["pagination"]["has_more"] is False
    assert earlier["pagination"]["next_before"] == ""

    newer = json.loads(asyncio.run(web_main.get_user_session(
        "current-user", "session-1", limit=2, after=earlier["pagination"]["end_cursor"],
    )).body)
    assert [event["event"] for event in newer["events"]] == ["third", "fourth"]
    assert newer["pagination"]["has_more_after"] is False


def test_execution_graph_endpoint_reads_atomic_graph_snapshot(monkeypatch, tmp_path):
    web_main = _load_web_main(monkeypatch)
    db_path = tmp_path / "session.db"
    _create_session_db(db_path, web_main.APP_NAME)
    graph = {
        "graph_id": "plan-2",
        "nodes": {"step-1": {"label": "Prepare structure", "status": "pending"}},
        "edges": [],
    }
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            "UPDATE sessions SET state = ? WHERE app_name = ? AND id = ?",
            (json.dumps({"execution_graph": [graph]}), web_main.APP_NAME, "session-1"),
        )
        conn.commit()
    monkeypatch.setattr(web_main, "SESSION_DB_PATH", db_path)
    monkeypatch.setattr(web_main, "_MATCREATOR_MODE", "local")

    response = asyncio.run(web_main.get_execution_graph("session-1"))

    assert json.loads(response.body) == graph


def test_compact_history_preserves_completion_row_reference(monkeypatch, tmp_path):
    web_main = _load_web_main(monkeypatch)
    db_path = tmp_path / 'session.db'
    _create_session_db(db_path, web_main.APP_NAME)
    monkeypatch.setattr(web_main, 'SESSION_DB_PATH', db_path)
    monkeypatch.setattr(web_main, '_MATCREATOR_MODE', 'local')
    reference = {
        'kind': 'aidb_completion', 'result_id': 'job-1',
        'user_id': 'legacy-display-name', 'session_id': 'session-1',
    }
    payload = {'result': {'aidb_result': reference, 'log': 'x' * 100_000}}
    event = {'content': {'parts': [{'functionResponse': {'id': 'collect', 'response': payload}}]}}
    with sqlite3.connect(db_path) as conn:
        conn.execute('INSERT INTO events VALUES (?, ?, ?, ?, ?)', (
            web_main.APP_NAME, 'legacy-display-name', 'session-1', json.dumps(event), 2.0,
        ))

    response = asyncio.run(web_main.get_user_session('legacy-display-name', 'session-1', compact=True))
    event = json.loads(response.body)['events'][-1]
    preview = event['content']['parts'][0]['functionResponse']['response']

    assert preview['aidb_completions'] == [reference]
    assert '_matcreator_deferred_detail' in preview
    assert 'log' not in json.dumps(preview)
