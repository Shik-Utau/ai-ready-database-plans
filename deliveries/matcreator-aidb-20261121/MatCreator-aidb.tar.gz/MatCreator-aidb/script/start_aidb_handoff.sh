#!/usr/bin/env bash
set -euo pipefail
project_root="$(cd "$(dirname "$0")/.." && pwd)"
runtime_dir="${1:-$project_root/.handoff}"
if [[ ! -f "$runtime_dir/env.sh" ]]; then
    echo "请先运行 python3 script/install_aidb_handoff.py；可传运行目录作为本脚本的第一个参数。" >&2
    exit 1
fi
source "$runtime_dir/env.sh"
cd "$project_root"
exec bash script/start_matcreator.sh
