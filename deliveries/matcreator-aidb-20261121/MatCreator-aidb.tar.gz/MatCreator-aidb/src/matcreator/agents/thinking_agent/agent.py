from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import threading
from typing import Optional

from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm
from google.adk.tools.function_tool import FunctionTool
from matcreator.tools.aidb_archive_tools import aidb_archive_vasp
from matcreator.tools.aidb_tools import aidb_query, aidb_detail, aidb_bind
from matcreator.tools.aidb_tools import aidb_export
from matcreator.tools.relaxation_tools import vasp_relaxation_choice
from matcreator.aidb.relaxation import choice_receipt, current_choice, turn_id
from matcreator.tools.xrd_tools import xrd_list_workspaces, xrd_get_results, xrd_action
from google.adk.tools.tool_context import ToolContext
from google.adk.agents.callback_context import CallbackContext

from ...constants import LLM_API_KEY, LLM_BASE_URL, LLM_MODEL
from ...adk_compat import install_lenient_tool_argument_parsing
from .planning import validate_plan, validate_graph
from .intent import validate_intent
from .summarize import validate_summarize
from .session_summary import write_session_summary
from ...skill import ALL_SKILLS, refresh_skills, seed_skills_to_graph
from .memory import (
    chat_with_knowledge_graph,
    get_related_skills,
    query_knowledge_graph,
    read_knowledge_node,
    read_memory,
    run_synthesizer,
    save_to_knowledge_graph,
    update_memory,
)
from ...tools.workspace_tools import (
    get_user_skills_root,
    init_workspace_tool,
    run_bash,
    run_python,
    set_session_output_dir,
    set_session_workdir,
)
from ...workspace import get_session_workdir
from ..execution_graph_state import get_execution_graph, set_execution_graph
from ...tools.util_tools import (
    show_artifact,
    show_plot,
    show_structure
)
from .history_tools import read_session_log
from ..execution_agent.remote_job_tools import list_remote_jobs


logger = logging.getLogger(__name__)

_model_name = os.environ.get("LLM_MODEL", LLM_MODEL)
_model_api_key = os.environ.get("LLM_API_KEY", LLM_API_KEY)
_model_base_url = os.environ.get("LLM_BASE_URL", LLM_BASE_URL)

# Some OpenAI-compatible endpoints occasionally emit malformed JSON in a
# streamed tool call.  Retrying the LLM node is the safe recovery: attempting
# to salvage a partial/concatenated payload could execute the wrong tool args.
# Recovery is handled at the orchestrator level (see
# ``orchestrator/agent.py:_stream_planning_with_recovery``), which wraps the
# planning stream in a try/except json.JSONDecodeError — mirroring the
# execution-phase recovery.  The legacy ``RetryConfig`` did nothing here
# because ``LlmAgent`` runs through ``llm_flows``, which does not consume
# ``retry_config``.

def _seed_skills_background() -> None:
    try:
        seed_skills_to_graph()
    except Exception as _seed_exc:
        logger.warning("Failed to seed skills into knowledge graph: %s", _seed_exc)

threading.Thread(target=_seed_skills_background, name="seed-skills", daemon=True).start()


def load_skill(skill_name: str) -> dict:
    """Load skill information by name.

    Returns the full SKILL.md instructions for every installed skill. Call this
    after ``query_knowledge_graph`` to read a selected skill; use
    ``read_knowledge_node`` separately only for graph-attached L3/L4 context.
    When the graph has a matching node, the response includes
    ``attached_context`` counts (plus related-skill connections) and, when
    nonzero, an exact follow-up hint. The response also lists the skill's
    bundled sidecar files (``references/``, ``assets/``, ``scripts/``) and
    their on-disk folder under ``bundled_files``.

    Args:
        skill_name: Exact name returned by query_knowledge_graph.
    """
    normalized = (skill_name or "").strip()
    skill = next((s for s in ALL_SKILLS if s.name == normalized), None)
    if skill is None:
        lowered = normalized.lower()
        skill = next((s for s in ALL_SKILLS if s.name.lower() == lowered), None)

    if skill is None:
        return {
            "status": "error",
            "message": f"Skill '{skill_name}' not found.",
            "available_skills": sorted(s.name for s in ALL_SKILLS),
        }

    from ...skill import is_skill_disabled
    if is_skill_disabled(skill.name):
        return {
            "status": "error",
            "message": f"Skill '{skill_name}' is disabled.",
        }

    result: dict[str, object] = {
        "status": "ok",
        "skill": skill.name,
        "description": skill.description,
        "instructions": skill.instructions,
    }
    from ...skill import format_skill_bundle_hint, skill_bundle_info
    from ...knowledge.query import format_node_context_hint, get_node_context_summary

    bundle = skill_bundle_info(skill.name)
    if bundle is not None:
        result["bundled_files"] = bundle
        bundle_hint = format_skill_bundle_hint(skill.name, bundle)
        if bundle_hint:
            result["bundled_files_hint"] = bundle_hint

    context = get_node_context_summary(skill.name)
    if context is not None:
        result["attached_context"] = context
        hint = format_node_context_hint(context)
        if hint:
            result["attached_context_hint"] = hint
    return result


def confirm_plan_and_start_execution(tool_context: ToolContext) -> dict:
    """Signal that the user has approved the plan and execution should begin.

    Call this when the user explicitly confirms they want to proceed with the plan
    (e.g. "yes", "proceed", "go ahead").  The orchestrator will then delegate each
    graph node to the execution agent — do NOT execute nodes yourself after calling this.
    """
    from ..cancellation import clear_cancellation

    choice = current_choice(tool_context)
    if choice and choice["status"] in {"waiting", "continue"}:
        return {"status": "error", "message": "请先处理本轮 VASP 候选。继续现有步骤应使用 resume_execution。"}
    sid = tool_context.state.get("session_id") or tool_context._invocation_context.session.id
    clear_cancellation(sid)

    # The model may retry a successful tool call before the orchestrator gets
    # control back. Confirmation must not reset nodes that already started or
    # completed during that window.
    if tool_context.state.get("execution_approved", False):
        return {
            "status": "ok",
            "message": "Execution was already approved; hand control back to the orchestrator.",
        }

    # Reset all node statuses so a fresh run starts clean
    graph = get_execution_graph(tool_context.state)
    if graph and isinstance(graph.get("nodes"), dict):
        for node in graph["nodes"].values():
            node["status"] = "pending"
            node["result"] = None
        set_execution_graph(tool_context.state, graph)

    tool_context.state["execution_approved"] = True
    tool_context.state["_node_exec_counter"] = 0
    return {
        "status": "ok",
        "message": "Execution approved. STOP making further calls.",
    }


def resume_execution(tool_context: ToolContext) -> dict:
    """Resume execution from the current graph state.

    Call this when the user explicitly requests to continue execution after an interruption.
    """
    if tool_context.state.get("execution_approved", False):
        return {
            "status": "ok",
            "message": "Execution resume was already approved; hand control back to the orchestrator.",
        }

    choice = current_choice(tool_context)
    if choice and (choice["status"] == "waiting" or (
        choice["status"] == "continue" and choice["decision_turn"] != turn_id(tool_context)
    )):
        return {"status": "error", "message": "请先处理本轮 VASP 候选。"}

    graph = get_execution_graph(tool_context.state)
    if not graph or not graph.get("nodes"):
        return {
            "status": "error",
            "message": "No execution_graph found in session state. Create/validate a graph first.",
        }

    pending = [nid for nid, n in graph["nodes"].items() if n.get("status") == "pending"]
    if not pending:
        return {
            "status": "error",
            "message": "No pending nodes remain — all nodes are complete or blocked.",
        }

    tool_context.state["return_to_planner"] = False
    tool_context.state["return_to_planner_reason"] = None
    tool_context.state["execution_approved"] = True

    return {
        "status": "ok",
        "message": (
            f"Execution resume approved. "
            f"The orchestrator will continue with {len(pending)} pending node(s)."
        ),
    }


# ---------------------------------------------------------------------------
# Mode helper
# ---------------------------------------------------------------------------


def _get_agent_mode(state: dict) -> str:
    """Return the active agent mode: 'flash', 'bench', or 'normal'."""
    mode = state.get("agent_mode")
    if mode in ("normal", "bench", "flash"):
        return mode
    return "bench" if state.get("benchmark_mode", False) else "normal"


# ---------------------------------------------------------------------------
# Flash mode: ad-hoc step execution
# ---------------------------------------------------------------------------


async def run_flash_step(
    action: str,
    suggested_skills: list[str],
    tool_context: ToolContext,
    label: Optional[str] = None,
) -> dict:
    """Execute a step ad-hoc. No DAG or plan required.

    Use when direct computation, scripts, or skill-level execution is needed.
    Multiple independent calls in one response turn run concurrently.

    Args:
        action: What to do (same semantics as a DAG node action).
        suggested_skills: Skill names to preload in the executor.
        label: Optional display name shown in the agent graph. Reuse the SAME label
            when re-running the same logical task so any remote job it submitted is
            re-attached rather than duplicated.
    """
    from ..execution_agent.step_executor_runner import run_step_executor

    counter = tool_context.state.get("_flash_step_counter", 0) + 1
    tool_context.state["_flash_step_counter"] = counter
    # The node ID is the identity a remote job is tracked under, so it must be
    # stable across retries of the same logical task.  Deriving the fallback from
    # the action (rather than an incrementing counter) means a repeated step
    # re-attaches to its existing job instead of submitting a duplicate one.
    if label:
        node_id = label.lower().replace(" ", "_")[:40]
    else:
        node_id = f"flash_{hashlib.sha256(action.encode()).hexdigest()[:12]}"

    choice = await asyncio.to_thread(current_choice, tool_context)
    if choice and choice["status"] == "waiting":
        return {"node_id": choice["scope"]["node_id"], **choice_receipt(choice)}
    if choice and choice["status"] == "continue":
        if choice["decision_turn"] != turn_id(tool_context):
            return {"status": "error", "message": "请用户明确继续本次 VASP 计算。"}
        node_id = choice["scope"]["node_id"]
        action = choice["action"] or action
        suggested_skills = choice["skills"] or suggested_skills

    result = await run_step_executor(
        step_number=counter,
        action=action,
        suggested_skills=suggested_skills,
        workspace_dir="",
        prior_context=None,
        node_id=node_id,
        tool_context=tool_context,
    )
    # Surface the durable identity to transcript consumers.  In particular a
    # label-less Flash call cannot reproduce the SHA-derived id from its tool
    # arguments without hashing asynchronously in the browser.
    return {"node_id": node_id, **result}


# ---------------------------------------------------------------------------
# Instructions
# ---------------------------------------------------------------------------

_FLASH_INSTRUCTION = """
You are MatCreator, an AI assistant for computational materials science.
**Flash mode**: act as a direct, conversational assistant.

## Context
- Goal: {goal}

## How to work
- Call `run_flash_step` for computation, or skill execution.
  Multiple independent calls in one response turn run concurrently.
- For MatPES labeling, delegate to `vasp-pymatgen`. Keep its returned batch ID for collection and status updates. Refer to candidates by source frame and delegate a selection, recalculation, or cancellation only when the user explicitly decides for that frame.
- Use `query_knowledge_graph` to discover clipped L1/L2 skills, knowledge, and memory candidates.
- Set `skills_only=true` and `include_memory=false` only when you specifically need skill-only discovery.
- An explicit request to save existing VASP relaxation, static SCF or MD outputs can call `aidb_archive_vasp` directly once the workspace directories are clear. Report each receipt and use its clickable result after verified readback.
- For a request to calculate VASP AIMD, plan the `vasp-pymatgen` workflow with the requested ensemble, temperature or program, time step, integration count and deliverables. Use its AIMD reference for input preparation and the managed VASP tools for submission and collection.
- For AIDB queries/details, discover and load `ai-ready-db`, then call `aidb_query`/`aidb_detail` so results use this chat's bound database and clickable presentation. Clarify ambiguous filters. Record editing/deletion is unavailable.
- `aidb_detail` directly fresh-reads the referenced record and opens its full presenter. Answer from returned facts; do not delegate a raw JSONL read or request approval for this supported read. Omitted arrays remain in the UI snapshot. Preserve unknown, false, not-applicable and truncation states. Label presence does not establish alignment, convergence, compatibility or training admission; never infer that records differ only in functional from this bounded summary. Distinguish native match counts, visible rows and verified frames.
- Call `load_skill` for a selected installed skill's full instructions.
- For all AIDB reads, omission from model facts is not evidence that a field is missing or not applicable. Never claim fields were not saved/extracted just because they are unlisted. Use optional_results availability and evidence; not_provided refers to the returned record, not raw-output capability. PAW projected electron populations are not oxidation states. Null magnetic moments or spin settings do not establish material magnetism; preserve not_assessed.
- Inspect `load_skill`'s `attached_context`; call `read_knowledge_node` only when its L3/L4 count is nonzero.
- Inspect `load_skill`'s `bundled_files` (references/, assets/, scripts/ paths plus the
  on-disk skill folder) whenever the skill bundles sidecar files; read them from disk when needed.
- For skill creation or evaluation requests, load the `skill-creation` guide and
  call `run_flash_step` with `suggested_skills=["skill-creation"]`.
- After completing work, call `save_to_knowledge_graph` to persist key findings.
- Use `chat_with_knowledge_graph` when the user wants to inspect or update the Know-Do Graph directly.

## Rules
- Be concise and responsive.
- Do NOT call `validate_graph` or `confirm_plan_and_start_execution`.
- Quote exact error messages and propose concrete solutions when something fails.
- A `run_flash_step` result with `status == "waiting"` is NOT a failure: the executor hit
  its timeout while the step's `remote_job` is still running on the provider. Report the
  job identity to the user and stop. Do NOT re-run the step to "restart" the job.
  To check on it later, call `run_flash_step` again with the SAME `label` and an action
  that says to call `get_remote_job_status` with that job_id and collect results if finished —
  never to submit a new job.
"""

_NORMAL_INSTRUCTION = """
You are MatCreator, an AI assistant for computational materials science workflows.
Your role here is **PLANNING ONLY** for computation and changes: concrete execution steps must be delegated to the execution agent. The scoped AIDB operations below are direct-tool exceptions.

## Context
- Goal: {goal}
- Execution graph: {execution_graph}
- Summarize: {summarize}

## Default workflow
When the user explicitly asks to save existing VASP relaxation, static SCF or MD results, discover/load the installed `ai-ready-db` skill and call `aidb_archive_vasp` directly with the specified workspace directories. The explicit save request authorizes this archive; it requires no calculation plan or submission. The installed skill's stock insert cannot verify the paired outputs for this workflow. Use the archive receipt for new, existing, or incomplete status per directory and leave details to the shared result presenter.

For a read-only AIDB query/detail request, discover and load `ai-ready-db`, then directly call `aidb_query`/`aidb_detail` using this chat's binding. This exception does not require an execution graph or approval. `aidb_detail` freshly reads the referenced ID and opens the full presenter; answer from its returned cell, method, label and source facts instead of planning raw JSONL inspection. Omitted arrays remain in the UI snapshot. Preserve unknown, false, not-applicable and truncation states. Label presence does not establish alignment, convergence, compatibility or training admission; never infer that records differ only in functional from the bounded summary. Distinguish native match counts, visible rows and verified frames. Clarify ambiguous references/filters. Record editing/deletion is unavailable.
For a natural-language AIDB export, call aidb_export directly after skill discovery. Use the actual record ID and, for a prior result row, its result ID. Return only the download formats confirmed in the receipt and explain any missing labels.

For all AIDB reads, omission from model facts is not evidence that a field is missing or not applicable. Never claim fields were not saved/extracted just because they are unlisted. Use optional_results availability and evidence; not_provided refers to the returned record, not raw-output capability. PAW projected electron populations are not oxidation states. Null magnetic moments or spin settings do not establish material magnetism; preserve not_assessed.

For other requests:
1. Determine the user's goal, then call `validate_intent` with your interpretation.
   Call `query_knowledge_graph` once with the user's goal to discover relevant skills, knowledge, and lessons.
   Load selected installed skills with `load_skill`. Inspect its `attached_context` and call
   `read_knowledge_node` only when it reports attached L3 heuristics or L4 constraints.
   Inspect its `bundled_files` when the skill bundles sidecar files (references/, assets/,
   scripts/) and pass those paths to the executor in the node action.
   Use `get_related_skills` to discover its dependencies or closely related workflows.
2. Always draft an execution graph, then call `validate_graph` to validate and commit it.
   Present the plan to the user as a Markdown table with columns:
   **Node ID | Label | Action | Depends On**
   (where "Depends On" lists predecessor node IDs, or "—" for root nodes).
{confirmation_instruction}

4. If the user asks to create or test a skill:
   a. Call `query_knowledge_graph(skills_only=true, include_memory=false)` and `load_skill` for the `skill-creation` guide.
   b. Create a normal execution graph node with `suggested_skills=["skill-creation"]`.
   c. The node action must say that generated skills belong under the user skills root
      returned by `get_user_skills_root`, not under the workspace skills directory.
5. After completing a node, use `save_to_knowledge_graph` to persist key lessons or findings.
6. Once execution has fully completed, call `write_session_summary` with the global narrative.
7. When the user requests direct Know-Do Graph interaction, call
   `chat_with_knowledge_graph`.

## DAG Planning Guidelines
- **Node IDs**: use descriptive snake_case prefixed with `step_`, e.g. `step_download_data`.
- **Edges**: `[predecessor_id, successor_id]` — predecessor must complete before successor starts.
  Independent nodes (no shared data, no ordering constraint) need no edge and will execute in parallel.
- **Keep graphs small**: 2–4 nodes for simple tasks, 5–7 for complex ones.
  Merge operations that belong to the same skill or logical unit into a single node.
- **Suggested skills**: include only exact names returned by `query_knowledge_graph`. Use `[]`
  when no installed skill is specifically needed; do not invent a skill name.
- **validate_graph input shape**:
  ```json
  {{
    "nodes": {{
      "step_download_data": {{
        "node_id": "step_download_data",
        "label": "Download Data",
        "action": "Download VASP output files from the remote server.",
        "suggested_skills": ["utility"]
      }},
      "step_relax": {{
        "node_id": "step_relax",
        "label": "Relax Geometry",
        "action": "Run VASP geometry relaxation in the workspace.",
        "suggested_skills": ["vasp-pymatgen"]
      }}
    }},
    "edges": [["step_download_data", "step_relax"]],
    "additional_notes": "Requires VASP 6.x."
  }}
  ```

## Rules
- NEVER execute plan nodes.
- When the user asks to keep outputs in a session-specific folder, call
    `set_session_output_dir` with a relative subdirectory under the workspace before execution.
    Every call creates a new directory; if the requested name exists, the tool adds a numeric
    suffix such as `_01`. Always use and report the output path returned by the tool rather than
    assuming the requested name was created.
    The executor can still read shared files from the workspace root, but generated files
    should be written under the configured output directory.
- Keep responses concise; reference absolute file paths where relevant.
- When you encounter an error, quote the exact message and propose concrete solutions.
- You may call `run_synthesizer` when the knowledge graph seems stale or after heavy knowledge accumulation.

## Reviewing execution history
- Use the current `execution_graph` state for normal replanning; avoid re-running
    nodes that already succeeded.
- A node with status `waiting` is NOT a failure: its step executor was released at its
    timeout while the node's `remote_job` is still running on the provider. The job is
    durable and keeps running without any executor attached.
    - Do NOT replan around it, do NOT add a replacement node, and do NOT plan a new job
      submission for it — that would duplicate the running job.
    - Tell the user the job is still running and report its `remote_job` identity.
    - When the user asks to check on it or the job is expected to be done, call
      `set_node_status(node_id="...", status="pending")` and hand control back so the
      node runs again; its executor automatically re-attaches to the same job.
- Before answering questions about running/tracked jobs, or after a restart, call
    `list_remote_jobs()` for an authoritative, low-noise list of this session's remote
    jobs (job IDs, providers, statuses) instead of relying on conversation history.
    Pass `active_only=True` to hide finished jobs.
- As a last-resort debug path, call `read_session_log(view="overview")` first to inspect
    the coarse executor graph. Only then call `read_session_log(view="detail", step_id="...")`
    or `node_id="..."` for one executor of interest; do not request bulk detail by default.
"""

_VASP_CHOICE_INSTRUCTION = """
If a VASP step reports waiting_choice, a result card has the verified candidates.
Tell the user they can view Details, reply with an ordinal to reuse, continue calculation,
revise inputs or cancel. Stop for their response. Do not submit, archive, export,
or finish that step while waiting. This is a user decision, not a running remote job.
If a pending choice is provided below, route the user's latest response with
vasp_relaxation_choice and that choice_id. For detail, call action=detail and keep waiting.
For reuse, call action=select with the exact ordinal or record ID. If several candidates
fit their reference, ask which one; never guess. A reused receipt already contains
downloadable EXTXYZ and POSCAR, energy, and any verified required raw artifacts.
Use the returned artifact_paths for downstream VASP inputs. In a band-structure
chain, keep SCF and NSCF as distinct dependent steps. After reusing SCF, use its
record ID and delivered restart paths to resume the NSCF node when authorized.
Report completion only after NSCF delivers both the band data and plot. Present those results
directly and do not call aidb_export again for the same request.
For changed conditions call revise before preparing new inputs. For cancellation or a
new task call cancel first. For unrelated discussion that replaces the task, close the choice
before answering. Never reuse a closed choice even if old cards appear in chat.
For an explicit decision to recalculate, call continue, then follow the original approval
rules. In Flash invoke run_flash_step once for the same step. In graph mode call
resume_execution when the original authorization is satisfied. Honor stale-input errors
by preparing changed inputs and checking again. Opening a record never authorizes reuse.
"""

_MATCREATOR_INSTRUCTION = "{instruction_body}"

# ---------------------------------------------------------------------------
# before_agent_callback: inject dynamic context into session state
# ---------------------------------------------------------------------------

def before_agent_callback(callback_context: CallbackContext) -> None:
    """Refresh memory and state each invocation."""
    state = callback_context._invocation_context.session.state
    for key, default in [
        ("execution_graph", None),
        ("goal", None),
        ("summarize", None),
        ("trajectory_step", 0),
    ]:
        if key not in state:
            callback_context.state[key] = default

    # Ensure workspace_dir reflects the session's actual workdir (respects custom_workdir)
    session_id = state.get("session_id", "default")
    callback_context.state["workspace_dir"] = state.get("workdir") or str(get_session_workdir(session_id))

    agent_mode = _get_agent_mode(state)
    if agent_mode == "flash":
        callback_context.state["instruction_body"] = _FLASH_INSTRUCTION.format(
            goal=state.get("goal") or "Not set",
        )
    else:
        if agent_mode == "bench":
            confirmation_instruction = (
                "3. **Benchmark mode is active.** Immediately call `confirm_plan_and_start_execution` "
                "after `validate_graph` succeeds — do NOT wait for user confirmation."
            )
        else:
            confirmation_instruction = (
                '3. **Wait for explicit user confirmation** (e.g. "yes", "ok", "proceed") before proceeding.\n'
                "   When the user confirms, call `confirm_plan_and_start_execution` — do NOT execute nodes yourself."
            )
        callback_context.state["instruction_body"] = _NORMAL_INSTRUCTION.format(
            goal=state.get("goal") or "Not set",
            execution_graph=get_execution_graph(state),
            summarize=state.get("summarize"),
            confirmation_instruction=confirmation_instruction,
        )

    choice = current_choice(callback_context)
    choice_context = ""
    if choice and choice["status"] in {"waiting", "continue"}:
        ids = [item["record_id"] for item in choice["candidates"]["records"]]
        choice_context = f"\nCurrent VASP result choice: {choice['id']}; ordered record IDs: {ids}.\n"
    elif choice:
        choice_context = ("\nThe previous VASP result choice is closed. A reference to one of its "
                          "rows alone is not a new calculation or query request. Tell the user the "
                          "previous choice is closed, and do not start a new step for that reference.\n")
    callback_context.state["instruction_body"] += _VASP_CHOICE_INSTRUCTION + choice_context
    return None

# ---------------------------------------------------------------------------
# MatCreator agent instance
# ---------------------------------------------------------------------------

# Repair malformed tool-call argument JSON (unescaped inner quotes) emitted by
# some OpenAI-compatible endpoints instead of crashing the planning stream.
install_lenient_tool_argument_parsing()


thinking_agent = LlmAgent(
    name="MatCreator",
    model=LiteLlm(
        model=_model_name,
        base_url=_model_base_url,
        api_key=_model_api_key,
    ),
    description=(
        "MatCreator: plans and executes computational materials science workflows "
        "through natural conversation with the user."
    ),
    instruction=_MATCREATOR_INSTRUCTION,
    tools=[
        FunctionTool(validate_graph),
        #FunctionTool(validate_plan),   # kept for backward compatibility
        FunctionTool(validate_intent),
        FunctionTool(validate_summarize),
        FunctionTool(write_session_summary),
        FunctionTool(confirm_plan_and_start_execution),
        FunctionTool(resume_execution),
        FunctionTool(read_knowledge_node),
        FunctionTool(get_related_skills),
        FunctionTool(query_knowledge_graph),
        FunctionTool(save_to_knowledge_graph),
        FunctionTool(chat_with_knowledge_graph),
        FunctionTool(run_synthesizer),
        FunctionTool(read_memory),
        FunctionTool(update_memory),
        FunctionTool(init_workspace_tool),
        FunctionTool(set_session_output_dir),
        #FunctionTool(set_session_workdir),
        FunctionTool(refresh_skills),
        FunctionTool(get_user_skills_root),
        FunctionTool(run_python),
        FunctionTool(run_bash),
        FunctionTool(aidb_query),
        FunctionTool(aidb_detail),
        FunctionTool(aidb_export),
        FunctionTool(vasp_relaxation_choice),
        FunctionTool(aidb_bind),
        FunctionTool(aidb_archive_vasp),
        FunctionTool(xrd_list_workspaces),
        FunctionTool(xrd_get_results),
        FunctionTool(xrd_action),
        FunctionTool(run_flash_step),
        FunctionTool(read_session_log),
        FunctionTool(list_remote_jobs),
        FunctionTool(load_skill),
        show_artifact,
        show_plot,
        show_structure,
    ],
    before_agent_callback=before_agent_callback,
)
