#!/usr/bin/env python3
"""Verify the AI-Ready DB environment is correctly set up."""

from __future__ import annotations

import sys


def check_python_version() -> bool:
    """Ensure Python >= 3.10."""
    ok = sys.version_info >= (3, 10)
    print(f"Python version: {sys.version}")
    if not ok:
        print("  FAIL: Python >= 3.10 required")
    else:
        print("  OK")
    return ok


def check_imports() -> bool:
    """Check core dependencies are importable."""
    required = [
        "yaml",
        "ase",
        "h5py",
        "numpy",
        "pymatgen",
        "sqlalchemy",
    ]
    optional = [
        "fastmcp",
    ]
    ok = True
    for mod in required:
        try:
            __import__(mod)
            print(f"  {mod}: OK")
        except ImportError:
            print(f"  {mod}: MISSING (required)")
            ok = False
    for mod in optional:
        try:
            __import__(mod)
            print(f"  {mod}: OK")
        except ImportError:
            print(f"  {mod}: MISSING (optional, install with pip install -e '.[mcp]')")
    return ok


def check_skill_actions() -> bool:
    """Verify agent actions load and dispatch correctly."""
    try:
        from ai_ready_db.ai_ready_db_Renaissance.skills.agent_handle import (
            available_agent_actions,
            handle_agent_action,
        )

        actions = available_agent_actions()
        print(f"  Available actions: {actions}")
        expected = ("renaissance_start", "finalize_dft", "finetune_plan", "accept_cloud_plan", "reject_cloud_plan")
        if actions == expected:
            print("  OK")
            return True
        print(f"  FAIL: Expected {expected}")
        return False
    except Exception as exc:
        print(f"  FAIL: {exc}")
        return False


def main() -> int:
    print("=== AI-Ready DB Environment Verification ===\n")

    checks = [
        ("Python version", check_python_version),
        ("Core imports", check_imports),
        ("Skill actions", check_skill_actions),
    ]

    all_ok = True
    for name, fn in checks:
        print(f"\n{name}:")
        if not fn():
            all_ok = False

    print("\n" + "=" * 45)
    if all_ok:
        print("All checks passed. Environment is ready.")
        return 0
    print("Some checks failed. See above for details.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
