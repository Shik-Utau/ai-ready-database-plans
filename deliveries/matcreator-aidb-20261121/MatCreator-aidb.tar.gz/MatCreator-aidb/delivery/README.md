# AIDB delivery sources

Start with [installation and file ownership](../docs/aidb-handoff.md).

- Base MatCreator commit: `46737212860c53ca739c28ee02ac8db2a2fab7fc`.
- `skills/ai-ready-db/`: snapshot of the independently maintained installed MatCreator skill, matching the acceptance copies. The delivery adds hosted-tool routing and updates maintenance references. `manifest.json` retains the original file digests and the delivered file digests separately.
- `vendor/ai-ready-db/`: runtime-only source snapshot from [Zikkying/Ai-ready_Database](https://github.com/Zikkying/Ai-ready_Database/tree/008e881676c12fe2028200c944cc8bd99fabbdfb), commit `008e881676c12fe2028200c944cc8bd99fabbdfb`. Tracked `ai_ready_db/`, `configs/` and `pyproject.toml` are copied byte-for-byte. Upstream dirty skill/docs changes, private data and virtualenv are excluded. This is a source snapshot of the user's dependency, not a claim that upstream is released under MatCreator's Apache license; the pinned upstream tree did not contain a LICENSE file. Preserve this provenance when redistributing and settle upstream licensing before broader public redistribution.
- `constraints.txt`: installed acceptance-environment constraints; `requirements-linux-py312.lock`: resolved runtime dependencies for the two projects on Python 3.12. Editable local projects are installed separately. The frontend uses its existing `package-lock.json`.

Runtime state belongs outside this directory. To update a snapshot, review the source diff, update provenance and file digests, and rerun the installation/check workflow. Do not copy live configs, datasets, tokens, `.adk` or `__pycache__` into the delivery.
