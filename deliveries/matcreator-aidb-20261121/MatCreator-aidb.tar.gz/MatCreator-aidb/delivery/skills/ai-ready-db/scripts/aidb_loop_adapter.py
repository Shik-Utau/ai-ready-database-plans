#!/usr/bin/env python3
"""MatCreator-facing orchestration for the local ai-ready-db loop.

This script contains no database business logic. It validates task input,
builds target-profile JSON files, invokes the public aidb CLI through
``aidb_client.py``, stores complete command results as workspace artifacts, and
prints a compact JSON receipt that stays below MatCreator's output limit.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import tempfile
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


CLIENT = Path(__file__).with_name("aidb_client.py")
SAFE_NAME = re.compile(r"[^A-Za-z0-9_.-]+")


class InputError(ValueError):
    """The task or command input is invalid."""


class AidbCommandError(RuntimeError):
    def __init__(self, kind: str, detail: str, result_path: Path):
        super().__init__(detail)
        self.kind = kind
        self.result_path = result_path


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _safe_name(value: str) -> str:
    cleaned = SAFE_NAME.sub("-", value.strip()).strip("-._")
    return cleaned[:80] or "task"


def _atomic_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True, default=str)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)


def _read_json(path: Path, label: str) -> dict[str, Any]:
    if not path.is_file():
        raise InputError(f"{label} does not exist: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise InputError(f"invalid {label} JSON {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise InputError(f"{label} must contain a JSON object: {path}")
    return payload


class AuditRun:
    def __init__(self, workspace: Path, task_id: str, run_id: str | None = None):
        run_id = run_id or f"{int(time.time())}-{uuid.uuid4().hex[:8]}"
        self.directory = (
            workspace.resolve()
            / ".aidb"
            / "runs"
            / _safe_name(task_id)
            / _safe_name(run_id)
        )
        self.command_timeout: float | None = None
        self.directory.mkdir(parents=True, exist_ok=False)
        self.audit_path = self.directory / "audit.json"
        self.payload: dict[str, Any] = {
            "schema_version": 1,
            "task_id": task_id,
            "run_id": run_id,
            "started_at": _now(),
            "status": "running",
            "events": [],
            "artifacts": {},
        }
        self._write()

    def _write(self) -> None:
        _atomic_json(self.audit_path, self.payload)

    def event(self, stage: str, status: str, **data: Any) -> None:
        self.payload["events"].append(
            {"time": _now(), "stage": stage, "status": status, **data}
        )
        self._write()

    def artifact(self, name: str, path: Path) -> None:
        self.payload["artifacts"][name] = str(path.resolve())
        self._write()

    def finish(self, status: str, **summary: Any) -> None:
        self.payload["status"] = status
        self.payload["finished_at"] = _now()
        self.payload["summary"] = summary
        self._write()


def _classify_failure(returncode: int, stderr: str) -> tuple[str, str]:
    detail = stderr.strip() or f"aidb command exited with code {returncode}"
    try:
        payload = json.loads(stderr)
    except json.JSONDecodeError:
        payload = None
    if isinstance(payload, dict) and payload.get("error"):
        return str(payload["error"]), str(payload.get("detail") or detail)
    return ("invalid_request" if returncode == 2 else "aidb_command_failed", detail)


def run_aidb(
    audit: AuditRun,
    stage: str,
    argv: list[str],
    *,
    expect_json: bool = True,
) -> tuple[dict[str, Any] | None, Path]:
    started = time.monotonic()
    timed_out = False
    env = os.environ.copy()
    if audit.command_timeout is not None:
        env["AI_READY_DB_BRIDGE_TIMEOUT"] = str(audit.command_timeout)
        env["AI_READY_DB_BRIDGE_STARTUP_TIMEOUT"] = str(min(15, audit.command_timeout))
    try:
        proc = subprocess.run(
            [sys.executable, str(CLIENT), *argv],
            capture_output=True, text=True, check=False,
            env=env, timeout=audit.command_timeout,
        )
    except subprocess.TimeoutExpired as exc:
        timed_out = True
        def decode(value: str | bytes | None) -> str:
            return value.decode(errors="replace") if isinstance(value, bytes) else (value or "")
        proc = subprocess.CompletedProcess(
            args=exc.cmd, returncode=124, stdout=decode(exc.stdout),
            stderr=json.dumps({"error": "timeout", "detail":
                f"{stage} exceeded {audit.command_timeout}s; server-side completion is unknown"}),
        )
    parsed: dict[str, Any] | None = None
    parse_error: str | None = None
    if expect_json and proc.stdout.strip():
        try:
            candidate = json.loads(proc.stdout)
            if not isinstance(candidate, dict):
                raise ValueError("JSON response is not an object")
            parsed = candidate
        except (json.JSONDecodeError, ValueError) as exc:
            parse_error = str(exc)
    command_index = len(
        list((audit.directory / "commands").glob("*.json"))
    ) + 1
    result_path = (
        audit.directory / "commands" / f"{command_index:03d}-{_safe_name(stage)}.json"
    )
    result = {
        "stage": stage,
        "timed_out": timed_out,
        "argv": argv,
        "returncode": proc.returncode,
        "stdout": proc.stdout,
        "stderr": proc.stderr,
        "parsed": parsed,
        "parse_error": parse_error,
        "duration_s": round(time.monotonic() - started, 6),
    }
    _atomic_json(result_path, result)
    audit.event(
        stage,
        "success" if proc.returncode == 0 and not parse_error else "failed",
        returncode=proc.returncode,
        result_path=str(result_path.resolve()),
        duration_s=result["duration_s"],
    )
    if proc.returncode != 0:
        kind, detail = _classify_failure(proc.returncode, proc.stderr)
        raise AidbCommandError(kind, detail, result_path)
    if expect_json and (parse_error or parsed is None):
        raise AidbCommandError(
            "invalid_json", parse_error or "aidb returned empty JSON", result_path
        )
    return parsed, result_path


def _with_config(argv: list[str], config: Path | None) -> list[str]:
    if config is None:
        return argv
    return [*argv, "--config", str(config)]


def _normalise_related(raw: Any) -> list[dict[str, Any]]:
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise InputError("related_materials must be a list")
    related: list[dict[str, Any]] = []
    for index, item in enumerate(raw):
        if isinstance(item, str):
            item = {"formula": item}
        if not isinstance(item, dict) or not str(item.get("formula", "")).strip():
            raise InputError(
                f"related_materials[{index}] must contain a non-empty formula"
            )
        related.append(dict(item))
    return related


def validate_task(payload: dict[str, Any]) -> dict[str, Any]:
    target = payload.get("target")
    if isinstance(target, str):
        target = {"formula": target}
    if not isinstance(target, dict):
        raise InputError("task.target must be an object or formula string")
    formula = str(target.get("formula", "")).strip()
    if not formula:
        raise InputError("task.target.formula is required")
    task_id = str(payload.get("task_id") or f"material-{formula}").strip()
    if not task_id:
        raise InputError("task_id cannot be empty")
    min_records = target.get("min_records", 1)
    if not isinstance(min_records, int) or min_records < 1:
        raise InputError("target.min_records must be a positive integer")
    return {
        **payload,
        "task_id": task_id,
        "target": {**target, "formula": formula, "min_records": min_records},
        "related_materials": _normalise_related(payload.get("related_materials")),
    }


def _profile(task: dict[str, Any], material: dict[str, Any], role: str) -> dict:
    target = task["target"]
    formula = material["formula"]
    return {
        "name": f"{task['task_id']}-{role}-{formula}",
        "elements": material.get("elements", target.get("elements", [])),
        "formulas": [formula],
        "tags": material.get("tags", target.get("tags", [])),
        "functional": material.get("functional", target.get("functional", "PBE")),
        "allow_dft_u": bool(
            material.get("allow_dft_u", target.get("allow_dft_u", False))
        ),
        "min_records": int(material.get("min_records", target["min_records"])),
        "domain": material.get("domain", target.get("domain", "bulk")),
        "prototypes": material.get(
            "prototypes", target.get("prototypes", [])
        ),
        "metadata": {
            "task_id": task["task_id"],
            "role": role,
            "purpose": task.get("purpose"),
            "relationship": material.get("relationship"),
            "knowledge_source": material.get("source"),
        },
    }


def build_query_plan(audit: AuditRun, task: dict[str, Any]) -> list[dict[str, Any]]:
    materials = [("target", task["target"])] + [
        ("related", material) for material in task["related_materials"]
    ]
    plan: list[dict[str, Any]] = []
    profile_dir = audit.directory / "profiles"
    for index, (role, material) in enumerate(materials, 1):
        profile = _profile(task, material, role)
        path = profile_dir / f"{index:02d}-{role}-{_safe_name(material['formula'])}.json"
        _atomic_json(path, profile)
        plan.append(
            {
                "role": role,
                "formula": material["formula"],
                "relationship": material.get("relationship"),
                "knowledge_source": material.get("source"),
                "profile_path": str(path.resolve()),
            }
        )
    plan_path = audit.directory / "query-plan.json"
    _atomic_json(plan_path, {"task_id": task["task_id"], "queries": plan})
    audit.artifact("query_plan", plan_path)
    audit.event("build_query_plan", "success", query_count=len(plan))
    return plan


def _query_one(
    audit: AuditRun, query: dict[str, Any], config: Path | None
) -> dict[str, Any]:
    formula = query["formula"]
    payload, result_path = run_aidb(
        audit,
        f"query-{formula}",
        _with_config(
            ["plan-finetune", "--profile", query["profile_path"]], config
        ),
    )
    assert payload is not None
    evidence = payload.get("evidence") or {}
    record_ids = list(evidence.get("local_record_ids") or [])
    return {
        **query,
        "status": "found" if record_ids else "not_found",
        "local_records_found": int(payload.get("local_records_found", 0)),
        "record_ids": record_ids,
        "additional_dft_required": (payload.get("option_a") or {}).get(
            "additional_dft_required"
        ),
        "local_coverage": evidence.get("local_coverage"),
        "full_result_path": str(result_path.resolve()),
        "reuse_scope": (
            "candidate_for_task_compatibility_check"
            if query["role"] == "target"
            else "reference_only_unless_separately_validated"
        ),
    }


def _export_ids(
    audit: AuditRun,
    query_result: dict[str, Any],
    config: Path | None,
    export_root: Path,
    export_format: str,
) -> dict[str, Any] | None:
    record_ids = query_result["record_ids"]
    if not record_ids:
        return None
    formula = query_result["formula"]
    extension = {"extxyz": "extxyz", "jsonl": "jsonl", "ase_db": "db"}[
        export_format
    ]
    output = (
        export_root.resolve()
        / f"{query_result['role']}-{_safe_name(formula)}"
        / f"records.{extension}"
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    argv = ["export-local"]
    for record_id in record_ids:
        argv.extend(["--record-id", str(record_id)])
    argv.extend(["--output", str(output), "--format", export_format])
    payload, result_path = run_aidb(
        audit, f"export-{formula}", _with_config(argv, config)
    )
    assert payload is not None
    manifest_path = output.parent / "dataset_manifest.json"
    actual_ids: list[str] = []
    if manifest_path.is_file():
        manifest = _read_json(manifest_path, "dataset manifest")
        actual_ids = list(manifest.get("source_records") or [])
    missing = sorted(set(record_ids) - set(actual_ids))
    if not output.is_file() or missing:
        raise AidbCommandError(
            "incomplete_export",
            f"export missing file or record IDs: {missing}",
            result_path,
        )
    return {
        "formula": formula,
        "output_path": str(output),
        "manifest_path": str(manifest_path),
        "requested_record_ids": record_ids,
        "exported_record_ids": actual_ids,
        "record_count": len(actual_ids),
    }


def _config_path(value: str | None) -> Path | None:
    value = value or os.environ.get("AI_READY_DB_CONFIG")
    if not value:
        return None
    path = Path(value).expanduser().resolve()
    if not path.is_file():
        raise InputError(f"config does not exist: {path}")
    return path


def command_health(args: argparse.Namespace) -> dict[str, Any]:
    audit = AuditRun(args.workspace, "aidb-health", args.run_id)
    try:
        bridge, _ = run_aidb(audit, "bridge-info", ["bridge-info"])
        status, _ = run_aidb(
            audit,
            "local-status",
            _with_config(["local-status"], args.config),
        )
        audit.finish("success", total=(status or {}).get("total"))
        return {
            "ok": True,
            "status": "healthy",
            "server_alive_before_check": (bridge or {}).get("server_alive"),
            "local_total": (status or {}).get("total"),
            "audit_path": str(audit.audit_path.resolve()),
        }
    except (AidbCommandError, InputError) as exc:
        kind = getattr(exc, "kind", "input_error")
        audit.finish("failed", error_kind=kind, detail=str(exc))
        raise


def command_preflight(args: argparse.Namespace) -> dict[str, Any]:
    task = validate_task(
        _read_json(args.task_json, "task") if args.task_json else {
            "purpose": "DFT preflight", "target": {
                "formula": args.formula, "functional": args.functional,
            }, "related_materials": [],
        }
    )
    audit = AuditRun(args.workspace, task["task_id"], args.run_id)
    audit.command_timeout = args.command_timeout
    task_path = audit.directory / "task.json"
    _atomic_json(task_path, task)
    audit.artifact("task", task_path)
    try:
        run_aidb(
            audit,
            "local-status",
            _with_config(["local-status"], args.config),
        )
        plan = build_query_plan(audit, task)
        results = [_query_one(audit, query, args.config) for query in plan]
        exports: list[dict[str, Any]] = []
        if args.export_dir:
            for result in results:
                exported = _export_ids(
                    audit,
                    result,
                    args.config,
                    args.export_dir,
                    args.export_format,
                )
                if exported:
                    exports.append(exported)
        report_path = audit.directory / "preflight-report.json"
        report = {
            "task_id": task["task_id"],
            "queries": results,
            "exports": exports,
            "decision_note": (
                "found target records still require task-specific compatibility "
                "validation; related materials are not direct substitutes"
            ),
        }
        _atomic_json(report_path, report)
        audit.artifact("preflight_report", report_path)
        target = results[0]
        audit.finish(
            "success",
            target_status=target["status"],
            target_record_count=len(target["record_ids"]),
        )
        return {
            "ok": True,
            "status": "preflight_complete",
            "task_id": task["task_id"],
            "target_formula": target["formula"],
            "target_status": target["status"],
            "target_record_count": len(target["record_ids"]),
            "target_record_ids": target["record_ids"][:10],
            "target_record_ids_truncated": len(target["record_ids"]) > 10,
            "related_queries": len(results) - 1,
            "exports": len(exports),
            "report_path": str(report_path.resolve()),
            "audit_path": str(audit.audit_path.resolve()),
        }
    except (AidbCommandError, InputError) as exc:
        kind = getattr(exc, "kind", "input_error")
        result_path = getattr(exc, "result_path", None)
        audit.finish(
            "failed",
            error_kind=kind,
            detail=str(exc),
            result_path=str(result_path) if result_path else None,
        )
        raise


def command_archive_and_requery(args: argparse.Namespace) -> dict[str, Any]:
    task = validate_task(_read_json(args.task_json, "task"))
    if not args.record_json.is_file():
        raise InputError(f"record JSON does not exist: {args.record_json}")
    audit = AuditRun(args.workspace, task["task_id"], args.run_id)
    task_path = audit.directory / "task.json"
    _atomic_json(task_path, task)
    audit.artifact("task", task_path)
    try:
        query = build_query_plan(audit, task)[0]
        before = _query_one(audit, query, args.config)
        archive_payload, archive_result = run_aidb(
            audit,
            "archive-local",
            _with_config(
                [
                    "archive-local",
                    "--record-json",
                    str(args.record_json.resolve()),
                    "--namespace",
                    args.namespace,
                    "--origin",
                    args.origin,
                    "--sync-status",
                    args.sync_status,
                ],
                args.config,
            ),
        )
        assert archive_payload is not None
        record_id = str(archive_payload.get("record_id") or "")
        if not record_id:
            raise AidbCommandError(
                "invalid_archive_receipt",
                "archive-local did not return record_id",
                archive_result,
            )
        after = _query_one(audit, query, args.config)
        verified = record_id in after["record_ids"]
        report_path = audit.directory / "archive-report.json"
        report = {
            "task_id": task["task_id"],
            "record_id": record_id,
            "before_record_ids": before["record_ids"],
            "after_record_ids": after["record_ids"],
            "verified_in_requery": verified,
        }
        _atomic_json(report_path, report)
        audit.artifact("archive_report", report_path)
        if not verified:
            raise AidbCommandError(
                "archive_not_visible",
                f"record {record_id} is absent from the post-archive query",
                report_path,
            )
        export = None
        if args.export_dir:
            export = _export_ids(
                audit,
                {**after, "record_ids": [record_id]},
                args.config,
                args.export_dir,
                args.export_format,
            )
        audit.finish("success", record_id=record_id, verified_in_requery=True)
        return {
            "ok": True,
            "status": "archive_verified",
            "task_id": task["task_id"],
            "record_id": record_id,
            "previously_present": record_id in before["record_ids"],
            "export_path": export["output_path"] if export else None,
            "report_path": str(report_path.resolve()),
            "audit_path": str(audit.audit_path.resolve()),
        }
    except (AidbCommandError, InputError) as exc:
        kind = getattr(exc, "kind", "input_error")
        result_path = getattr(exc, "result_path", None)
        audit.finish(
            "failed",
            error_kind=kind,
            detail=str(exc),
            result_path=str(result_path) if result_path else None,
        )
        raise


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--workspace",
        type=Path,
        default=Path(os.environ.get("MATCLAW_SESSION_DIR", Path.cwd())),
    )
    parser.add_argument("--config", default=None)
    parser.add_argument("--run-id", default=None)
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("health")

    preflight = subparsers.add_parser("preflight")
    target_input = preflight.add_mutually_exclusive_group(required=True)
    target_input.add_argument("--task-json", type=Path)
    target_input.add_argument("--formula")
    preflight.add_argument("--functional", default="PBE")
    preflight.add_argument("--command-timeout", type=float, default=60.0)
    preflight.add_argument("--export-dir", type=Path)
    preflight.add_argument(
        "--export-format", choices=("extxyz", "jsonl", "ase_db"), default="extxyz"
    )

    archive = subparsers.add_parser("archive-and-requery")
    archive.add_argument("--task-json", type=Path, required=True)
    archive.add_argument("--record-json", type=Path, required=True)
    archive.add_argument("--namespace", default="bulk_base_pbe")
    archive.add_argument("--origin", default="local_calculation")
    archive.add_argument("--sync-status", default="local_only")
    archive.add_argument("--export-dir", type=Path)
    archive.add_argument(
        "--export-format", choices=("extxyz", "jsonl", "ase_db"), default="extxyz"
    )
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    try:
        args.workspace = args.workspace.expanduser().resolve()
        args.workspace.mkdir(parents=True, exist_ok=True)
        args.config = _config_path(args.config)
        if hasattr(args, "command_timeout") and not (0 < args.command_timeout < float("inf")):
            raise InputError("command-timeout must be positive and finite")
        if hasattr(args, "task_json") and args.task_json:
            args.task_json = args.task_json.expanduser().resolve()
        if hasattr(args, "record_json"):
            args.record_json = args.record_json.expanduser().resolve()
        if hasattr(args, "export_dir") and args.export_dir:
            args.export_dir = args.export_dir.expanduser().resolve()

        if args.command == "health":
            receipt = command_health(args)
        elif args.command == "preflight":
            receipt = command_preflight(args)
        else:
            receipt = command_archive_and_requery(args)
    except InputError as exc:
        print(
            json.dumps(
                {"ok": False, "status": "failed", "error_kind": "input_error", "detail": str(exc)},
                sort_keys=True,
            )
        )
        return 2
    except AidbCommandError as exc:
        print(
            json.dumps(
                {
                    "ok": False,
                    "status": "failed",
                    "error_kind": exc.kind,
                    "detail": str(exc),
                    "result_path": str(exc.result_path.resolve()),
                },
                sort_keys=True,
            )
        )
        return 1
    print(json.dumps(receipt, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
