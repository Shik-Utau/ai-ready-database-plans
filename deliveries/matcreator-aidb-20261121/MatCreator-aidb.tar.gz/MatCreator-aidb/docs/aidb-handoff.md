# MatCreator AIDB 交付与安装

本交付以 `46737212860c53ca739c28ee02ac8db2a2fab7fc` 为基础，补入原工作树中尚未提交的原始产物交付、NSCF 来源、EOS 和 MatPES 回收修复，以及两份使用说明。请在独立目录安装，保留已有基线。

## 1. 获取和安装

支持 Linux 和 Windows 的 WSL2（Ubuntu），使用 Python 3.12 和 Node.js >= 24.14.1。先安装 Git、[uv](https://docs.astral.sh/uv/getting-started/installation/) 和符合版本要求的 Node.js，确认 `git --version`、`uv --version`、`node --version`、`npm --version` 可用。安装需要访问 Python/npm 包源，以及 `mat_agent_bench`、`mat_know_base` 两个 Git 依赖；有权限限制时使用各自的 Git 凭据。

```bash
git clone --branch codex/aidb-handoff-20261121 https://github.com/Shik-Utau/ai-ready-database-plans.git
cd ai-ready-database-plans/deliveries/matcreator-aidb-20261121
tar -xzf MatCreator-aidb.tar.gz
cd MatCreator-aidb
python3 script/install_aidb_handoff.py
source .handoff/env.sh
python script/check_aidb_handoff.py
```

原 MatCreator 仓库另有约 385 MB 的 `database/domain_datasets.tar.gz` Git LFS 对象。本交付包仅保留该文件的指针，不含其数据；安装和 AIDB 样例不依赖它。确有需要时，在有权限的原 MatCreator Git 克隆中单独获取该 LFS 对象。指针文本不等于已下载的数据集。

安装程序创建新的 `.handoff/.venv`，按锁定清单安装 Python 依赖，安装本仓库与随附 AIDB，执行 `npm ci` 和前端构建，再准备独立用户目录、真实 skill 副本、空数据库和 Si 样例。`--runtime /absolute/path` 可指定其他独立目录，此后以程序打印的 `env.sh` 路径为准。Python 3.12 不在本机时，uv 会下载对应解释器。

自检不调用大模型、不提交 VASP，也不写安装程序创建的材料库；它在临时库中验证空查询、真实 VASP 输出归档、重复归档、按 ID 读回及 EXTXYZ/POSCAR/HTML 导出。输出 `PASS` 后再配置模型。

## 2. 配置模型并启动

每次打开新的 Bash 终端，先进入本仓库并加载同一份环境：

```bash
source .handoff/env.sh
matcreator config set llm.model=openai/你的模型名称
matcreator config set llm.base_url=https://你的接口地址/v1
```

在 `.handoff/home/config.yaml` 的 `llm.api_key` 中填写自己的密钥。模型、接口与原使用者一致，才更容易复现对话行为。独立配置不会继承原用户的模型、Bohrium 凭据、技能开关或知识图谱。终端预先设置的 `LLM_*` 等变量在 local 模式优先；遇到配置不一致先检查这些变量。

```bash
bash script/start_matcreator.sh
```

默认打开 <http://127.0.0.1:5174/>；API 和 Web 后端分别为 8100、8101，避开基线默认端口。端口可在 `.handoff/home/config.yaml` 的 `ports` 中修改。若终端已有 `MATCREATOR_*_PORT`，以环境变量为准。保持启动终端运行，Ctrl+C 停止服务。以后也可在仓库根目录运行 `bash script/start_aidb_handoff.sh`，它会自动加载默认运行目录；自定义运行目录作为第一个参数传入。

## 3. 从正常对话验收 {#chat-acceptance}

先使用安装生成的空库，不需要 VASP、POTCAR 或 Bohrium。新建 Web 对话，在界面核对工作目录为 `.handoff/workspace` 的绝对路径。`AI_READY_DB_CONFIG` 已指向新库，也可明确发送「本次对话使用 `/实际路径/.handoff/aidb-config.json` 作为 AIDB 配置」。

依次发送：

1. 「查询当前 AIDB 中化学式为 Si 的记录。」空库应为 0 条。
2. 「请把 aidb-demo/si-pbe-relax 中已经完成的 VASP 弛豫结果保存到 AIDB，告诉我读回的记录 ID。」
3. 「查询化学式为 Si、使用 PBE 且有逐原子力的记录。」应返回 1 条；详情为 8 个 Si 原子，末帧能量约 −43.38227814 eV/cell。
4. 点击详情与导出，或要求「将这条记录导出为 EXTXYZ、POSCAR 和完整详情 HTML」。
5. 再次发送相同保存请求。应返回已有记录，ID 不变。

自动自检只证明安装和数据路径可用；这一轮 Web 对话另外验证模型路由与界面。示例的历史输出不会运行新的计算。计算前复用、Batch/Sandbox、SCF/NSCF、AIMD、EOS、MatPES 和恢复操作见[使用指南](aidb-vasp.md)与[对话样例](aidb-vasp-examples.md)。新计算需各自配置 Bohrium、项目、镜像、资源和有权使用的 POTCAR。

## 4. 文件分别归谁管理

| 内容 | 本交付位置 | 是否进入 Git |
| --- | --- | --- |
| MatCreator 源码、内置 skill、前端、样例 | `src/`、`web/`、`tests/aidb/fixtures/` | 是 |
| 独立维护的 AIDB skill 发布源 | `delivery/skills/ai-ready-db/` | 是；包括脚本、参考文档和模板 |
| AIDB 运行代码快照 | `delivery/vendor/ai-ready-db/` | 是；固定外部仓库提交，未混入其本地 skill 改动 |
| 来源、原 skill 哈希、交付文件哈希 | `delivery/manifest.json` | 是 |
| 依赖锁与验收环境约束 | `delivery/requirements-linux-py312.lock`、`delivery/constraints.txt` | 是 |
| 本机安装的 skill | `.handoff/home/skills/ai-ready-db/` | 否；从发布源复制的真实目录 |
| 模型与其他个人配置 | `.handoff/home/config.yaml` | 否 |
| 库配置、SQLite、sidecar | `.handoff/aidb-config.json`、`.handoff/data/` | 否 |
| 工作区、会话、图谱、日志、环境 | `.handoff/workspace/`、`.handoff/home/.adk/`、`.handoff/home/logs/`、`.handoff/.venv/` | 否 |

整个 `.handoff/` 已忽略。使用外部 `--runtime` 时，运行目录应放在版本管理之外。数据库与 sidecar 必须配套迁移；本交付从空库开始，不附带原用户的材料库、会话、模型文件、密钥或 POTCAR。

### skill 加载和更新

真实加载顺序见 `src/matcreator/skill.py`：内置 → official → 用户自定义 → workspace，同名使用先发现的目录。workspace 技能目录为 `$MATCLAW_WORKSPACE/skills/`；会话工作目录可另外指定，不能把任意会话目录下的 skill 当作一定会被发现。工作区根依次来自 `MATCLAW_WORKSPACE`、`workspace.default_workdir`、`$MATCREATOR_HOME/workspace`。

本版通过 `env.sh` 固定内置 skill 根、用户目录和工作区，避免误用基线或个人环境。AIDB skill 必须是实际目录：验收曾发现 `rglob("SKILL.md")` 不会进入符号链接的 skill 目录。自检会报告最终加载位置、来源及是否停用。

以后修改运行目录中的 skill，Git 不会看见。应先比较它与 `delivery/skills/ai-ready-db/`，把确认需要发布的文件同步回发布源；内置 VASP skill 则修改 `src/matcreator/skills/vasp-pymatgen/`。运行 `python3 script/update_aidb_handoff_manifest.py` 刷新经确认的发布文件哈希后提交，重新运行安装程序部署。安装程序保留已有配置和数据库；skill 有差异时先移到运行目录的 `backups/`，备份在扫描目录外。然后重启正在运行的服务。独立 Python 进程的刷新不会更新已有服务，也无需删除知识图谱。

安装的 AIDB skill 与上游数据库仓库的同名 skill 独立维护。保留原 `aidb_ops.py` 的查询协议，在 skill 正文中补充本版宿主工具入口；原始 skill 文件哈希保存在 manifest。不要用上游 `skills/ai-ready-db` 整包覆盖本目录。旧 standalone 参考只适用于其脚本路径，不代表正式宿主功能范围。

## 5. 版本与验证范围

AIDB 快照来源为 `Zikkying/Ai-ready_Database` 的 `008e881676c12fe2028200c944cc8bd99fabbdfb`，只包含运行包、配置模板与构建元数据。来源信息见 仓库内 `delivery/README.md`。原安装 skill 与四个验收环境副本逐文件哈希一致，其中 `aidb_ops.py` 为 `643c984ddb48f858447f81bf415d89918bf8bdb0bb6f2aa5916e0cfec88d6c77`。

Python 依赖使用原验收环境约束解析，Google ADK 2.14.0、ASE 3.29.0、pymatgen 2026.10.24；两个 Git 依赖固定到完整提交。锁定的是本交付所需依赖，安装仍需网络下载。`2.27.0` 只是包版本号，解压目录不附带 Git 历史；应用源码版本、补丁和归档 SHA-256 见计划仓库交付目录的 `manifest.json`，发布版本以计划仓库提交标识。

历史正常对话与真实/回放计算范围见[原验收记录](aidb-implementation/ticket14.md)。本次安装与回归记录见[交付验证](aidb-handoff-validation.md)。自动自检和离线回归不等同于在师兄账户上提交真实付费作业。
