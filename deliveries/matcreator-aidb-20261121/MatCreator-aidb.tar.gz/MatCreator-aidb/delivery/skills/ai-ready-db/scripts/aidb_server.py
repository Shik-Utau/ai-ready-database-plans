#!/usr/bin/env python3
"""Serial local bridge from MatCreator to the ai-ready-db CLI."""

from __future__ import annotations

import argparse
import atexit
import contextlib
import gc
import io
import json
import logging
import os
import select
import signal
import socket
import sys
from pathlib import Path


IDLE_TIMEOUT = float(os.environ.get("AI_READY_DB_BRIDGE_IDLE_TIMEOUT", "600"))
BACKLOG = int(os.environ.get("AI_READY_DB_BRIDGE_BACKLOG", "128"))
MAX_REQUEST_BYTES = int(
    os.environ.get("AI_READY_DB_BRIDGE_MAX_REQUEST_BYTES", str(8 * 1024 * 1024))
)
FALLBACK_COMMANDS = {
    "init-db", "ingest", "classify", "screen", "route-to-cloud",
    "prepare-recalc", "submit-recalc", "archive-recalc", "status",
    "archive-local", "local-status", "plan-finetune", "accept-cloud-reuse",
    "reject-cloud-reuse", "run-supplement-dft", "run-finetune",
    "export-local", "pull-from-cloud", "sync-to-cloud",
    "upload-new-records-to-cloud",
}
_SOCKET_PATH: Path | None = None


def _resolve_root() -> Path:
    explicit = os.environ.get("AI_READY_DB_ROOT", "").strip()
    if not explicit:
        raise RuntimeError("AI_READY_DB_ROOT is required by aidb_server.py")
    root = Path(explicit).expanduser().resolve()
    if not (root / "ai_ready_db" / "cli.py").is_file():
        raise RuntimeError(f"invalid AI_READY_DB_ROOT: {root}")
    return root


def _resolve_socket() -> Path:
    explicit = os.environ.get("AI_READY_DB_BRIDGE_SOCK", "").strip()
    if not explicit:
        raise RuntimeError("AI_READY_DB_BRIDGE_SOCK is required by aidb_server.py")
    return Path(explicit).expanduser()


def extract_subcommands(parser: argparse.ArgumentParser) -> set[str]:
    try:
        for action in parser._actions:
            if isinstance(action, argparse._SubParsersAction):
                return set(action.choices)
    except Exception:
        pass
    return set(FALLBACK_COMMANDS)


def find_subcommand(argv: list[str], allowed: set[str] | None = None) -> str | None:
    if allowed:
        for token in argv:
            if token in allowed:
                return token
    for token in argv:
        if not token.startswith("-"):
            return token
    if any(token in ("-h", "--help") for token in argv):
        return "--help"
    return None


def run_cli(cli_main, argv: list[str]) -> dict:
    """Run one CLI call while the bridge remains deliberately serial."""

    out, err = io.StringIO(), io.StringIO()
    root_logger = logging.getLogger()
    saved = [
        (handler, handler.stream)
        for handler in root_logger.handlers
        if isinstance(handler, logging.StreamHandler)
    ]
    for handler, _ in saved:
        handler.setStream(err)
    try:
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            try:
                code = cli_main(list(argv))
            except SystemExit as exc:
                code = exc.code if isinstance(exc.code, int) else (
                    0 if exc.code is None else 1
                )
    except Exception as exc:  # noqa: BLE001 - bridge must always reply
        code = 1
        err.write(f"bridge internal error: {exc}\n")
    finally:
        for handler, stream in saved:
            handler.setStream(stream)
    return {
        "returncode": int(code),
        "stdout": out.getvalue(),
        "stderr": err.getvalue(),
    }


def _cleanup_socket() -> None:
    if _SOCKET_PATH is None:
        return
    try:
        _SOCKET_PATH.unlink()
    except OSError:
        pass


def _handle_signal(signum, frame) -> None:  # noqa: ARG001
    _cleanup_socket()
    raise SystemExit(0)


def _probe_and_clean(sock_path: Path) -> None:
    if not sock_path.exists():
        return
    probe = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    probe.settimeout(0.5)
    try:
        probe.connect(str(sock_path))
    except OSError:
        sock_path.unlink(missing_ok=True)
    else:
        raise RuntimeError(f"bridge socket is already active: {sock_path}")
    finally:
        probe.close()


def _handle_line(line: bytes, cli_main, allowed: set[str]) -> dict:
    try:
        request = json.loads(line)
        argv = request["argv"]
        if not isinstance(argv, list) or not all(
            isinstance(token, str) for token in argv
        ):
            raise ValueError("argv must be a list of strings")
    except Exception as exc:
        return {"returncode": 2, "stdout": "", "stderr": f"bad request: {exc}"}
    subcommand = find_subcommand(argv, allowed)
    if subcommand == "--help":
        return run_cli(cli_main, argv)
    if subcommand not in allowed:
        return {
            "returncode": 2,
            "stdout": "",
            "stderr": f"command not allowed: {subcommand!r}",
        }
    return run_cli(cli_main, argv)


def serve() -> None:
    global _SOCKET_PATH
    root = _resolve_root()
    sock_path = _resolve_socket()
    _SOCKET_PATH = sock_path
    os.chdir(root)
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    from ai_ready_db.cli import build_parser, main as cli_main

    allowed = extract_subcommands(build_parser())
    logging.basicConfig(
        level=logging.WARNING, format="%(levelname)s %(name)s %(message)s"
    )
    sock_path.parent.mkdir(parents=True, exist_ok=True)
    _probe_and_clean(sock_path)
    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    server.bind(str(sock_path))
    os.chmod(sock_path, 0o600)
    server.listen(BACKLOG)
    atexit.register(_cleanup_socket)
    signal.signal(signal.SIGTERM, _handle_signal)
    signal.signal(signal.SIGINT, _handle_signal)
    try:
        while True:
            readable, _, _ = select.select([server], [], [], IDLE_TIMEOUT)
            if not readable:
                break
            conn, _ = server.accept()
            try:
                with conn:
                    reader = conn.makefile("rb")
                    try:
                        while True:
                            line = reader.readline(MAX_REQUEST_BYTES + 1)
                            if not line:
                                break
                            if len(line) > MAX_REQUEST_BYTES:
                                reply = {
                                    "returncode": 2,
                                    "stdout": "",
                                    "stderr": "request exceeds bridge size limit",
                                }
                            else:
                                reply = _handle_line(line, cli_main, allowed)
                            conn.sendall((json.dumps(reply) + "\n").encode())
                            gc.collect()
                    finally:
                        reader.close()
            except (BrokenPipeError, ConnectionResetError, OSError):
                continue
    finally:
        server.close()
        _cleanup_socket()


if __name__ == "__main__":
    serve()
