"""Recipient installation preserves material data and deploys discoverable skills."""
import importlib.util
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("handoff_installer", ROOT / "script/install_aidb_handoff.py")
installer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(installer)


def test_reinstall_preserves_config_material_data_and_replaces_changed_skill(tmp_path):
    runtime = tmp_path / "recipient"
    python = runtime / ".venv/bin/python"
    installer.initialize(runtime, python=python)
    config = runtime / "home/config.yaml"
    config.write_text("llm:\n  model: own-model\n", encoding="utf-8")
    sidecar = runtime / "data/archive.sidecar.json"
    sidecar.write_text('{"records": {"own-record": {}}}', encoding="utf-8")
    database = runtime / "data/archive.db"
    before = database.read_bytes()
    installed = runtime / "home/skills/ai-ready-db"
    assert not installed.is_symlink()
    (installed / "SKILL.md").write_text("recipient edits", encoding="utf-8")
    installer.initialize(runtime, python=python)
    assert config.read_text() == "llm:\n  model: own-model\n"
    assert sidecar.read_text() == '{"records": {"own-record": {}}}'
    assert database.read_bytes() == before
    assert (installed / "SKILL.md").read_bytes() == (installer.DELIVERY / "skills/ai-ready-db/SKILL.md").read_bytes()
    [backup] = (runtime / "backups").glob("*/ai-ready-db/SKILL.md")
    assert backup.read_text() == "recipient edits"
    assert not list((runtime / "home/skills").rglob("backups"))
    assert str(runtime / "workspace") in (runtime / "env.sh").read_text()


def test_reinstall_refuses_to_recreate_missing_sidecar(tmp_path):
    runtime = tmp_path / "recipient"
    python = runtime / ".venv/bin/python"
    installer.initialize(runtime, python=python)
    (runtime / "data/archive.sidecar.json").unlink()
    before = (runtime / "data/archive.db").read_bytes()
    with pytest.raises(RuntimeError, match="sidecar"):
        installer.initialize(runtime, python=python)
    assert not (runtime / "data/archive.sidecar.json").exists()
    assert (runtime / "data/archive.db").read_bytes() == before


def test_skill_symlink_is_backed_up_and_replaced_with_real_directory(tmp_path):
    original = tmp_path / "old-skill"
    original.mkdir()
    (original / "SKILL.md").write_text("old", encoding="utf-8")
    runtime = tmp_path / "recipient"
    skills = runtime / "home/skills"
    skills.mkdir(parents=True)
    (skills / "ai-ready-db").symlink_to(original, target_is_directory=True)
    installer.initialize(runtime, python=runtime / ".venv/bin/python")
    assert not (skills / "ai-ready-db").is_symlink()
    assert list(skills.rglob("ai-ready-db/SKILL.md"))
    assert (original / "SKILL.md").read_text() == "old"


def test_manifest_rejects_changed_skill_script(tmp_path, monkeypatch):
    delivery = tmp_path / "delivery"
    delivery.mkdir()
    (delivery / "manifest.json").write_text('{"files": {"missing.py": "wrong"}}')
    monkeypatch.setattr(installer, "DELIVERY", delivery)
    with pytest.raises(RuntimeError, match="missing.py"):
        installer.verify_bundle()
