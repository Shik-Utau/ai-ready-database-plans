# aidb_ops.py 接口约定

仅限已安装的 MatCreator `ai-ready-db` skill。源代码项目的同名 skill 独立维护。

## 命令

```text
aidb_ops.py --workspace WORKSPACE [--config CONFIG] query --conditions-json CONDITIONS
aidb_ops.py --workspace WORKSPACE [--config CONFIG] insert --calculation-dir DIRECTORY --source-id ID [--source-dataset DATASET]
```

全局参数放在子命令之前。使用绝对路径，传给 `run_skill_script` 的每个参数经 `shlex.quote` 等价转义。
CONFIG 可由 AI_READY_DB_CONFIG 提供；DATASET 默认为 local_dft。操作环境复用 aidb_client 的有限范围发现机制。
首次运行重新启动到 aidb 的 Python 环境；不启动桥接 server。

配置是 aidb YAML/JSON，须显式写出 `ase_sqlite.path` 与 `ase_sqlite.json_sidecar_path`。
本适配层把相对存储路径解释为相对于配置目录；若原 CLI 依赖工作目录，请先改用绝对路径。
查询要求两个文件已存在；插入可在显式位置初始化新库。

## query 条件

JSON 对象，字段缺失或 `null` 表示不限。至少有一个非空、非 null 条件。

| 字段 | 类型 | 匹配 |
|---|---|---|
| record_id | string | 精确记录 ID，直接读取；其他条件仍取交集 |
| formula | string | pymatgen 约化组成相等；SrTiO3 与 O3SrTi 一致，不区分晶相 |
| elements | string[] | 非空有效元素符号，全部包含，可有额外元素 |
| functional | string | 精确存储值，如 PBE、SCAN；本版不提供别名或模糊匹配 |
| has_hubbard_u | boolean | 保存的方法信息表明是否使用 U；未知既不匹配 true，也不匹配 false |
| calculation_type | string | 精确存储值；本适配器可识别 static、relaxation、molecular_dynamics，不能识别时为空 |
| source_dataset / source_id | string | 精确来源数据集／来源标识 |
| has_forces / has_stress | boolean | 对应已保存结果非空；false 表示缺项 |

空对象、空字符串、空元素数组、错误类型和未知字段均为错误。布尔值须为 `true/false`，不能写字符串 `"false"`。
已存记录的未知方法不得假定为 PBE。记录存在和条件命中不代表可用于新计算。

查询读取所有本地 namespace，包括 workflow、rejected_records 等；其状态保存在详情的 source_metadata 中，命中不代表已通过质量筛选。
采用当前 aidb 读接口全量扫描，没有条数截断；尚未做十万条性能验收。
`records.jsonl` 存完整匹配记录，`report.json` 存条件、范围、数量、3 条预览、是否截断预览及详情路径。
stdout 是小型 JSON 回执，避免宿主 4000 字符截断；预览要读取报告后展示。

## insert 内容与校验

- 输入须是已完成的 VASP 结果目录，仅一个 vasprun.xml 或 vasprun.xml.gz。
- XML 必须完整且解析前后哈希不变；pymatgen 电子／离子收敛均为真才保存。
- 提取最后一步结构、零展宽外推总能量（pymatgen final_energy，eV）、力（eV/Å）、应力。
- VASP 应力（kbar、压缩为正）先翻转符号，再由 aidb 归一化为 eV/Å³、拉伸为正；转换和单位写入 provenance。查询从 provenance 恢复 aidb 读回遗漏的单位。
- 保存解析所得计算参数、来源、文件路径／SHA256、收敛与软件版本；不复制源文件。
- 混合泛函不能从不完整信息精确识别时记 hybrid 并保留参数；未知方法为 null；U 依据解析后的有效设置。
- 本版不解析 DOS／本征值／OUTCAR 磁矩电荷；相应缺项为空，不拿初始 MAGMOM 填最终磁矩。
- U 记录进 bulk_dft_u_archive；已知 PBE 且无 U 进 bulk_base_pbe；其他进 fine_tune_working。
- 写前校验数据可序列化、数值有限、结构非空、力／应力维度。保存后按返回 ID 核对结构、结果、方法、参数与来源。
- 写入沿用 aidb 的 ID 生成与同 ID 覆盖行为；不设计重复数据合并。数据库与 sidecar 不是单事务：失败可能部分写入，不自动重试。
- 适配器用共享 sidecar 路径的文件锁串行化自身读写；无法约束绕过本适配器的外部写入者。

## 状态

| 状态 | 退出码 | 含义 |
|---|---|---|
| query_complete | 0 | 查询完整完成，match_count 可以为 0 |
| insert_complete | 0 | 已保存且 readback_verified=true |
| not_stored | 0 | 收敛未确认，未执行写入 |
| error | 1 | 输入、解析、存储或校验失败；不是未命中 |

CLI 用法错误由 argparse 返回退出码 2。宿主超时／中断没有成功含义。
每次操作生成独立运行目录。失败有 error.json；开始写入前记录 write-attempt.json 和 intended-record.json。
完整路径见回执 report_path；所有查询／写入报告均应先读取再向用户宣布完成。
